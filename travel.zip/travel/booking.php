<?php
require_once 'config.php';
require_once 'paytm-config.php';

if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $route_id = intval($_POST['route_id']);
    $bus_id = intval($_POST['bus_id']);
    $travel_date = $_POST['travel_date'];
    $seats_booked = intval($_POST['seats_booked']);
    $user_id = $_SESSION['user_id'];

    // Check seat availability
    $seat_query = "SELECT total_seats FROM buses WHERE id = $bus_id";
    $seat_result = mysqli_query($conn, $seat_query);
    $bus = mysqli_fetch_assoc($seat_result);

    $booked_query = "SELECT SUM(seats_booked) as booked FROM bookings WHERE bus_id = $bus_id AND travel_date = '$travel_date'";
    $booked_result = mysqli_query($conn, $booked_query);
    $booked = mysqli_fetch_assoc($booked_result);

    $available_seats = $bus['total_seats'] - intval($booked['booked']);

    if ($seats_booked > $available_seats) {
        $_SESSION['error'] = "Not enough seats available.";
        header("Location: book-now.php");
        exit();
    }

    // Calculate total amount (example: ₹500 per seat)
    $total_amount = $seats_booked * 500;

    // Insert booking
    $insert = "INSERT INTO bookings (user_id, route_id, bus_id, travel_date, seats_booked, total_amount, booking_time)
               VALUES ($user_id, $route_id, $bus_id, '$travel_date', $seats_booked, $total_amount, NOW())";
    if (mysqli_query($conn, $insert)) {
        $last_id = mysqli_insert_id($conn);
        $_SESSION['last_booking_id'] = $last_id;
        header("Location: booking.php?booking_id=$last_id");
        exit();
    } else {
        $_SESSION['error'] = "Booking failed. Please try again.";
        header("Location: book-now.php");
        exit();
    }
}

// Fetch routes and buses for the form
$routes = mysqli_query($conn, "SELECT * FROM bus_routes");
$buses = mysqli_query($conn, "SELECT * FROM buses");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Now - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h2>Book Your Ticket</h2>
    <?php if (!empty($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="mb-3">
            <label for="route_id" class="form-label">Route</label>
            <select name="route_id" id="route_id" class="form-control" required>
                <?php while ($route = mysqli_fetch_assoc($routes)): ?>
                    <option value="<?php echo $route['id']; ?>">
                        <?php echo htmlspecialchars($route['from_city'] . " to " . $route['to_city']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="bus_id" class="form-label">Bus</label>
            <select name="bus_id" id="bus_id" class="form-control" required>
                <?php while ($bus = mysqli_fetch_assoc($buses)): ?>
                    <option value="<?php echo $bus['id']; ?>">
                        <?php echo htmlspecialchars($bus['bus_name'] . " (" . $bus['bus_number'] . ")"); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="travel_date" class="form-label">Travel Date</label>
            <input type="date" name="travel_date" id="travel_date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="seats_booked" class="form-label">Number of Seats</label>
            <input type="number" name="seats_booked" id="seats_booked" class="form-control" min="1" required>
        </div>
        <button type="submit" class="btn btn-success">Book Now</button>
    </form>
</div>
</body>
</html>
