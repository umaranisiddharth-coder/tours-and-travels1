<?php
require_once 'config.php';

// Page configuration
$page_title = 'Set New Password';
$page_description = 'Create a new secure password for your SR Travels account';

// Redirect if already logged in
if (is_logged_in()) {
    if (is_admin()) {
        header("Location: admin-dashboard-enhanced.php");
    } else {
        header("Location: user-dashboard-enhanced.php");
    }
    exit();
}

$error = '';
$success = '';
$token = isset($_GET['token']) ? sanitize_input($_GET['token']) : '';

// Clean expired tokens
if (function_exists('clean_expired_otps')) {
    clean_expired_otps();
}

// Validate token
if ($token) {
    $query = "SELECT * FROM users WHERE reset_token = '$token' AND reset_token_expiry > NOW()";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) == 0) {
        $error = "Invalid or expired reset link.";
        $token = '';
    } else {
        $user = mysqli_fetch_assoc($result);
        $email = $user['email'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = sanitize_input($_POST['token']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate
    if (empty($password)) {
        $error = 'Please enter a new password.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long.';
    } else {
        // Check password strength
        $strength_errors = check_password_strength($password);
        if (!empty($strength_errors)) {
            $error = implode('<br>', $strength_errors);
        } else {
            // Check if token is still valid
            $query = "SELECT * FROM users WHERE reset_token = '$token' AND reset_token_expiry > NOW()";
            $result = mysqli_query($conn, $query);
            
            if (mysqli_num_rows($result) > 0) {
                $user = mysqli_fetch_assoc($result);
                
                // Hash new password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Update password and clear reset token
                $update_query = "UPDATE users SET password = '$hashed_password', 
                                reset_token = NULL, reset_token_expiry = NULL,
                                otp_code = NULL, otp_expiry = NULL,
                                otp_attempts = 0
                                WHERE id = {$user['id']}";
                
                if (mysqli_query($conn, $update_query)) {
                    // Send confirmation email
                    $subject = "Password Reset Successful - SR Travels";
                    $message = "
                    <html>
                    <body style='font-family: Arial, sans-serif;'>
                        <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
                            <h2 style='color: #d32f2f;'>Password Reset Successful</h2>
                            <p>Your password has been successfully reset for your SR Travels account.</p>
                            <p>If you did not perform this action, please contact our support team immediately.</p>
                            <hr>
                            <p><strong>Reset Details:</strong></p>
                            <p>Date: " . date('Y-m-d H:i:s') . "</p>
                            <p>IP Address: " . $_SERVER['REMOTE_ADDR'] . "</p>
                            <hr>
                            <p>Thank you for using SR Travels!</p>
                        </div>
                    </body>
                    </html>";
                    
                    send_email($user['email'], $subject, $message);
                    
                    $success = 'Password has been reset successfully! You can now login with your new password.';
                    $token = ''; // Clear token after successful reset
                } else {
                    $error = 'Error resetting password. Please try again.';
                }
            } else {
                $error = 'Invalid or expired reset link.';
            }
        }
    }
}

// Custom CSS for RedBus-inspired design
$custom_css = "
    body {
        background: linear-gradient(135deg, #d32f2f 0%, #f44336 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .reset-wrapper {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    .reset-container {
        background: white;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        overflow: hidden;
        max-width: 500px;
        width: 100%;
        padding: 40px;
    }
    
    .reset-header {
        text-align: center;
        margin-bottom: 30px;
    }
    
    .brand-logo {
        font-size: 2.5rem;
        font-weight: 800;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .brand-logo i {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .reset-title {
        font-size: 1.8rem;
        font-weight: 700;
        color: #333;
        margin-bottom: 10px;
    }
    
    .reset-subtitle {
        color: #666;
        font-size: 1rem;
        margin-bottom: 0;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #333;
        font-size: 0.9rem;
    }
    
    .form-control {
        width: 100%;
        padding: 15px;
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #fafafa;
    }
    
    .form-control:focus {
        outline: none;
        border-color: #d32f2f;
        background: white;
        box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.1);
    }
    
    .input-group {
        position: relative;
        display: flex;
    }
    
    .input-group .form-control {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-right: none;
    }
    
    .input-group .btn {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        border: 2px solid #e0e0e0;
        border-left: none;
        background: #f8f9fa;
        color: #666;
        padding: 15px 20px;
    }
    
    .input-group .btn:hover {
        background: #e9ecef;
        color: #333;
    }
    
    .btn-primary {
        width: 100%;
        padding: 15px;
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        color: white;
        border: none;
        border-radius: 10px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-bottom: 15px;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(211, 47, 47, 0.3);
    }
    
    .alert {
        padding: 15px 20px;
        border-radius: 10px;
        margin-bottom: 20px;
        font-size: 0.9rem;
        border: none;
    }
    
    .alert-danger {
        background: linear-gradient(135deg, rgba(211, 47, 47, 0.1), rgba(183, 28, 28, 0.1));
        color: #c62828;
        border-left: 4px solid #d32f2f;
    }
    
    .alert-success {
        background: linear-gradient(135deg, rgba(46, 125, 50, 0.1), rgba(56, 142, 60, 0.1));
        color: #2e7d32;
        border-left: 4px solid #4caf50;
    }
    
    .alert-warning {
        background: linear-gradient(135deg, rgba(255, 152, 0, 0.1), rgba(255, 193, 7, 0.1));
        color: #f57c00;
        border-left: 4px solid #ff9800;
    }
    
    .password-strength {
        margin-top: 10px;
        font-size: 0.85rem;
    }
    
    .strength-bar {
        height: 6px;
        background: #e0e0e0;
        border-radius: 3px;
        margin-top: 5px;
        overflow: hidden;
    }
    
    .strength-fill {
        height: 100%;
        width: 0%;
        transition: all 0.3s ease;
        border-radius: 3px;
    }
    
    .password-rules {
        font-size: 0.8rem;
        color: #666;
        margin-top: 10px;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .password-rules ul {
        padding-left: 20px;
        margin-bottom: 0;
    }
    
    .password-rules li {
        margin-bottom: 5px;
        transition: color 0.3s ease;
    }
    
    .password-rules li.valid {
        color: #28a745;
    }
    
    .password-rules li.invalid {
        color: #dc3545;
    }
    
    .password-rules li.valid::before {
        content: '✓ ';
        font-weight: bold;
    }
    
    .password-rules li.invalid::before {
        content: '✗ ';
        font-weight: bold;
    }
    
    .form-text {
        font-size: 0.85rem;
        margin-top: 5px;
    }
    
    .back-link {
        text-align: center;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #e0e0e0;
    }
    
    .back-link a {
        color: #d32f2f;
        text-decoration: none;
        font-weight: 500;
    }
    
    .back-link a:hover {
        text-decoration: underline;
    }
    
    @media (max-width: 768px) {
        .reset-container {
            margin: 10px;
            padding: 30px 20px;
        }
        
        .brand-logo {
            font-size: 2rem;
        }
        
        .reset-title {
            font-size: 1.5rem;
        }
    }
";

// Don't show page header for reset password
$show_page_header = false;

// Include header
include 'includes/header.php';
?>

<div class="reset-wrapper">
    <div class="reset-container" data-aos="fade-up">
        <div class="reset-header">
            <div class="brand-logo">
                <i class="fas fa-bus"></i>
                <span>SR TRAVELS</span>
            </div>
            <h1 class="reset-title">Set New Password</h1>
            <p class="reset-subtitle">Create a strong and secure password</p>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
            <div class="text-center">
                <a href="login.php" class="btn btn-primary">
                    <i class="fas fa-sign-in-alt me-2"></i>Go to Login
                </a>
            </div>
        <?php elseif($token): ?>
            <form method="POST" action="" id="resetForm">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                
                <div class="form-group">
                    <label class="form-label" for="password">
                        <i class="fas fa-lock me-2"></i>New Password
                    </label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" 
                               placeholder="Enter your new password" required>
                        <button type="button" class="btn toggle-password">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="password-strength">
                        <div>Password strength: <span id="strength-value" style="font-weight: 600;">None</span></div>
                        <div class="strength-bar">
                            <div id="strength-fill" class="strength-fill"></div>
                        </div>
                    </div>
                    <div class="password-rules" id="password-rules">
                        <strong>Password Requirements:</strong>
                        <ul>
                            <li id="rule-length" class="invalid">At least 8 characters</li>
                            <li id="rule-uppercase" class="invalid">One uppercase letter</li>
                            <li id="rule-lowercase" class="invalid">One lowercase letter</li>
                            <li id="rule-number" class="invalid">One number</li>
                            <li id="rule-special" class="invalid">One special character</li>
                        </ul>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="confirm_password">
                        <i class="fas fa-lock me-2"></i>Confirm New Password
                    </label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                               placeholder="Confirm your new password" required>
                        <button type="button" class="btn toggle-password">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div id="password-match" class="form-text"></div>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-key me-2"></i>Reset Password
                </button>
            </form>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                No valid reset link found. Please request a new password reset.
            </div>
            <div class="text-center">
                <a href="forgot-password.php" class="btn btn-primary">
                    <i class="fas fa-redo me-2"></i>Request New Reset
                </a>
            </div>
        <?php endif; ?>
        
        <div class="back-link">
            <a href="login.php">
                <i class="fas fa-arrow-left me-1"></i>Back to Login
            </a>
        </div>
    </div>
</div>

<script>
    // Password strength checker
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const strengthText = document.getElementById('strength-value');
    const strengthFill = document.getElementById('strength-fill');
    const passwordMatch = document.getElementById('password-match');
    
    // Password rules elements
    const ruleLength = document.getElementById('rule-length');
    const ruleUppercase = document.getElementById('rule-uppercase');
    const ruleLowercase = document.getElementById('rule-lowercase');
    const ruleNumber = document.getElementById('rule-number');
    const ruleSpecial = document.getElementById('rule-special');
    
    function checkPasswordStrength(password) {
        let strength = 0;
        
        // Check length
        if (password.length >= 8) {
            strength += 20;
            ruleLength.classList.remove('invalid');
            ruleLength.classList.add('valid');
        } else {
            ruleLength.classList.remove('valid');
            ruleLength.classList.add('invalid');
        }
        
        // Check uppercase
        if (/[A-Z]/.test(password)) {
            strength += 20;
            ruleUppercase.classList.remove('invalid');
            ruleUppercase.classList.add('valid');
        } else {
            ruleUppercase.classList.remove('valid');
            ruleUppercase.classList.add('invalid');
        }
        
        // Check lowercase
        if (/[a-z]/.test(password)) {
            strength += 20;
            ruleLowercase.classList.remove('invalid');
            ruleLowercase.classList.add('valid');
        } else {
            ruleLowercase.classList.remove('valid');
            ruleLowercase.classList.add('invalid');
        }
        
        // Check numbers
        if (/[0-9]/.test(password)) {
            strength += 20;
            ruleNumber.classList.remove('invalid');
            ruleNumber.classList.add('valid');
        } else {
            ruleNumber.classList.remove('valid');
            ruleNumber.classList.add('invalid');
        }
        
        // Check special characters
        if (/[^A-Za-z0-9]/.test(password)) {
            strength += 20;
            ruleSpecial.classList.remove('invalid');
            ruleSpecial.classList.add('valid');
        } else {
            ruleSpecial.classList.remove('valid');
            ruleSpecial.classList.add('invalid');
        }
        
        // Update strength bar
        strengthFill.style.width = strength + '%';
        
        // Update strength text and colors
        if (strength >= 80) {
            strengthText.textContent = 'Strong';
            strengthText.style.color = '#28a745';
            strengthFill.style.backgroundColor = '#28a745';
        } else if (strength >= 60) {
            strengthText.textContent = 'Good';
            strengthText.style.color = '#ffc107';
            strengthFill.style.backgroundColor = '#ffc107';
        } else if (strength >= 40) {
            strengthText.textContent = 'Fair';
            strengthText.style.color = '#fd7e14';
            strengthFill.style.backgroundColor = '#fd7e14';
        } else if (strength > 0) {
            strengthText.textContent = 'Weak';
            strengthText.style.color = '#dc3545';
            strengthFill.style.backgroundColor = '#dc3545';
        } else {
            strengthText.textContent = 'None';
            strengthText.style.color = '#6c757d';
            strengthFill.style.backgroundColor = '#6c757d';
        }
    }
    
    function checkPasswordMatch() {
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        
        if (confirmPassword === '') {
            passwordMatch.textContent = '';
            passwordMatch.style.color = '';
        } else if (password === confirmPassword) {
            passwordMatch.innerHTML = '<i class="fas fa-check-circle me-1"></i>Passwords match';
            passwordMatch.style.color = '#28a745';
        } else {
            passwordMatch.innerHTML = '<i class="fas fa-times-circle me-1"></i>Passwords do not match';
            passwordMatch.style.color = '#dc3545';
        }
    }
    
    // Event listeners
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            checkPasswordMatch();
        });
    }
    
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', checkPasswordMatch);
    }
    
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // Form validation
    const resetForm = document.getElementById('resetForm');
    if (resetForm) {
        resetForm.addEventListener('submit', function(e) {
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return;
            }
            
            // Check if password meets all requirements
            const validRules = document.querySelectorAll('.password-rules li.valid');
            if (validRules.length < 5) {
                e.preventDefault();
                alert('Please ensure your password meets all requirements.');
                return;
            }
        });
    }
</script>

<?php include 'includes/footer.php'; ?>