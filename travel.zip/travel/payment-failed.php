<?php
// payment-failed.php
session_start();
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .failure-card {
            background: white;
            border-radius: 20px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .failure-header {
            background: #dc3545;
            color: white;
            padding: 30px;
            text-align: center;
        }
        .failure-body {
            padding: 30px;
        }
        .action-buttons {
            display: grid;
            gap: 15px;
            margin: 30px 0;
        }
        .btn-action {
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
        }
        .btn-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="failure-card">
        <div class="failure-header">
            <h2><i class="fas fa-times-circle"></i> Payment Failed</h2>
            <p class="mb-0">We couldn't process your payment</p>
        </div>
        
        <div class="failure-body">
            <?php if (isset($_SESSION['payment_error'])): ?>
            <div class="alert alert-danger">
                <h5><i class="fas fa-exclamation-triangle"></i> Error</h5>
                <p class="mb-0"><?php echo $_SESSION['payment_error']; ?></p>
                <?php unset($_SESSION['payment_error']); ?>
            </div>
            <?php else: ?>
            <div class="alert alert-warning">
                <h5><i class="fas fa-exclamation-circle"></i> Payment Failed</h5>
                <p class="mb-0">Your payment could not be processed. Please try again.</p>
            </div>
            <?php endif; ?>
            
            <div class="alert alert-info">
                <h5><i class="fas fa-info-circle"></i> What to do next?</h5>
                <ul class="mb-0">
                    <li>Check if you have sufficient balance</li>
                    <li>Verify your payment details</li>
                    <li>Try a different payment method</li>
                    <li>Contact your bank if issue persists</li>
                </ul>
            </div>
            
            <div class="action-buttons">
                <a href="payment.php" class="btn-action btn-primary">
                    <i class="fas fa-redo"></i> Try Payment Again
                </a>
                
                <a href="booking.php" class="btn-action btn-outline-primary">
                    <i class="fas fa-arrow-left"></i> Back to Booking
                </a>
                
                <a href="user.php" class="btn-action btn-outline-secondary">
                    <i class="fas fa-user"></i> My Dashboard
                </a>
            </div>
            
            <div class="text-center">
                <h6>Need Help?</h6>
                <p class="mb-1">
                    <i class="fas fa-phone"></i> Call: +91 9356437871
                </p>
                <p class="mb-1">
                    <i class="fas fa-envelope"></i> Email: support@srtravels.com
                </p>
                <p class="mb-0">
                    <i class="fas fa-clock"></i> 24/7 Customer Support
                </p>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>