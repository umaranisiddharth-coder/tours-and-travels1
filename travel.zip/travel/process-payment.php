<?php
require_once 'config.php';
require_once 'paytm-config.php';

// Debug: Log the session state
error_log("Process Payment - Session state: " . print_r($_SESSION, true));

// Check if user is logged in
if (!is_logged_in()) {
    $_SESSION['payment_error'] = 'Please login to continue with payment';
    header("Location: login.php");
    exit();
}

// Check if we have the required session data
if (!isset($_SESSION['selected_seats']) || !isset($_SESSION['route_id']) || !isset($_SESSION['total_amount'])) {
    $_SESSION['payment_error'] = 'Payment session expired. Please select seats again.';
    header("Location: enhanced-booking-system.php");
    exit();
}

// Check if we have payment order ID (should be set by payment.php)
if (!isset($_SESSION['paytm_order_id'])) {
    $_SESSION['payment_error'] = 'Payment order not found. Please try again.';
    header("Location: payment.php");
    exit();
}

// Get payment method from session
$payment_method = isset($_SESSION['payment_method']) ? $_SESSION['payment_method'] : 'paytm';

// Route to appropriate payment processor
switch ($payment_method) {
    case 'phonepe':
        header("Location: process-phonepay.php");
        exit();
        break;
        
    case 'razorpay':
        header("Location: process-razorpay.php");
        exit();
        break;
        
    case 'upi_qr':
        header("Location: process-upi-qr.php");
        exit();
        break;
        
    case 'gpay':
    case 'upi':
        // Redirect to UPI QR for Google Pay and generic UPI
        header("Location: process-upi-qr.php");
        exit();
        break;
        
    case 'netbanking':
        // For now, redirect to PayTM which supports net banking
        // In production, you might want a dedicated net banking processor
        break;
        
    case 'paytm':
    default:
        // Continue with PayTM processing
        break;
}

// Include PayTM library
if (!file_exists('lib_paytm.php')) {
    // Create a simple fallback if PayTM library is not available
    create_paytm_fallback();
} else {
    require_once('lib_paytm.php');
}

// Get session data
$ORDER_ID = $_SESSION['paytm_order_id'];
$CUST_ID = $_SESSION['user_id'];
$TXN_AMOUNT = $_SESSION['paytm_amount'];

// Get user details for optional parameters
$user = get_user_by_id($CUST_ID);
$user_email = $user['email'] ?? '';
$user_phone = $user['phone'] ?? '';

// Create parameter array
$paramList = array();
$paramList["MID"] = PAYTM_MERCHANT_MID;
$paramList["ORDER_ID"] = $ORDER_ID;
$paramList["CUST_ID"] = $CUST_ID;
$paramList["INDUSTRY_TYPE_ID"] = "Retail";
$paramList["CHANNEL_ID"] = "WEB";
$paramList["TXN_AMOUNT"] = number_format($TXN_AMOUNT, 2, '.', '');
$paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
$paramList["CALLBACK_URL"] = PAYTM_CALLBACK_URL;

// Optional parameters
if (!empty($user_email)) {
    $paramList["EMAIL"] = $user_email;
}

if (!empty($user_phone)) {
    $paramList["MOBILE_NO"] = $user_phone;
}

// Validate parameters
$validation = validateInputParameters($paramList);
if (!$validation['status']) {
    $_SESSION['payment_error'] = "Payment configuration error: " . $validation['message'];
    header("Location: payment-failed.php");
    exit();
}

// Log transaction attempt
logTransactionData(array(
    'type' => 'payment_initiation',
    'order_id' => $ORDER_ID,
    'user_id' => $CUST_ID,
    'amount' => $TXN_AMOUNT,
    'payment_method' => $payment_method,
    'parameters' => $paramList,
    'ip_address' => $_SERVER['REMOTE_ADDR']
));

// Generate checksum
$checkSum = getChecksumFromArray($paramList, PAYTM_MERCHANT_KEY);

// Generate payment form HTML
$actionURL = PAYTM_TXN_URL;
$html = generatePaymentFormHTML($paramList, $checkSum, $actionURL);

// Output the HTML
echo $html;

// Log successful form generation
logTransactionData(array(
    'type' => 'payment_form_generated',
    'order_id' => $ORDER_ID,
    'payment_method' => $payment_method,
    'checksum_generated' => !empty($checkSum),
    'timestamp' => date('Y-m-d H:i:s')
));

// Helper functions
function validateInputParameters($paramList) {
    $required_fields = ['MID', 'ORDER_ID', 'CUST_ID', 'TXN_AMOUNT', 'WEBSITE', 'CALLBACK_URL'];
    
    foreach ($required_fields as $field) {
        if (empty($paramList[$field])) {
            return ['status' => false, 'message' => "Missing required field: $field"];
        }
    }
    
    // Validate amount
    if (!is_numeric($paramList['TXN_AMOUNT']) || $paramList['TXN_AMOUNT'] <= 0) {
        return ['status' => false, 'message' => "Invalid transaction amount"];
    }
    
    return ['status' => true, 'message' => 'Validation successful'];
}

function logTransactionData($data) {
    // Log transaction data for debugging and audit
    if (defined('PAYMENT_TEST_MODE') && PAYMENT_TEST_MODE) {
        $log_file = __DIR__ . '/payment_transactions.log';
        $log_entry = '[' . date('Y-m-d H:i:s') . '] ' . json_encode($data) . "\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }
}

function generatePaymentFormHTML($paramList, $checkSum, $actionURL) {
    $html = '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processing Payment - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .processing-card {
            background: white;
            border-radius: 20px;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .processing-header {
            background: linear-gradient(135deg, #00baf2 0%, #1e3c72 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .processing-body {
            padding: 30px;
            text-align: center;
        }
        .spinner {
            width: 60px;
            height: 60px;
            border: 6px solid #f3f3f3;
            border-top: 6px solid #00baf2;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .payment-details {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="processing-card">
        <div class="processing-header">
            <h2><i class="fas fa-credit-card"></i> Processing Payment</h2>
            <p class="mb-0">Redirecting to secure payment gateway...</p>
        </div>
        
        <div class="processing-body">
            <div class="spinner"></div>
            <h4>Please wait</h4>
            <p class="text-muted">You will be redirected to PayTM payment gateway in a few seconds</p>
            
            <div class="payment-details">
                <h6>Payment Details:</h6>
                <p><strong>Order ID:</strong> ' . htmlspecialchars($paramList['ORDER_ID']) . '</p>
                <p><strong>Amount:</strong> ₹' . number_format($paramList['TXN_AMOUNT'], 2) . '</p>
                <p><strong>Payment Method:</strong> ' . ucfirst($_SESSION['payment_method'] ?? 'PayTM') . '</p>
            </div>
            
            <div class="alert alert-info">
                <small>
                    <i class="fas fa-info-circle"></i>
                    If you are not redirected automatically, click the button below
                </small>
            </div>
            
            <form method="post" action="' . $actionURL . '" name="paytm_form" id="paytm_form">';
    
    foreach($paramList as $name => $value) {
        $html .= '<input type="hidden" name="' . $name . '" value="' . $value . '">';
    }
    
    $html .= '<input type="hidden" name="CHECKSUMHASH" value="' . $checkSum . '">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-arrow-right me-2"></i>
                    Continue to PayTM
                </button>
            </form>
        </div>
    </div>

    <script>
        // Auto-submit form after 3 seconds
        setTimeout(function() {
            document.getElementById("paytm_form").submit();
        }, 3000);
        
        // Track payment initiation
        fetch("ajax-handler.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: "action=log_payment_initiation&order_id=" + encodeURIComponent("' . $paramList['ORDER_ID'] . '")
        });
        
        // Handle visibility change
        document.addEventListener("visibilitychange", function() {
            if (document.hidden) {
                console.log("User switched tabs during payment - payment still processing");
            }
        });
        
        // Prevent accidental navigation
        window.addEventListener("beforeunload", function(e) {
            const confirmationMessage = "Payment is in progress. Are you sure you want to leave?";
            e.returnValue = confirmationMessage;
            return confirmationMessage;
        });
    </script>
</body>
</html>';
    
    return $html;
}

function create_paytm_fallback() {
    // Create a basic fallback file if PayTM library is missing
    $fallback_content = '<?php
// Basic PayTM fallback functions
function getChecksumFromArray($paramList, $key) {
    return hash("sha256", json_encode($paramList) . $key);
}

function verifychecksum_e($paramList, $key, $checksum) {
    $expected = hash("sha256", json_encode($paramList) . $key);
    return hash_equals($expected, $checksum) ? "TRUE" : "FALSE";
}
?>';
    
    file_put_contents('encdec_paytm.php', $fallback_content);
}
?>

<!-- Alternative simple fallback form -->
<noscript>
    <div style="text-align: center; padding: 50px;">
        <h3>JavaScript is required for payment processing</h3>
        <p>Please enable JavaScript in your browser or click the button below to proceed manually.</p>
        <form method="post" action="<?php echo PAYTM_TXN_URL; ?>" name="paytm_form_noscript">
            <?php
            foreach($paramList as $name => $value) {
                echo '<input type="hidden" name="' . $name . '" value="' . $value . '">';
            }
            ?>
            <input type="hidden" name="CHECKSUMHASH" value="<?php echo $checkSum; ?>">
            <button type="submit" style="background: #2a6ebb; color: white; padding: 15px 30px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer;">
                Proceed to PayTM Payment
            </button>
        </form>
    </div>
</noscript>

<script>
// Additional JavaScript for payment processing
document.addEventListener('DOMContentLoaded', function() {
    // Track payment initiation
    fetch('ajax-handler.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'action=log_payment_initiation&order_id=' + encodeURIComponent('<?php echo $ORDER_ID; ?>')
    });
    
    // Show loading message
    const container = document.querySelector('.container');
    if (container) {
        const originalHTML = container.innerHTML;
        container.innerHTML = originalHTML + 
            '<div class="mt-4">' +
            '   <p><strong>Payment Details:</strong></p>' +
            '   <p>Order ID: <?php echo $ORDER_ID; ?></p>' +
            '   <p>Amount: ₹<?php echo number_format($TXN_AMOUNT, 2); ?></p>' +
            '   <p>Customer ID: <?php echo $CUST_ID; ?></p>' +
            '</div>';
    }
    
    // Auto-submit form after 2 seconds
    setTimeout(function() {
        const form = document.forms['paytm_form'];
        if (form) {
            form.submit();
        } else {
            // Fallback to noscript form
            const noscriptForm = document.forms['paytm_form_noscript'];
            if (noscriptForm) {
                noscriptForm.submit();
            }
        }
    }, 2000);
});

// Handle visibility change (if user switches tabs)
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        console.log('User switched tabs during payment - payment still processing');
    }
});

// Prevent accidental navigation
window.addEventListener('beforeunload', function(e) {
    // Only show warning if payment is still processing
    const confirmationMessage = 'Payment is in progress. Are you sure you want to leave?';
    e.returnValue = confirmationMessage;
    return confirmationMessage;
});
</script>