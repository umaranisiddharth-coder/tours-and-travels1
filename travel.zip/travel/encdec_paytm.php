<?php
/**
 * PayTM Encryption/Decryption Library
 * SR Travels - Payment Gateway Integration
 */

class PaytmHelper {
    
    /**
     * Generate checksum for PayTM transaction
     */
    public static function getChecksumFromArray($paramList, $key) {
        ksort($paramList);
        $arrayStr = self::getArray2Str($paramList);
        $salt = self::generateSalt_e(4);
        $finalString = $arrayStr . "|" . $salt;
        $hash = hash("sha256", $finalString);
        $hashString = $hash . $salt;
        $checksum = self::encrypt_e($hashString, $key);
        return $checksum;
    }
    
    /**
     * Verify checksum for PayTM response
     */
    public static function verifychecksum_e($paramList, $key, $checksum) {
        $paytm_hash = self::decrypt_e($checksum, $key);
        $salt = substr($paytm_hash, -4);
        $finalString = self::getArray2StrForVerify($paramList) . "|" . $salt;
        $website_hash = hash("sha256", $finalString);
        $website_hash .= $salt;
        
        $validFlag = "FALSE";
        if($website_hash == $paytm_hash) {
            $validFlag = "TRUE";
        } else {
            $validFlag = "FALSE";
        }
        return $validFlag;
    }
    
    /**
     * Generate salt for encryption
     */
    private static function generateSalt_e($length) {
        $random = "";
        srand((double) microtime() * 1000000);
        $data = "AbcDE123IJKLMN67QRSTUVWXYZ";
        $data .= "aBCdefghijklmn123opq45rs67tuv89wxyz";
        $data .= "0FGH45OP89";
        
        for($i = 0; $i < $length; $i++) {
            $random .= substr($data, (rand() % (strlen($data))), 1);
        }
        
        return $random;
    }
    
    /**
     * Encrypt data
     */
    private static function encrypt_e($input, $ky) {
        $key = html_entity_decode($ky);
        $iv = "@@@@&&&&####$$$$";
        $data = openssl_encrypt($input, "AES-128-CBC", $key, 0, $iv);
        return $data;
    }
    
    /**
     * Decrypt data
     */
    private static function decrypt_e($crypt, $ky) {
        $key = html_entity_decode($ky);
        $iv = "@@@@&&&&####$$$$";
        $data = openssl_decrypt($crypt, "AES-128-CBC", $key, 0, $iv);
        return $data;
    }
    
    /**
     * Convert array to string for checksum generation
     */
    private static function getArray2Str($arrayList) {
        $findme = 'REFUND';
        $findmepipe = '|';
        $paramStr = "";
        $flag = 1;
        
        foreach($arrayList as $key => $value) {
            $pos = strpos($value, $findme);
            $pospipe = strpos($value, $findmepipe);
            
            if($pos !== false || $pospipe !== false) {
                continue;
            }
            
            if($flag) {
                $paramStr .= self::checkString_e($value);
                $flag = 0;
            } else {
                $paramStr .= "|" . self::checkString_e($value);
            }
        }
        return $paramStr;
    }
    
    /**
     * Convert array to string for verification
     */
    private static function getArray2StrForVerify($arrayList) {
        $paramStr = "";
        $flag = 1;
        
        foreach($arrayList as $key => $value) {
            if($flag) {
                $paramStr .= self::checkString_e($value);
                $flag = 0;
            } else {
                $paramStr .= "|" . self::checkString_e($value);
            }
        }
        return $paramStr;
    }
    
    /**
     * Check and clean string
     */
    private static function checkString_e($value) {
        $myvalue = ltrim($value);
        $myvalue = rtrim($myvalue);
        
        if($myvalue == 'null') {
            $myvalue = '';
        }
        
        return $myvalue;
    }
    
    /**
     * Generate transaction token (for newer PayTM API)
     */
    public static function generateTransactionToken($paramList, $key) {
        $checksum = self::getChecksumFromArray($paramList, $key);
        return $checksum;
    }
    
    /**
     * Validate PayTM response
     */
    public static function validatePaytmResponse($response, $key) {
        if (!isset($response['CHECKSUMHASH'])) {
            return false;
        }
        
        $checksum = $response['CHECKSUMHASH'];
        unset($response['CHECKSUMHASH']);
        
        $isValidChecksum = self::verifychecksum_e($response, $key, $checksum);
        return ($isValidChecksum === "TRUE");
    }
}

// Backward compatibility functions
function getChecksumFromArray($paramList, $key) {
    return PaytmHelper::getChecksumFromArray($paramList, $key);
}

function verifychecksum_e($paramList, $key, $checksum) {
    return PaytmHelper::verifychecksum_e($paramList, $key, $checksum);
}

function generateTransactionToken($paramList, $key) {
    return PaytmHelper::generateTransactionToken($paramList, $key);
}

function validatePaytmResponse($response, $key) {
    return PaytmHelper::validatePaytmResponse($response, $key);
}
?>