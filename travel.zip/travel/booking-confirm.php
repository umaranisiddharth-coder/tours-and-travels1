<?php
require_once 'config.php';
require_once 'paytm-config.php';

if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Check if coming from successful payment
if (!isset($_SESSION['payment_success']) && !isset($_GET['booking_id'])) {
    header("Location: booking.php");
    exit();
}

$booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : $_SESSION['last_booking_id'];
$user_id = $_SESSION['user_id'];

// Clear payment success flag if set
if (isset($_SESSION['payment_success'])) {
    unset($_SESSION['payment_success']);
}

// Get booking details with complete information
$query = "SELECT 
            b.*, 
            r.from_city, r.to_city, r.departure_time, r.arrival_time, r.duration, r.fare,
            bus.bus_name, bus.bus_number, bus.bus_type, bus.amenities,
            u.full_name, u.email, u.phone,
            p.transaction_id, p.payment_method, p.payment_date, p.bank_name, p.bank_txn_id, p.payment_gateway,
            sa.seat_type
          FROM bookings b
          JOIN bus_routes r ON b.route_id = r.id
          JOIN buses bus ON b.bus_id = bus.id
          JOIN users u ON b.user_id = u.id
          LEFT JOIN payments p ON b.id = p.booking_id
          LEFT JOIN seat_availability sa ON b.id = sa.booking_id
          WHERE b.id = $booking_id AND b.user_id = $user_id
          GROUP BY b.id";

$result = mysqli_query($conn, $query);
$booking = mysqli_fetch_assoc($result);

if (!$booking) {
    $_SESSION['error'] = 'Booking not found or you do not have permission to view it.';
    header("Location: user.php");
    exit();
}

// Generate QR code data for e-ticket
$qr_data = "SR TRAVELS\nBooking ID: " . $booking['booking_id'] . "\nPassenger: " . $booking['full_name'] . "\nRoute: " . $booking['from_city'] . " to " . $booking['to_city'] . "\nDate: " . format_date($booking['travel_date']) . "\nTime: " . format_time($booking['departure_time']) . "\nSeats: " . $booking['seats_booked'];

// Send confirmation email (in real app, this would be queued)
function send_booking_confirmation_email($booking) {
    $to = $booking['email'];
    $subject = "Booking Confirmed - " . $booking['booking_id'] . " - SR Travels";
    
    $message = '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2a6ebb; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 20px; border-radius: 5px; }
            .footer { margin-top: 20px; text-align: center; color: #666; font-size: 12px; }
            .ticket { border: 2px solid #2a6ebb; padding: 20px; margin: 20px 0; background: white; }
            .highlight { color: #2a6ebb; font-weight: bold; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>SR TRAVELS</h2>
                <h3>Booking Confirmed!</h3>
            </div>
            <div class="content">
                <p>Dear ' . $booking['full_name'] . ',</p>
                <p>Your booking has been confirmed. Here are your booking details:</p>
                
                <div class="ticket">
                    <h4>E-TICKET</h4>
                    <p><strong>Booking ID:</strong> <span class="highlight">' . $booking['booking_id'] . '</span></p>
                    <p><strong>Route:</strong> ' . $booking['from_city'] . ' to ' . $booking['to_city'] . '</p>
                    <p><strong>Travel Date:</strong> ' . format_date($booking['travel_date']) . '</p>
                    <p><strong>Departure Time:</strong> ' . format_time($booking['departure_time']) . '</p>
                    <p><strong>Bus:</strong> ' . $booking['bus_name'] . ' (' . $booking['bus_number'] . ')</p>
                    <p><strong>Seats:</strong> ' . $booking['seats_booked'] . '</p>
                    <p><strong>Total Amount:</strong> ₹' . $booking['total_amount'] . '</p>
                    <p><strong>Payment Method:</strong> ' . strtoupper($booking['payment_method']) . '</p>
                </div>
                
                <h4>Important Information:</h4>
                <ul>
                    <li>Please arrive at the boarding point 30 minutes before departure</li>
                    <li>Carry a valid government-issued ID proof</li>
                    <li>Show this e-ticket or booking ID at the boarding point</li>
                    <li>For bus tracking, visit: ' . SITE_URL . '/bus-tracking.php</li>
                </ul>
                
                <p>Thank you for choosing SR Travels!</p>
            </div>
            <div class="footer">
                <p>SR Travels Customer Support: +91 9356437871 | support@srtravels.com</p>
                <p>This is an automated email. Please do not reply.</p>
            </div>
        </div>
    </body>
    </html>';
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: SR Travels <" . PAYMENT_RECEIPT_FROM_EMAIL . ">" . "\r\n";
    $headers .= "Reply-To: " . PAYMENT_RECEIPT_FROM_EMAIL . "\r\n";
    
    return mail($to, $subject, $message, $headers);
}

// Send email in background (for better user experience)
if (!isset($_SESSION['email_sent_' . $booking_id])) {
    // In production, queue this email
    // For now, we'll just mark it as sent to prevent multiple emails
    $_SESSION['email_sent_' . $booking_id] = true;
    // Uncomment to actually send email:
    // send_booking_confirmation_email($booking);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmed - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <style>
        .confirmation-card {
            border: 3px solid #28a745;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(40, 167, 69, 0.2);
            overflow: hidden;
        }
        
        .ticket-header {
            background: linear-gradient(135deg, #2a6ebb, #28a745);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .ticket-body {
            padding: 30px;
            background: #f8f9fa;
        }
        
        .ticket-details {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .qr-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        #qrcode {
            margin: 0 auto;
            padding: 10px;
            background: white;
            display: inline-block;
        }
        
        .status-badge {
            font-size: 0.9rem;
            padding: 8px 15px;
            border-radius: 20px;
        }
        
        .print-only {
            display: none;
        }
        
        @media print {
            .no-print {
                display: none !important;
            }
            
            .print-only {
                display: block !important;
            }
            
            .ticket-details, .qr-container {
                box-shadow: none;
                border: 1px solid #ddd;
            }
            
            body {
                background: white !important;
                color: black !important;
            }
        }
        
        .timeline {
            position: relative;
            padding-left: 30px;
            margin: 20px 0;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #2a6ebb;
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -34px;
            top: 0;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: #2a6ebb;
            border: 3px solid white;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-light bg-white shadow-sm no-print">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="index.php">
                <i class="fas fa-bus me-2"></i>SR<span class="text-warning">TRAVELS</span>
            </a>
            <div class="d-flex align-items-center">
                <span class="me-3">Welcome, <?php echo $_SESSION['full_name']; ?></span>
                <a href="user.php" class="btn btn-outline-primary btn-sm me-2">
                    <i class="fas fa-user me-1"></i> Dashboard
                </a>
                <button onclick="printTicket()" class="btn btn-primary btn-sm">
                    <i class="fas fa-print me-1"></i> Print
                </button>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <!-- Success Alert -->
                <div class="alert alert-success alert-dismissible fade show no-print" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-check-circle fa-2x me-3"></i>
                        <div>
                            <h4 class="alert-heading mb-1">Booking Confirmed Successfully!</h4>
                            <p class="mb-0">Your booking has been confirmed. An e-ticket has been sent to <?php echo $booking['email']; ?></p>
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>

                <!-- E-Ticket Card -->
                <div class="confirmation-card">
                    <!-- Ticket Header -->
                    <div class="ticket-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="text-start">
                                <h1 class="mb-0"><i class="fas fa-bus"></i> SR TRAVELS</h1>
                                <p class="mb-0">Travel with Comfort & Safety</p>
                            </div>
                            <div class="text-end">
                                <h2 class="mb-0">E-TICKET</h2>
                                <p class="mb-0">Valid for Travel</p>
                            </div>
                        </div>
                    </div>

                    <!-- Ticket Body -->
                    <div class="ticket-body">
                        <div class="row">
                            <!-- Left Column: Journey Details -->
                            <div class="col-lg-8">
                                <!-- Booking Information -->
                                <div class="ticket-details">
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <h5 class="text-primary mb-3">
                                                <i class="fas fa-route me-2"></i> Journey Details
                                            </h5>
                                            <p class="mb-2"><strong>From:</strong> <?php echo $booking['from_city']; ?></p>
                                            <p class="mb-2"><strong>To:</strong> <?php echo $booking['to_city']; ?></p>
                                            <p class="mb-2"><strong>Date:</strong> <?php echo format_date($booking['travel_date']); ?></p>
                                            <p class="mb-2"><strong>Time:</strong> <?php echo format_time($booking['departure_time']); ?></p>
                                            <p class="mb-0"><strong>Duration:</strong> <?php echo $booking['duration']; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <h5 class="text-primary mb-3">
                                                <i class="fas fa-user me-2"></i> Passenger Details
                                            </h5>
                                            <p class="mb-2"><strong>Name:</strong> <?php echo $booking['full_name']; ?></p>
                                            <p class="mb-2"><strong>Email:</strong> <?php echo $booking['email']; ?></p>
                                            <p class="mb-2"><strong>Phone:</strong> <?php echo $booking['phone']; ?></p>
                                            <p class="mb-2"><strong>Seats:</strong> <?php echo $booking['seats_booked']; ?></p>
                                            <p class="mb-0"><strong>Bus Type:</strong> <?php echo ucfirst($booking['bus_type']); ?></p>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <h5 class="text-primary mb-3">
                                                <i class="fas fa-bus me-2"></i> Bus Details
                                            </h5>
                                            <p class="mb-2"><strong>Bus Name:</strong> <?php echo $booking['bus_name']; ?></p>
                                            <p class="mb-2"><strong>Bus Number:</strong> <?php echo $booking['bus_number']; ?></p>
                                            <p class="mb-0"><strong>Amenities:</strong> <?php echo $booking['amenities']; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <h5 class="text-primary mb-3">
                                                <i class="fas fa-rupee-sign me-2"></i> Payment Details
                                            </h5>
                                            <p class="mb-2"><strong>Booking ID:</strong> <span class="badge bg-dark"><?php echo $booking['booking_id']; ?></span></p>
                                            <p class="mb-2"><strong>Total Amount:</strong> ₹<?php echo $booking['total_amount']; ?></p>
                                            <p class="mb-2"><strong>Payment Method:</strong> <?php echo strtoupper($booking['payment_method']); ?></p>
                                            <?php if($booking['transaction_id']): ?>
                                            <p class="mb-2"><strong>Transaction ID:</strong> <?php echo $booking['transaction_id']; ?></p>
                                            <?php endif; ?>
                                            <p class="mb-0"><strong>Booking Date:</strong> <?php echo format_date($booking['booking_date']) . ' ' . format_time($booking['booking_date']); ?></p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Journey Timeline -->
                                <div class="ticket-details">
                                    <h5 class="text-primary mb-4">
                                        <i class="fas fa-map-marked-alt me-2"></i> Journey Timeline
                                    </h5>
                                    <div class="timeline">
                                        <div class="timeline-item">
                                            <h6>Boarding</h6>
                                            <p class="mb-1">Report to boarding point 30 minutes before departure</p>
                                            <small class="text-muted">Carry valid ID proof and this e-ticket</small>
                                        </div>
                                        <div class="timeline-item">
                                            <h6>Departure</h6>
                                            <p class="mb-1"><?php echo format_time($booking['departure_time']); ?> from <?php echo $booking['from_city']; ?></p>
                                        </div>
                                        <div class="timeline-item">
                                            <h6>Journey</h6>
                                            <p class="mb-1">Approx. <?php echo $booking['duration']; ?> journey time</p>
                                        </div>
                                        <div class="timeline-item">
                                            <h6>Arrival</h6>
                                            <p class="mb-1">ETA: <?php echo format_time($booking['arrival_time']); ?> at <?php echo $booking['to_city']; ?></p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Important Instructions -->
                                <div class="ticket-details">
                                    <h5 class="text-primary mb-3">
                                        <i class="fas fa-exclamation-circle me-2"></i> Important Instructions
                                    </h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <ul class="mb-0">
                                                <li>Carry valid photo ID proof</li>
                                                <li>Arrive 30 minutes before departure</li>
                                                <li>Check luggage restrictions</li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6">
                                            <ul class="mb-0">
                                                <li>No smoking or alcohol allowed</li>
                                                <li>Follow COVID-19 guidelines</li>
                                                <li>Keep this e-ticket handy</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Right Column: QR Code & Actions -->
                            <div class="col-lg-4">
                                <!-- QR Code -->
                                <div class="qr-container mb-4">
                                    <h5 class="text-primary mb-3">
                                        <i class="fas fa-qrcode me-2"></i> Digital Ticket
                                    </h5>
                                    <div id="qrcode"></div>
                                    <p class="mt-3 mb-0 text-muted">
                                        <small>Scan this QR code at boarding point</small>
                                    </p>
                                </div>

                                <!-- Status & Actions -->
                                <div class="qr-container">
                                    <h5 class="text-primary mb-3">
                                        <i class="fas fa-info-circle me-2"></i> Status & Actions
                                    </h5>
                                    
                                    <!-- Booking Status -->
                                    <div class="mb-3">
                                        <p class="mb-1"><strong>Booking Status:</strong></p>
                                        <span class="badge bg-success status-badge">
                                            <?php echo strtoupper($booking['booking_status']); ?>
                                        </span>
                                    </div>
                                    
                                    <!-- Payment Status -->
                                    <div class="mb-3">
                                        <p class="mb-1"><strong>Payment Status:</strong></p>
                                        <span class="badge bg-success status-badge">
                                            <?php echo strtoupper($booking['payment_status']); ?>
                                        </span>
                                    </div>

                                    <!-- Action Buttons -->
                                    <div class="d-grid gap-2">
                                        <a href="bus-tracking.php?booking_id=<?php echo $booking['booking_id']; ?>" 
                                           class="btn btn-primary">
                                            <i class="fas fa-map-marker-alt me-2"></i> Track Bus
                                        </a>
                                        <button onclick="downloadTicket()" class="btn btn-outline-primary">
                                            <i class="fas fa-download me-2"></i> Download Ticket
                                        </button>
                                        <a href="user.php" class="btn btn-outline-secondary">
                                            <i class="fas fa-list me-2"></i> My Bookings
                                        </a>
                                        <?php if($booking['booking_status'] == 'confirmed'): ?>
                                        <button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#cancelModal">
                                            <i class="fas fa-times me-2"></i> Cancel Booking
                                        </button>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Support Information -->
                                    <div class="mt-4 pt-3 border-top">
                                        <h6><i class="fas fa-headset me-2"></i> Need Help?</h6>
                                        <p class="mb-1 small">Call: +91 9356437871</p>
                                        <p class="mb-1 small">Email: support@srtravels.com</p>
                                        <p class="mb-0 small">24/7 Customer Support</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Footer Actions -->
                        <div class="row mt-4 no-print">
                            <div class="col-12">
                                <div class="d-flex justify-content-center gap-3">
                                    <button onclick="printTicket()" class="btn btn-primary px-4">
                                        <i class="fas fa-print me-2"></i> Print Ticket
                                    </button>
                                    <button onclick="shareTicket()" class="btn btn-outline-primary px-4">
                                        <i class="fas fa-share-alt me-2"></i> Share
                                    </button>
                                    <a href="index.php" class="btn btn-outline-secondary px-4">
                                        <i class="fas fa-home me-2"></i> Home
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Booking Timeline (Print Only) -->
                <div class="print-only mt-4">
                    <div class="ticket-details">
                        <h5>Booking Timeline</h5>
                        <p><strong>Booked On:</strong> <?php echo format_date($booking['booking_date']) . ' ' . format_time($booking['booking_date']); ?></p>
                        <p><strong>Travel Date:</strong> <?php echo format_date($booking['travel_date']); ?></p>
                        <p><strong>Payment Date:</strong> <?php echo format_date($booking['payment_date']) . ' ' . format_time($booking['payment_date']); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Cancel Booking Modal -->
    <div class="modal fade" id="cancelModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cancel Booking</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to cancel booking <strong><?php echo $booking['booking_id']; ?></strong>?</p>
                    <p class="text-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Cancellation charges may apply as per our cancellation policy.
                    </p>
                    <div class="mb-3">
                        <label class="form-label">Cancellation Reason (Optional)</label>
                        <textarea class="form-control" id="cancelReason" rows="3" placeholder="Please specify reason for cancellation"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, Keep Booking</button>
                    <button type="button" class="btn btn-danger" onclick="cancelBooking()">Yes, Cancel Booking</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Generate QR Code
        const qrData = `<?php echo addslashes($qr_data); ?>`;
        QRCode.toCanvas(document.getElementById('qrcode'), qrData, {
            width: 180,
            margin: 1,
            color: {
                dark: '#2a6ebb',
                light: '#ffffff'
            }
        }, function (error) {
            if (error) console.error(error);
        });

        // Print Ticket
        function printTicket() {
            window.print();
        }

        // Download Ticket as PDF
        function downloadTicket() {
            // In a real app, this would generate a PDF
            alert('Ticket download feature will be available soon!');
            // You can implement PDF generation using jsPDF or server-side PDF generation
        }

        // Share Ticket
        function shareTicket() {
            if (navigator.share) {
                navigator.share({
                    title: 'My SR Travels Ticket - <?php echo $booking['booking_id']; ?>',
                    text: 'Check out my bus ticket for <?php echo $booking['from_city']; ?> to <?php echo $booking['to_city']; ?> on <?php echo format_date($booking['travel_date']); ?>',
                    url: window.location.href
                })
                .then(() => console.log('Ticket shared successfully'))
                .catch((error) => console.log('Error sharing:', error));
            } else {
                // Fallback: Copy to clipboard
                const shareUrl = window.location.href;
                navigator.clipboard.writeText(shareUrl).then(() => {
                    alert('Ticket link copied to clipboard!');
                });
            }
        }

        // Cancel Booking
        function cancelBooking() {
            const reason = document.getElementById('cancelReason').value;
            
            if (confirm('Are you sure you want to cancel this booking? This action cannot be undone.')) {
                // Send AJAX request to cancel booking
                const formData = new FormData();
                formData.append('booking_id', <?php echo $booking_id; ?>);
                formData.append('reason', reason);
                formData.append('action', 'cancel_booking');
                
                fetch('ajax-handler.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Booking cancelled successfully!');
                        window.location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Error cancelling booking. Please try again.');
                });
            }
        }

        // Auto-refresh for status updates (every 30 seconds)
        setInterval(() => {
            // Check for status updates
            fetch(`ajax-handler.php?action=check_booking_status&booking_id=<?php echo $booking_id; ?>`)
                .then(response => response.json())
                .then(data => {
                    if (data.status_changed) {
                        // Update status on page
                        document.querySelector('.badge.bg-success').textContent = data.new_status.toUpperCase();
                    }
                });
        }, 30000);

        // Show notification when page is printed
        window.addEventListener('afterprint', () => {
            alert('Ticket printed successfully! Please keep a copy with you during travel.');
        });
    </script>
</body>
</html>