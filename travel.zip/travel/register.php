<?php
require_once 'config.php';

// Page configuration
$page_title = 'Create Your Account';
$page_description = 'Join SR Travels and start booking your bus tickets with ease';

// Redirect if already logged in
if (is_logged_in()) {
    if (is_admin()) {
        header("Location: admin-dashboard-enhanced.php");
    } else {
        header("Location: user-dashboard-enhanced.php");
    }
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = sanitize_input($_POST['full_name']);
    $phone = sanitize_input($_POST['phone']);
    
    // Enhanced validation
    if (empty($username) || empty($email) || empty($password) || empty($full_name)) {
        $error = 'All required fields must be filled.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif ($phone && !preg_match('/^[0-9]{10}$/', $phone)) {
        $error = 'Please enter a valid 10-digit phone number.';
    } else {
        // Check password strength
        $password_errors = check_password_strength($password);
        if (!empty($password_errors)) {
            $error = implode('<br>', $password_errors);
        } else {
            // Check if username or email already exists using prepared statements
            $check_query = "SELECT id FROM users WHERE username = ? OR email = ?";
            $stmt = mysqli_prepare($conn, $check_query);
            mysqli_stmt_bind_param($stmt, "ss", $username, $email);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if (mysqli_num_rows($result) > 0) {
                $error = 'Username or email already exists. Please choose different ones.';
            } else {
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert user with prepared statement
                $insert_query = "INSERT INTO users (username, email, password, full_name, phone, user_type, created_at) 
                               VALUES (?, ?, ?, ?, ?, 'user', NOW())";
                $stmt = mysqli_prepare($conn, $insert_query);
                mysqli_stmt_bind_param($stmt, "sssss", $username, $email, $hashed_password, $full_name, $phone);
                
                if (mysqli_stmt_execute($stmt)) {
                    $success = 'Registration successful! You can now login with your credentials.';
                    
                    // Optional: Auto-login the user
                    $user_id = mysqli_insert_id($conn);
                    $_SESSION['user_id'] = $user_id;
                    $_SESSION['user_type'] = 'user';
                    $_SESSION['full_name'] = $full_name;
                    $_SESSION['email'] = $email;
                    
                    // Redirect after 2 seconds
                    header("refresh:2;url=user-dashboard-enhanced.php");
                } else {
                    $error = 'Registration failed. Please try again later.';
                }
            }
        }
    }
}

// Custom CSS for RedBus-inspired design
$custom_css = "
    body {
        background: linear-gradient(135deg, #d32f2f 0%, #f44336 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .register-wrapper {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    .register-container {
        background: white;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        overflow: hidden;
        max-width: 1000px;
        width: 100%;
        display: grid;
        grid-template-columns: 1fr 1.2fr;
        min-height: 600px;
    }
    
    .register-left {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        color: white;
        padding: 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }
    
    .register-left::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><circle cx=\"20\" cy=\"20\" r=\"2\" fill=\"rgba(255,255,255,0.1)\"/><circle cx=\"80\" cy=\"80\" r=\"3\" fill=\"rgba(255,255,255,0.1)\"/><circle cx=\"40\" cy=\"60\" r=\"1\" fill=\"rgba(255,255,255,0.1)\"/></svg>');
        background-size: 100px 100px;
    }
    
    .register-brand {
        position: relative;
        z-index: 2;
    }
    
    .brand-logo {
        font-size: 3rem;
        font-weight: 800;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .brand-logo i {
        background: rgba(255,255,255,0.2);
        padding: 15px;
        border-radius: 15px;
        font-size: 2rem;
    }
    
    .brand-tagline {
        font-size: 1.2rem;
        opacity: 0.9;
        margin-bottom: 30px;
        line-height: 1.6;
    }
    
    .benefits-list {
        list-style: none;
        padding: 0;
    }
    
    .benefits-list li {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
        font-size: 1rem;
        opacity: 0.9;
    }
    
    .benefits-list i {
        margin-right: 12px;
        width: 20px;
        color: #ffeb3b;
    }
    
    .register-right {
        padding: 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
    
    .register-header {
        text-align: center;
        margin-bottom: 30px;
    }
    
    .register-title {
        font-size: 2rem;
        font-weight: 700;
        color: #333;
        margin-bottom: 10px;
    }
    
    .register-subtitle {
        color: #666;
        font-size: 1rem;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #333;
        font-size: 0.9rem;
    }
    
    .form-control {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        font-size: 0.95rem;
        transition: all 0.3s ease;
        background: #fafafa;
    }
    
    .form-control:focus {
        outline: none;
        border-color: #d32f2f;
        background: white;
        box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.1);
    }
    
    .btn-register {
        width: 100%;
        padding: 15px;
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        color: white;
        border: none;
        border-radius: 10px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-bottom: 20px;
    }
    
    .btn-register:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(211, 47, 47, 0.3);
    }
    
    .btn-register:active {
        transform: translateY(0);
    }
    
    .divider {
        text-align: center;
        margin: 25px 0;
        position: relative;
    }
    
    .divider::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 0;
        right: 0;
        height: 1px;
        background: #e0e0e0;
    }
    
    .divider span {
        background: white;
        padding: 0 20px;
        color: #999;
        font-size: 0.9rem;
    }
    
    .login-link {
        text-align: center;
        padding-top: 20px;
        border-top: 1px solid #e0e0e0;
    }
    
    .login-link a {
        color: #d32f2f;
        text-decoration: none;
        font-weight: 600;
    }
    
    .login-link a:hover {
        text-decoration: underline;
    }
    
    .alert {
        padding: 12px 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-size: 0.9rem;
    }
    
    .alert-danger {
        background: #ffebee;
        color: #c62828;
        border: 1px solid #ffcdd2;
    }
    
    .alert-success {
        background: #e8f5e8;
        color: #2e7d32;
        border: 1px solid #c8e6c9;
    }
    
    .password-strength {
        font-size: 0.8rem;
        margin-top: 5px;
        color: #666;
    }
    
    @media (max-width: 768px) {
        .register-container {
            grid-template-columns: 1fr;
            margin: 10px;
        }
        
        .register-left {
            padding: 30px 20px;
            text-align: center;
        }
        
        .register-right {
            padding: 30px 20px;
        }
        
        .brand-logo {
            font-size: 2.5rem;
            justify-content: center;
        }
        
        .register-title {
            font-size: 1.8rem;
        }
    }
";

// Don't show page header for register
$show_page_header = false;

// Include header
include 'includes/header.php';
?>

<div class="register-wrapper">
    <div class="register-container" data-aos="fade-up">
        <!-- Left Side - Branding -->
        <div class="register-left">
            <div class="register-brand">
                <div class="brand-logo">
                    <i class="fas fa-bus"></i>
                    <span>SR TRAVELS</span>
                </div>
                <div class="brand-tagline">
                    Join thousands of happy travelers and experience the best bus booking platform in India.
                </div>
                <ul class="benefits-list">
                    <li><i class="fas fa-gift"></i> Exclusive Member Discounts</li>
                    <li><i class="fas fa-clock"></i> Quick & Easy Booking</li>
                    <li><i class="fas fa-shield-alt"></i> Secure Payment Options</li>
                    <li><i class="fas fa-headset"></i> 24/7 Customer Support</li>
                    <li><i class="fas fa-mobile-alt"></i> Mobile Tickets & Tracking</li>
                    <li><i class="fas fa-star"></i> Earn Reward Points</li>
                </ul>
            </div>
        </div>
        
        <!-- Right Side - Registration Form -->
        <div class="register-right">
            <div class="register-header">
                <h1 class="register-title">Create Account</h1>
                <p class="register-subtitle">Join SR Travels family today</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    <br><small>Redirecting to dashboard...</small>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="full_name">Full Name *</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   placeholder="Enter your full name" required 
                                   value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="username">Username *</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   placeholder="Choose a username" required 
                                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="email">Email Address *</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="Enter your email address" required 
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="phone">Phone Number</label>
                    <input type="tel" class="form-control" id="phone" name="phone" 
                           placeholder="Enter 10-digit mobile number" 
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="password">Password *</label>
                            <input type="password" class="form-control" id="password" name="password" 
                                   placeholder="Create a strong password" required>
                            <div class="password-strength">
                                Must be 8+ characters with uppercase, lowercase, number & special character
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="confirm_password">Confirm Password *</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                   placeholder="Confirm your password" required>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn-register">
                    <i class="fas fa-user-plus me-2"></i>Create My Account
                </button>
            </form>
            
            <div class="divider">
                <span>Already have an account?</span>
            </div>
            
            <div class="login-link">
                <p>Ready to travel? 
                    <a href="login.php">Sign In to Your Account</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>