    <!-- Enhanced Footer -->
    <footer class="footer" style="background: linear-gradient(135deg, #1a365d, #2d3748); color: white; padding: 80px 0 30px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="footer-brand" style="font-size: 2rem; font-weight: 800; margin-bottom: 20px; background: linear-gradient(135deg, var(--accent-color), #ffd700); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">
                        <i class="fas fa-bus me-2"></i>SR TRAVELS
                    </div>
                    <p class="mb-4">
                        India's most trusted bus booking platform with safe, comfortable, and affordable travel across the country.
                    </p>
                    <div class="social-icons">
                        <a href="#" title="Facebook" style="display: inline-flex; align-items: center; justify-content: center; width: 45px; height: 45px; border-radius: 50%; background: rgba(255, 255, 255, 0.1); color: white; text-decoration: none; margin-right: 15px; transition: all 0.3s ease;">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" title="Twitter" style="display: inline-flex; align-items: center; justify-content: center; width: 45px; height: 45px; border-radius: 50%; background: rgba(255, 255, 255, 0.1); color: white; text-decoration: none; margin-right: 15px; transition: all 0.3s ease;">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" title="Instagram" style="display: inline-flex; align-items: center; justify-content: center; width: 45px; height: 45px; border-radius: 50%; background: rgba(255, 255, 255, 0.1); color: white; text-decoration: none; margin-right: 15px; transition: all 0.3s ease;">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" title="LinkedIn" style="display: inline-flex; align-items: center; justify-content: center; width: 45px; height: 45px; border-radius: 50%; background: rgba(255, 255, 255, 0.1); color: white; text-decoration: none; margin-right: 15px; transition: all 0.3s ease;">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" title="YouTube" style="display: inline-flex; align-items: center; justify-content: center; width: 45px; height: 45px; border-radius: 50%; background: rgba(255, 255, 255, 0.1); color: white; text-decoration: none; margin-right: 15px; transition: all 0.3s ease;">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5 class="mb-4">Quick Links</h5>
                    <div class="footer-links">
                        <a href="index.php" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Home</a>
                        <a href="enhanced-booking-system.php" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Book Bus</a>
                        <a href="bus-tracking.php" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Track Bus</a>
                        <a href="#about" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">About Us</a>
                        <a href="#contact" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Contact</a>
                        <a href="#testimonials" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Reviews</a>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5 class="mb-4">Services</h5>
                    <div class="footer-links">
                        <a href="enhanced-booking-system.php?bus_type=seater" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Seater Buses</a>
                        <a href="enhanced-booking-system.php?bus_type=sleeper" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Sleeper Buses</a>
                        <a href="enhanced-booking-system.php?ac=1" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">AC Buses</a>
                        <a href="bus-tracking.php" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Live Tracking</a>
                        <a href="payment.php" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">Secure Payment</a>
                        <a href="#support" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; transition: all 0.3s ease; display: block; padding: 5px 0;">24/7 Support</a>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb-4">
                    <h5 class="mb-4">Contact Info</h5>
                    <div class="contact-info mb-4">
                        <p class="mb-2">
                            <i class="fas fa-map-marker-alt me-3"></i>
                            SR Travels Head Office<br>
                            <span class="ms-4">Pune, Maharashtra, India</span>
                        </p>
                        <p class="mb-2">
                            <i class="fas fa-phone me-3"></i>
                            <a href="tel:+919356437871" class="text-white text-decoration-none">+91 9356437871</a>
                        </p>
                        <p class="mb-2">
                            <i class="fas fa-envelope me-3"></i>
                            <a href="mailto:srtravels@gmail.com" class="text-white text-decoration-none">srtravels@gmail.com</a>
                        </p>
                        <p class="mb-4">
                            <i class="fas fa-clock me-3"></i>
                            24/7 Customer Support
                        </p>
                    </div>
                    
                    <h6 class="mb-3">Newsletter Subscription</h6>
                    <p class="mb-3">Get exclusive offers and travel updates</p>
                    <form class="newsletter-form" onsubmit="subscribeNewsletter(event)">
                        <div class="input-group">
                            <input type="email" class="form-control" placeholder="Enter your email" required>
                            <button class="btn btn-warning" type="submit">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <hr class="my-4" style="border-color: rgba(255,255,255,0.2);">
            
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0">
                        &copy; <?php echo date('Y'); ?> SR TRAVELS. All rights reserved.
                    </p>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="footer-links d-inline-flex">
                        <a href="#privacy" class="me-3" style="color: rgba(255, 255, 255, 0.8); text-decoration: none;">Privacy Policy</a>
                        <a href="#terms" class="me-3" style="color: rgba(255, 255, 255, 0.8); text-decoration: none;">Terms of Service</a>
                        <a href="#refund" style="color: rgba(255, 255, 255, 0.8); text-decoration: none;">Refund Policy</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- AOS Animation -->
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    
    <script>
        // Initialize AOS (Animate On Scroll)
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true,
            offset: 100
        });

        // Loading overlay
        window.addEventListener('load', function() {
            setTimeout(function() {
                const loadingOverlay = document.getElementById('loadingOverlay');
                if (loadingOverlay) {
                    loadingOverlay.style.opacity = '0';
                    setTimeout(function() {
                        loadingOverlay.style.display = 'none';
                    }, 500);
                }
            }, 1000);
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNavbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Newsletter subscription
        function subscribeNewsletter(event) {
            event.preventDefault();
            const email = event.target.querySelector('input[type="email"]').value;
            
            // Show loading state
            const button = event.target.querySelector('button');
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            button.disabled = true;
            
            // Simulate API call
            setTimeout(function() {
                alert('Thank you for subscribing! You will receive exclusive offers and updates.');
                event.target.reset();
                button.innerHTML = originalText;
                button.disabled = false;
            }, 1500);
        }

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Social media hover effects
        document.querySelectorAll('.social-icons a').forEach(link => {
            link.addEventListener('mouseenter', function() {
                this.style.background = 'var(--accent-color)';
                this.style.transform = 'translateY(-3px)';
            });
            
            link.addEventListener('mouseleave', function() {
                this.style.background = 'rgba(255, 255, 255, 0.1)';
                this.style.transform = 'translateY(0)';
            });
        });

        // Footer links hover effects
        document.querySelectorAll('.footer-links a').forEach(link => {
            link.addEventListener('mouseenter', function() {
                this.style.color = 'var(--accent-color)';
                this.style.paddingLeft = '10px';
            });
            
            link.addEventListener('mouseleave', function() {
                this.style.color = 'rgba(255, 255, 255, 0.8)';
                this.style.paddingLeft = '0';
            });
        });
        
        <?php if (isset($custom_js)) echo $custom_js; ?>
    </script>
    
    <?php if (isset($additional_scripts)) echo $additional_scripts; ?>
</body>
</html>