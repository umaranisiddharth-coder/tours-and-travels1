<?php
require_once 'config.php';

// Check if user is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: login.php");
    exit();
}

// Get comprehensive statistics with prepared statements
$stats = [];

// Basic counts
$stats['total_users'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE user_type = 'user'"))['count'];
$stats['total_buses'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM buses WHERE status = 'active'"))['count'];
$stats['total_routes'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bus_routes WHERE is_active = 1"))['count'];

// Today's statistics
$today = date('Y-m-d');
$stats['today_bookings'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings WHERE DATE(booking_date) = '$today'"))['count'];
$stats['today_revenue'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount), 0) as total FROM bookings WHERE DATE(booking_date) = '$today' AND payment_status = 'paid'"))['total'];

// This month statistics
$this_month = date('Y-m');
$stats['month_bookings'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings WHERE DATE_FORMAT(booking_date, '%Y-%m') = '$this_month'"))['count'];
$stats['month_revenue'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount), 0) as total FROM bookings WHERE DATE_FORMAT(booking_date, '%Y-%m') = '$this_month' AND payment_status = 'paid'"))['total'];

// Total revenue
$stats['total_revenue'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount), 0) as total FROM bookings WHERE payment_status = 'paid'"))['total'];

// Bus type distribution
$bus_types = mysqli_query($conn, "SELECT bus_type, COUNT(*) as count FROM buses WHERE status = 'active' GROUP BY bus_type");

// Booking status distribution
$booking_status = mysqli_query($conn, "SELECT booking_status, COUNT(*) as count FROM bookings GROUP BY booking_status");

// Payment method distribution
$payment_methods = mysqli_query($conn, "SELECT payment_method, COUNT(*) as count FROM bookings WHERE payment_method IS NOT NULL GROUP BY payment_method");

// Recent bookings
$recent_bookings = mysqli_query($conn, 
    "SELECT b.booking_id, u.full_name, r.from_city, r.to_city, b.total_amount, b.booking_status, b.booking_date 
     FROM bookings b 
     JOIN users u ON b.user_id = u.id 
     JOIN bus_routes r ON b.route_id = r.id 
     ORDER BY b.booking_date DESC LIMIT 10");

// Popular routes
$popular_routes = mysqli_query($conn,
    "SELECT r.from_city, r.to_city, COUNT(*) as booking_count, SUM(b.total_amount) as revenue
     FROM bookings b
     JOIN bus_routes r ON b.route_id = r.id
     WHERE b.booking_status = 'confirmed'
     GROUP BY r.from_city, r.to_city
     ORDER BY booking_count DESC
     LIMIT 5");

// Daily revenue for last 7 days
$daily_revenue = mysqli_query($conn,
    "SELECT DATE(booking_date) as date, COALESCE(SUM(total_amount), 0) as revenue
     FROM bookings 
     WHERE booking_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
     AND payment_status = 'paid'
     GROUP BY DATE(booking_date)
     ORDER BY date DESC");

// Bus utilization
$bus_utilization = mysqli_query($conn,
    "SELECT b.bus_name, b.bus_number, b.total_seats,
            COALESCE(SUM(bk.total_seats), 0) as booked_seats,
            ROUND((COALESCE(SUM(bk.total_seats), 0) / (b.total_seats * 30)) * 100, 2) as utilization_percent
     FROM buses b
     LEFT JOIN bookings bk ON b.id = bk.bus_id 
                           AND bk.booking_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                           AND bk.booking_status = 'confirmed'
     WHERE b.status = 'active'
     GROUP BY b.id, b.bus_name, b.bus_number, b.total_seats
     ORDER BY utilization_percent DESC
     LIMIT 10");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #17a2b8;
            --dark-color: #343a40;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .dashboard-container {
            padding: 20px;
        }
        
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border-left: 5px solid;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100px;
            background: linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.3));
            border-radius: 50%;
            transform: translate(30px, -30px);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        
        .stat-card.primary { border-left-color: var(--primary-color); }
        .stat-card.success { border-left-color: var(--success-color); }
        .stat-card.warning { border-left-color: var(--warning-color); }
        .stat-card.info { border-left-color: var(--info-color); }
        .stat-card.danger { border-left-color: var(--danger-color); }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 15px;
        }
        
        .stat-icon.primary { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); }
        .stat-icon.success { background: linear-gradient(135deg, var(--success-color), #20c997); }
        .stat-icon.warning { background: linear-gradient(135deg, var(--warning-color), #fd7e14); }
        .stat-icon.info { background: linear-gradient(135deg, var(--info-color), #6f42c1); }
        .stat-icon.danger { background: linear-gradient(135deg, var(--danger-color), #e83e8c); }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .chart-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .table-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #333;
            background: #f8f9fa;
        }
        
        .badge-status {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .navbar-admin {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .quick-action-btn {
            background: white;
            border: none;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .quick-action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            color: var(--primary-color);
        }
        
        .utilization-bar {
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .utilization-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        
        .utilization-high { background: var(--success-color); }
        .utilization-medium { background: var(--warning-color); }
        .utilization-low { background: var(--danger-color); }
        
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 10px;
            }
            
            .stat-value {
                font-size: 2rem;
            }
            
            .quick-actions {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-admin">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold text-primary" href="#">
                <i class="fas fa-tachometer-alt me-2"></i>
                SR<span class="text-warning">TRAVELS</span> Admin
            </a>
            
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i>
                        <?php echo $_SESSION['user_name'] ?? 'Admin'; ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin-settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><a class="dropdown-item" href="admin-profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="dashboard-container">
        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="admin-bookings.php" class="quick-action-btn">
                <i class="fas fa-ticket-alt fa-2x mb-2 text-primary"></i>
                <div>Manage Bookings</div>
            </a>
            <a href="admin-buses.php" class="quick-action-btn">
                <i class="fas fa-bus fa-2x mb-2 text-success"></i>
                <div>Manage Buses</div>
            </a>
            <a href="admin-routes.php" class="quick-action-btn">
                <i class="fas fa-route fa-2x mb-2 text-warning"></i>
                <div>Manage Routes</div>
            </a>
            <a href="admin-users.php" class="quick-action-btn">
                <i class="fas fa-users fa-2x mb-2 text-info"></i>
                <div>Manage Users</div>
            </a>
            <a href="admin-reports.php" class="quick-action-btn">
                <i class="fas fa-chart-bar fa-2x mb-2 text-danger"></i>
                <div>Reports</div>
            </a>
            <a href="admin-settings.php" class="quick-action-btn">
                <i class="fas fa-cogs fa-2x mb-2 text-secondary"></i>
                <div>Settings</div>
            </a>
        </div>

        <!-- Statistics Cards -->
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="stat-card primary">
                    <div class="stat-icon primary">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['total_users']); ?></div>
                    <div class="stat-label">Total Users</div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="stat-card success">
                    <div class="stat-icon success">
                        <i class="fas fa-bus"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['total_buses']); ?></div>
                    <div class="stat-label">Active Buses</div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="stat-card warning">
                    <div class="stat-icon warning">
                        <i class="fas fa-ticket-alt"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['today_bookings']); ?></div>
                    <div class="stat-label">Today's Bookings</div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="stat-card info">
                    <div class="stat-icon info">
                        <i class="fas fa-rupee-sign"></i>
                    </div>
                    <div class="stat-value">₹<?php echo number_format($stats['today_revenue'], 0); ?></div>
                    <div class="stat-label">Today's Revenue</div>
                </div>
            </div>
        </div>

        <!-- Additional Stats Row -->
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="stat-card danger">
                    <div class="stat-icon danger">
                        <i class="fas fa-calendar-month"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['month_bookings']); ?></div>
                    <div class="stat-label">This Month Bookings</div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="stat-card primary">
                    <div class="stat-icon primary">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-value">₹<?php echo number_format($stats['month_revenue'], 0); ?></div>
                    <div class="stat-label">This Month Revenue</div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="stat-card success">
                    <div class="stat-icon success">
                        <i class="fas fa-coins"></i>
                    </div>
                    <div class="stat-value">₹<?php echo number_format($stats['total_revenue'], 0); ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="row">
            <div class="col-lg-6">
                <div class="chart-container">
                    <h5 class="mb-4">
                        <i class="fas fa-chart-pie me-2"></i>
                        Booking Status Distribution
                    </h5>
                    <canvas id="bookingStatusChart" height="300"></canvas>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="chart-container">
                    <h5 class="mb-4">
                        <i class="fas fa-chart-line me-2"></i>
                        Daily Revenue (Last 7 Days)
                    </h5>
                    <canvas id="revenueChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- Tables Row -->
        <div class="row">
            <div class="col-lg-8">
                <div class="table-container">
                    <h5 class="mb-4">
                        <i class="fas fa-clock me-2"></i>
                        Recent Bookings
                    </h5>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Booking ID</th>
                                    <th>Customer</th>
                                    <th>Route</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($booking = mysqli_fetch_assoc($recent_bookings)): ?>
                                <tr>
                                    <td><strong><?php echo $booking['booking_id']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($booking['full_name']); ?></td>
                                    <td><?php echo $booking['from_city'] . ' → ' . $booking['to_city']; ?></td>
                                    <td>₹<?php echo number_format($booking['total_amount'], 2); ?></td>
                                    <td>
                                        <span class="badge-status 
                                            <?php echo $booking['booking_status'] == 'confirmed' ? 'bg-success' : 
                                                     ($booking['booking_status'] == 'pending' ? 'bg-warning' : 'bg-danger'); ?>">
                                            <?php echo ucfirst($booking['booking_status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, H:i', strtotime($booking['booking_date'])); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="table-container">
                    <h5 class="mb-4">
                        <i class="fas fa-fire me-2"></i>
                        Popular Routes
                    </h5>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Route</th>
                                    <th>Bookings</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($route = mysqli_fetch_assoc($popular_routes)): ?>
                                <tr>
                                    <td>
                                        <small><?php echo $route['from_city'] . ' → ' . $route['to_city']; ?></small>
                                    </td>
                                    <td><strong><?php echo $route['booking_count']; ?></strong></td>
                                    <td><small>₹<?php echo number_format($route['revenue'], 0); ?></small></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bus Utilization -->
        <div class="row">
            <div class="col-12">
                <div class="table-container">
                    <h5 class="mb-4">
                        <i class="fas fa-chart-bar me-2"></i>
                        Bus Utilization (Last 30 Days)
                    </h5>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Bus Name</th>
                                    <th>Bus Number</th>
                                    <th>Total Seats</th>
                                    <th>Booked Seats</th>
                                    <th>Utilization</th>
                                    <th>Performance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($bus = mysqli_fetch_assoc($bus_utilization)): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($bus['bus_name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($bus['bus_number']); ?></td>
                                    <td><?php echo $bus['total_seats']; ?></td>
                                    <td><?php echo $bus['booked_seats']; ?></td>
                                    <td><?php echo $bus['utilization_percent']; ?>%</td>
                                    <td>
                                        <div class="utilization-bar">
                                            <div class="utilization-fill 
                                                <?php echo $bus['utilization_percent'] >= 70 ? 'utilization-high' : 
                                                         ($bus['utilization_percent'] >= 40 ? 'utilization-medium' : 'utilization-low'); ?>"
                                                 style="width: <?php echo min(100, $bus['utilization_percent']); ?>%">
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Booking Status Chart
        const bookingStatusCtx = document.getElementById('bookingStatusChart').getContext('2d');
        const bookingStatusData = {
            <?php
            $status_data = [];
            mysqli_data_seek($booking_status, 0);
            while ($status = mysqli_fetch_assoc($booking_status)) {
                $status_data[] = "'" . $status['booking_status'] . "': " . $status['count'];
            }
            echo implode(', ', $status_data);
            ?>
        };
        
        new Chart(bookingStatusCtx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(bookingStatusData),
                datasets: [{
                    data: Object.values(bookingStatusData),
                    backgroundColor: [
                        '#28a745',
                        '#ffc107', 
                        '#dc3545',
                        '#17a2b8'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Revenue Chart
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        const revenueData = {
            <?php
            $revenue_labels = [];
            $revenue_values = [];
            mysqli_data_seek($daily_revenue, 0);
            while ($revenue = mysqli_fetch_assoc($daily_revenue)) {
                $revenue_labels[] = "'" . date('M d', strtotime($revenue['date'])) . "'";
                $revenue_values[] = $revenue['revenue'];
            }
            echo "labels: [" . implode(', ', array_reverse($revenue_labels)) . "],";
            echo "values: [" . implode(', ', array_reverse($revenue_values)) . "]";
            ?>
        };
        
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: revenueData.labels,
                datasets: [{
                    label: 'Revenue (₹)',
                    data: revenueData.values,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });

        // Auto-refresh dashboard every 5 minutes
        setInterval(function() {
            location.reload();
        }, 300000);

        // Real-time updates via WebSocket (if implemented)
        // This would connect to a WebSocket server for real-time updates
        function initializeRealTimeUpdates() {
            // WebSocket implementation would go here
            console.log('Real-time updates initialized');
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            initializeRealTimeUpdates();
        });
    </script>
</body>
</html>