<?php
require_once 'config.php';

if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

$route_id = isset($_GET['route_id']) ? intval($_GET['route_id']) : 0;
$travel_date = isset($_GET['travel_date']) ? sanitize_input($_GET['travel_date']) : date('Y-m-d');

// Get route details with prepared statement
$route_query = "SELECT r.*, b.bus_number, b.bus_name, b.bus_type, b.total_seats, b.amenities, b.facilities 
                FROM bus_routes r 
                JOIN buses b ON r.bus_id = b.id 
                WHERE r.id = ?";
$stmt = mysqli_prepare($conn, $route_query);
mysqli_stmt_bind_param($stmt, "i", $route_id);
mysqli_stmt_execute($stmt);
$route_result = mysqli_stmt_get_result($stmt);
$route = mysqli_fetch_assoc($route_result);

if (!$route) {
    $_SESSION['error'] = "Invalid route selected.";
    header("Location: enhanced-booking-system.php");
    exit();
}

// Get booked seats for this bus on selected date
$booked_seats_query = "SELECT seat_number FROM seat_availability 
                      WHERE bus_id = ? AND travel_date = ? AND is_available = FALSE";
$stmt = mysqli_prepare($conn, $booked_seats_query);
mysqli_stmt_bind_param($stmt, "is", $route['bus_id'], $travel_date);
mysqli_stmt_execute($stmt);
$booked_seats_result = mysqli_stmt_get_result($stmt);
$booked_seats = [];
while($seat = mysqli_fetch_assoc($booked_seats_result)) {
    $booked_seats[] = $seat['seat_number'];
}

// Get seat layout based on bus type
$seat_layout = generateSeatLayout($route['bus_type'], $route['total_seats']);

// Handle seat selection
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_seats = isset($_POST['selected_seats']) ? $_POST['selected_seats'] : [];
    
    // Ensure selected_seats is an array
    if (is_string($selected_seats)) {
        // Check if it's JSON string first
        $json_decoded = json_decode($selected_seats, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($json_decoded)) {
            $selected_seats = $json_decoded;
        } else {
            // If it's a comma-separated string, convert to array
            $selected_seats = !empty($selected_seats) ? explode(',', $selected_seats) : [];
        }
        // Remove any empty values and trim whitespace
        $selected_seats = array_filter(array_map('trim', $selected_seats));
    } elseif (!is_array($selected_seats)) {
        // If it's neither string nor array, make it empty array
        $selected_seats = [];
    }
    
    if (count($selected_seats) == 0) {
        $error = "Please select at least one seat.";
    } elseif (count($selected_seats) > 6) {
        $error = "You can select maximum 6 seats at a time.";
    } else {
        // Check if selected seats are still available
        $seat_check_query = "SELECT seat_number FROM seat_availability 
                            WHERE bus_id = ? AND travel_date = ? AND seat_number IN (" . 
                            str_repeat('?,', count($selected_seats) - 1) . "?) AND is_available = FALSE";
        
        $stmt = mysqli_prepare($conn, $seat_check_query);
        $types = "is" . str_repeat('s', count($selected_seats));
        $params = array_merge([$route['bus_id'], $travel_date], $selected_seats);
        mysqli_stmt_bind_param($stmt, $types, ...$params);
        mysqli_stmt_execute($stmt);
        $unavailable_seats = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($unavailable_seats) > 0) {
            $error = "Some selected seats are no longer available. Please refresh and try again.";
        } else {
            // Store selected seats in session and redirect to payment
            $_SESSION['selected_seats'] = $selected_seats;
            $_SESSION['route_id'] = $route_id;
            $_SESSION['travel_date'] = $travel_date;
            $_SESSION['total_amount'] = count($selected_seats) * $route['fare'];
            
            header("Location: payment.php");
            exit();
        }
    }
}

function generateSeatLayout($bus_type, $total_seats) {
    $layout = [];
    
    if ($bus_type == 'seater') {
        // 2+2 seating arrangement for seater buses
        $rows = ceil($total_seats / 4);
        for ($row = 1; $row <= $rows; $row++) {
            $layout[$row] = [
                'left' => [
                    ($row - 1) * 4 + 1,
                    ($row - 1) * 4 + 2
                ],
                'right' => [
                    ($row - 1) * 4 + 3,
                    ($row - 1) * 4 + 4
                ]
            ];
        }
    } else {
        // 2+1 arrangement for sleeper buses (upper and lower berths)
        $rows = ceil($total_seats / 6); // 6 berths per row (4 lower + 2 upper)
        for ($row = 1; $row <= $rows; $row++) {
            $base = ($row - 1) * 6;
            $layout[$row] = [
                'lower_left' => [$base + 1, $base + 2],
                'lower_right' => [$base + 3],
                'upper_left' => ['U' . ($base + 1), 'U' . ($base + 2)],
                'upper_right' => ['U' . ($base + 3)]
            ];
        }
    }
    
    return $layout;
}

// Page configuration for header
$page_title = "Select Seats";
$page_description = "Choose your preferred seats for a comfortable journey";
$show_page_header = true;
$breadcrumbs = [
    ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
    ['title' => 'Book Bus', 'url' => 'enhanced-booking-system.php', 'icon' => 'fas fa-search'],
    ['title' => 'Select Seats', 'icon' => 'fas fa-chair']
];

// Custom CSS for seat selection
$custom_css = '
        .seat-selection-container {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 30px;
            margin-top: 30px;
        }
        
        .bus-layout {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }
        
        .bus-front {
            background: linear-gradient(135deg, #333, #555);
            color: white;
            text-align: center;
            padding: 15px;
            border-radius: 15px;
            margin-bottom: 30px;
            position: relative;
        }
        
        .bus-front::after {
            content: "";
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 15px solid transparent;
            border-right: 15px solid transparent;
            border-top: 10px solid #555;
        }
        
        .seat-layout {
            max-width: 400px;
            margin: 0 auto;
        }
        
        .seat-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            align-items: center;
        }
        
        .seat-group {
            display: flex;
            gap: 8px;
        }
        
        .seat {
            width: 45px;
            height: 45px;
            border: 2px solid #ddd;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.8rem;
            font-weight: 600;
            position: relative;
            background: #f8f9fa;
        }
        
        .seat.sleeper {
            height: 35px;
            border-radius: 12px;
        }
        
        .seat.upper {
            background: linear-gradient(135deg, #e3f2fd, #bbdefb);
            border-color: #2196f3;
        }
        
        .seat.lower {
            background: linear-gradient(135deg, #f3e5f5, #e1bee7);
            border-color: #9c27b0;
        }
        
        .seat.available:hover {
            transform: scale(1.1);
            border-color: var(--primary-color);
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }
        
        .seat.selected {
            background: linear-gradient(135deg, var(--success-color), #20c997);
            border-color: var(--success-color);
            color: white;
            transform: scale(1.05);
        }
        
        .seat.booked {
            background: #dc3545;
            border-color: #dc3545;
            color: white;
            cursor: not-allowed;
            opacity: 0.7;
        }
        
        .aisle {
            width: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ccc;
        }
        
        .row-number {
            width: 30px;
            text-align: center;
            font-weight: bold;
            color: #666;
        }
        
        .booking-summary {
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            position: sticky;
            top: 20px;
        }
        
        .legend {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
        }
        
        .legend-seat {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            border: 2px solid;
        }
        
        .selected-seats {
            margin: 20px 0;
        }
        
        .seat-tag {
            display: inline-block;
            background: var(--success-color);
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            margin: 2px;
            font-size: 0.8rem;
        }
        
        .price-breakdown {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
        }
        
        .price-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        
        .total-price {
            font-size: 1.3rem;
            font-weight: bold;
            color: var(--success-color);
            border-top: 2px solid #dee2e6;
            padding-top: 10px;
        }
        
        .continue-btn {
            background: linear-gradient(135deg, var(--success-color), #20c997);
            border: none;
            padding: 15px;
            border-radius: 10px;
            color: white;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s ease;
        }
        
        .continue-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
            color: white;
        }
        
        .continue-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
        }
        
        .seat-info {
            position: absolute;
            background: rgba(0,0,0,0.8);
            color: white;
            padding: 5px 8px;
            border-radius: 5px;
            font-size: 0.7rem;
            top: -30px;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }
        
        .seat:hover .seat-info {
            opacity: 1;
        }
        
        @media (max-width: 768px) {
            .seat-selection-container {
                grid-template-columns: 1fr;
            }
            
            .booking-summary {
                position: static;
                order: -1;
            }
            
            .seat {
                width: 35px;
                height: 35px;
                font-size: 0.7rem;
            }
        }
';

include 'includes/header.php';
?>
<!-- Content Section -->
<section class="content-section">
    <div class="container">
        <!-- Route Information Card -->
        <div class="card mb-4" data-aos="fade-up">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="mb-2">
                            <i class="fas fa-route me-2"></i>
                            <?php echo htmlspecialchars($route['from_city']); ?> → <?php echo htmlspecialchars($route['to_city']); ?>
                        </h4>
                        <div class="row">
                            <div class="col-md-6">
                                <p class="mb-1">
                                    <i class="fas fa-bus text-light me-2"></i>
                                    <strong><?php echo htmlspecialchars($route['bus_name']); ?></strong> 
                                    (<?php echo htmlspecialchars($route['bus_number']); ?>)
                                </p>
                                <p class="mb-1">
                                    <i class="fas fa-calendar text-light me-2"></i>
                                    <?php echo date('d M Y', strtotime($travel_date)); ?>
                                </p>
                            </div>
                            <div class="col-md-6">
                                <p class="mb-1">
                                    <i class="fas fa-clock text-light me-2"></i>
                                    <?php echo date('H:i', strtotime($route['departure_time'])); ?> - 
                                    <?php echo date('H:i', strtotime($route['arrival_time'])); ?>
                                </p>
                                <p class="mb-1">
                                    <i class="fas fa-chair text-light me-2"></i>
                                    <?php echo ucfirst($route['bus_type']); ?> • ₹<?php echo number_format($route['fare'], 2); ?> per seat
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-end">
                        <div class="badge bg-light text-dark fs-6 p-2">
                            <i class="fas fa-shield-alt me-1"></i>
                            Safe & Secure Booking
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" data-aos="fade-up">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Seat Selection -->
        <div class="seat-selection-container" data-aos="fade-up" data-aos-delay="200">
            <!-- Bus Layout -->
            <div class="bus-layout">
                <div class="bus-front">
                    <i class="fas fa-steering-wheel me-2"></i>
                    Driver
                </div>

                <div class="seat-layout">
                    <?php foreach ($seat_layout as $row_num => $row): ?>
                    <div class="seat-row">
                        <div class="row-number"><?php echo $row_num; ?></div>
                        
                        <?php if ($route['bus_type'] == 'seater'): ?>
                            <!-- Seater Layout -->
                            <div class="seat-group">
                                <?php foreach ($row['left'] as $seat_num): ?>
                                    <?php if ($seat_num <= $route['total_seats']): ?>
                                    <div class="seat available <?php echo in_array($seat_num, $booked_seats) ? 'booked' : ''; ?>" 
                                         data-seat="<?php echo $seat_num; ?>"
                                         onclick="toggleSeat(this)">
                                        <?php echo $seat_num; ?>
                                        <div class="seat-info">Seat <?php echo $seat_num; ?></div>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="aisle">
                                <i class="fas fa-grip-lines-vertical"></i>
                            </div>
                            
                            <div class="seat-group">
                                <?php foreach ($row['right'] as $seat_num): ?>
                                    <?php if ($seat_num <= $route['total_seats']): ?>
                                    <div class="seat available <?php echo in_array($seat_num, $booked_seats) ? 'booked' : ''; ?>" 
                                         data-seat="<?php echo $seat_num; ?>"
                                         onclick="toggleSeat(this)">
                                        <?php echo $seat_num; ?>
                                        <div class="seat-info">Seat <?php echo $seat_num; ?></div>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            
                        <?php else: ?>
                            <!-- Sleeper Layout -->
                            <div class="d-flex flex-column gap-2">
                                <!-- Upper berths -->
                                <div class="d-flex justify-content-between">
                                    <div class="seat-group">
                                        <?php foreach ($row['upper_left'] as $seat_num): ?>
                                            <?php if (is_numeric(str_replace('U', '', $seat_num)) && str_replace('U', '', $seat_num) <= $route['total_seats']/2): ?>
                                            <div class="seat sleeper upper available <?php echo in_array($seat_num, $booked_seats) ? 'booked' : ''; ?>" 
                                                 data-seat="<?php echo $seat_num; ?>"
                                                 onclick="toggleSeat(this)">
                                                <?php echo $seat_num; ?>
                                                <div class="seat-info">Upper Berth <?php echo $seat_num; ?></div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                    
                                    <div class="aisle">
                                        <i class="fas fa-grip-lines-vertical"></i>
                                    </div>
                                    
                                    <div class="seat-group">
                                        <?php foreach ($row['upper_right'] as $seat_num): ?>
                                            <?php if (is_numeric(str_replace('U', '', $seat_num)) && str_replace('U', '', $seat_num) <= $route['total_seats']/2): ?>
                                            <div class="seat sleeper upper available <?php echo in_array($seat_num, $booked_seats) ? 'booked' : ''; ?>" 
                                                 data-seat="<?php echo $seat_num; ?>"
                                                 onclick="toggleSeat(this)">
                                                <?php echo $seat_num; ?>
                                                <div class="seat-info">Upper Berth <?php echo $seat_num; ?></div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                
                                <!-- Lower berths -->
                                <div class="d-flex justify-content-between">
                                    <div class="seat-group">
                                        <?php foreach ($row['lower_left'] as $seat_num): ?>
                                            <?php if ($seat_num <= $route['total_seats']): ?>
                                            <div class="seat sleeper lower available <?php echo in_array($seat_num, $booked_seats) ? 'booked' : ''; ?>" 
                                                 data-seat="<?php echo $seat_num; ?>"
                                                 onclick="toggleSeat(this)">
                                                <?php echo $seat_num; ?>
                                                <div class="seat-info">Lower Berth <?php echo $seat_num; ?></div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                    
                                    <div class="aisle">
                                        <i class="fas fa-grip-lines-vertical"></i>
                                    </div>
                                    
                                    <div class="seat-group">
                                        <?php foreach ($row['lower_right'] as $seat_num): ?>
                                            <?php if ($seat_num <= $route['total_seats']): ?>
                                            <div class="seat sleeper lower available <?php echo in_array($seat_num, $booked_seats) ? 'booked' : ''; ?>" 
                                                 data-seat="<?php echo $seat_num; ?>"
                                                 onclick="toggleSeat(this)">
                                                <?php echo $seat_num; ?>
                                                <div class="seat-info">Lower Berth <?php echo $seat_num; ?></div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Booking Summary -->
            <div class="booking-summary" data-aos="fade-left" data-aos-delay="400">
                <h5 class="mb-3">
                    <i class="fas fa-clipboard-list me-2"></i>
                    Booking Summary
                </h5>

                <!-- Legend -->
                <div class="legend">
                    <div class="legend-item">
                        <div class="legend-seat" style="background: #f8f9fa; border-color: #ddd;"></div>
                        <span>Available</span>
                    </div>
                    <div class="legend-item">
                        <div class="legend-seat" style="background: var(--success-color); border-color: var(--success-color);"></div>
                        <span>Selected</span>
                    </div>
                    <div class="legend-item">
                        <div class="legend-seat" style="background: #dc3545; border-color: #dc3545;"></div>
                        <span>Booked</span>
                    </div>
                    <?php if ($route['bus_type'] == 'sleeper'): ?>
                    <div class="legend-item">
                        <div class="legend-seat" style="background: linear-gradient(135deg, #e3f2fd, #bbdefb); border-color: #2196f3;"></div>
                        <span>Upper</span>
                    </div>
                    <div class="legend-item">
                        <div class="legend-seat" style="background: linear-gradient(135deg, #f3e5f5, #e1bee7); border-color: #9c27b0;"></div>
                        <span>Lower</span>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Selected Seats -->
                <div class="selected-seats">
                    <h6>Selected Seats:</h6>
                    <div id="selected-seats-display">
                        <span class="text-muted">No seats selected</span>
                    </div>
                </div>

                <!-- Price Breakdown -->
                <div class="price-breakdown">
                    <div class="price-row">
                        <span>Base Fare:</span>
                        <span>₹<span id="base-fare">0.00</span></span>
                    </div>
                    <div class="price-row">
                        <span>Taxes & Fees:</span>
                        <span>₹<span id="taxes">0.00</span></span>
                    </div>
                    <div class="price-row total-price">
                        <span>Total Amount:</span>
                        <span>₹<span id="total-amount">0.00</span></span>
                    </div>
                </div>

                <!-- Continue Button -->
                <form method="POST" id="seat-form">
                    <input type="hidden" name="selected_seats" id="selected-seats-input">
                    <button type="submit" class="continue-btn" id="continue-btn" disabled>
                        <i class="fas fa-arrow-right me-2"></i>
                        Continue to Payment
                    </button>
                </form>

                <!-- Bus Amenities -->
                <?php if ($route['amenities']): ?>
                <div class="mt-4">
                    <h6>Bus Amenities:</h6>
                    <div class="d-flex flex-wrap gap-2">
                        <?php 
                        $amenities = explode(',', $route['amenities']);
                        foreach ($amenities as $amenity): 
                        ?>
                        <span class="badge bg-light text-dark">
                            <i class="fas fa-check me-1"></i><?php echo trim($amenity); ?>
                        </span>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php
// Custom JavaScript for seat selection
$custom_js = '
        let selectedSeats = [];
        const farePerSeat = ' . $route['fare'] . ';
        const taxRate = 0.05; // 5% tax

        function toggleSeat(seatElement) {
            if (seatElement.classList.contains("booked")) {
                return; // Cannot select booked seats
            }

            const seatNumber = seatElement.dataset.seat;
            
            if (seatElement.classList.contains("selected")) {
                // Deselect seat
                seatElement.classList.remove("selected");
                selectedSeats = selectedSeats.filter(seat => seat !== seatNumber);
            } else {
                // Select seat (max 6 seats)
                if (selectedSeats.length >= 6) {
                    alert("You can select maximum 6 seats at a time.");
                    return;
                }
                seatElement.classList.add("selected");
                selectedSeats.push(seatNumber);
            }

            updateBookingSummary();
        }

        function updateBookingSummary() {
            const seatCount = selectedSeats.length;
            const baseFare = seatCount * farePerSeat;
            const taxes = baseFare * taxRate;
            const totalAmount = baseFare + taxes;

            // Update selected seats display
            const selectedSeatsDisplay = document.getElementById("selected-seats-display");
            if (seatCount > 0) {
                selectedSeatsDisplay.innerHTML = selectedSeats.map(seat => 
                    `<span class="seat-tag">${seat}</span>`
                ).join("");
            } else {
                selectedSeatsDisplay.innerHTML = "<span class=\"text-muted\">No seats selected</span>";
            }

            // Update price breakdown
            document.getElementById("base-fare").textContent = baseFare.toFixed(2);
            document.getElementById("taxes").textContent = taxes.toFixed(2);
            document.getElementById("total-amount").textContent = totalAmount.toFixed(2);

            // Update form input
            document.getElementById("selected-seats-input").value = JSON.stringify(selectedSeats);

            // Enable/disable continue button
            const continueBtn = document.getElementById("continue-btn");
            continueBtn.disabled = seatCount === 0;
        }

        // Auto-refresh seat availability every 30 seconds
        setInterval(function() {
            fetch("ajax-handler.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: `action=check_seat_availability&route_id=' . $route_id . '&travel_date=' . $travel_date . '`
            })
            .then(response => response.json())
            .then(data => {
                if (data.updated_seats) {
                    // Update seat availability
                    data.updated_seats.forEach(seat => {
                        const seatElement = document.querySelector(`[data-seat="${seat}"]`);
                        if (seatElement && !seatElement.classList.contains("selected")) {
                            seatElement.classList.add("booked");
                            seatElement.onclick = null;
                        }
                    });
                }
            })
            .catch(error => console.error("Error checking seat availability:", error));
        }, 30000);

        // Prevent form submission if no seats selected
        document.getElementById("seat-form").addEventListener("submit", function(e) {
            if (selectedSeats.length === 0) {
                e.preventDefault();
                alert("Please select at least one seat.");
            }
        });

        // Initialize
        updateBookingSummary();
';

include 'includes/footer.php';
?>e selected seats display
