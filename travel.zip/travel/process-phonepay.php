
<?php
require_once 'config.php';
require_once 'paytm-config.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Get order ID
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : (isset($_SESSION['paytm_order_id']) ? $_SESSION['paytm_order_id'] : '');
if (empty($order_id)) {
    header("Location: payment.php");
    exit();
}

// Get pending booking details
$pending_query = "SELECT * FROM pending_bookings WHERE order_id = '$order_id' AND user_id = " . $_SESSION['user_id'];
$pending_result = mysqli_query($conn, $pending_query);
$pending_booking = mysqli_fetch_assoc($pending_result);

if (!$pending_booking) {
    header("Location: payment.php");
    exit();
}

$amount = $pending_booking['amount'];
$user_id = $_SESSION['user_id'];

// Get user details
$user = get_user_by_id($user_id);
$user_email = $user['email'];
$user_phone = $user['phone'];

// Prepare PhonePe payment request
$merchantId = PHONEPE_MERCHANT_ID;
$merchantTransactionId = $order_id;
$amountInPaise = $amount * 100; // Convert to paise
$callbackUrl = PHONEPE_CALLBACK_URL;

// Create payload
$payload = [
    'merchantId' => $merchantId,
    'merchantTransactionId' => $merchantTransactionId,
    'merchantUserId' => 'MUID_' . $user_id,
    'amount' => $amountInPaise,
    'redirectUrl' => SITE_URL . '/booking-confirm.php',
    'redirectMode' => 'REDIRECT',
    'callbackUrl' => $callbackUrl,
    'mobileNumber' => $user_phone,
    'paymentInstrument' => [
        'type' => 'PAY_PAGE'
    ]
];

// Convert payload to base64
$base64Payload = base64_encode(json_encode($payload));

// Generate signature
$signature = generate_phonepe_signature($base64Payload . '/pg/v1/pay' . PHONEPE_SALT_KEY);

// Make API request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, PHONEPE_PAY_URL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['request' => $base64Payload]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'X-VERIFY: ' . $signature,
    'accept: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Log request for debugging
log_payment_debug('PhonePe Payment Request', [
    'payload' => $payload,
    'base64Payload' => $base64Payload,
    'signature' => $signature,
    'response' => $response,
    'http_code' => $httpCode
]);

// Process response
if ($httpCode == 200) {
    $responseData = json_decode($response, true);
    
    if ($responseData['success'] && isset($responseData['data']['instrumentResponse']['redirectInfo']['url'])) {
        // Redirect to PhonePe payment page
        $paymentUrl = $responseData['data']['instrumentResponse']['redirectInfo']['url'];
        header("Location: " . $paymentUrl);
        exit();
    } else {
        // Handle error
        $_SESSION['payment_error'] = 'Failed to initiate PhonePe payment. Please try again.';
        header("Location: payment-failed.php");
        exit();
    }
} else {
    // Handle API error
    $_SESSION['payment_error'] = 'Payment gateway error. Please try another payment method.';
    header("Location: payment-failed.php");
    exit();
}
?>
