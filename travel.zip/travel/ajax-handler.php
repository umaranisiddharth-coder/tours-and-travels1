<?php
// ajax-handler.php
require_once 'config.php';

session_start();

$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

switch($action) {
    case 'log_payment_initiation':
        $order_id = isset($_POST['order_id']) ? $_POST['order_id'] : '';
        if (!empty($order_id)) {
            error_log("Payment initiated for order: " . $order_id . " at " . date('Y-m-d H:i:s'));
        }
        echo json_encode(['success' => true]);
        break;
        
    case 'check_booking_status':
        $booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0;
        if ($booking_id > 0) {
            // Check booking status from database
            $query = "SELECT booking_status FROM bookings WHERE id = $booking_id";
            $result = mysqli_query($conn, $query);
            if ($row = mysqli_fetch_assoc($result)) {
                echo json_encode([
                    'status_changed' => false, // Set to true if status changed
                    'new_status' => $row['booking_status']
                ]);
            }
        }
        break;
        
    case 'cancel_booking':
        $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
        $reason = isset($_POST['reason']) ? sanitize_input($_POST['reason']) : '';
        
        if ($booking_id > 0) {
            // Here you would implement actual cancellation logic
            // For now, just return a success message
            echo json_encode([
                'success' => true,
                'message' => 'Cancellation request received. You will receive confirmation shortly.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid booking ID'
            ]);
        }
        break;
        
    case 'check_payment_status':
        $order_id = sanitize_input($_POST['order_id']);
        $payment_status = check_payment_status($order_id);
        echo json_encode($payment_status);
        break;
        
    case 'check_upi_payment':
        $order_id = sanitize_input($_POST['order_id']);
        $upi_status = check_upi_payment_status($order_id);
        echo json_encode($upi_status);
        break;
        
    case 'log_payment_initiation':
        $order_id = sanitize_input($_POST['order_id']);
        if (function_exists('log_payment_attempt')) {
            log_payment_attempt($order_id, $_SESSION['user_id'] ?? 0, 0, 'unknown', 'initiated', 'Payment form loaded');
        }
        echo json_encode(['status' => 'logged']);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}

// Payment status checking functions
function check_payment_status($order_id) {
    global $conn;
    
    // Check if payment is completed
    $query = "SELECT p.*, b.booking_status 
              FROM payments p 
              JOIN bookings b ON p.booking_id = b.id 
              WHERE p.order_id = ? 
              ORDER BY p.id DESC LIMIT 1";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($payment = mysqli_fetch_assoc($result)) {
        if ($payment['payment_status'] === 'completed') {
            return [
                'status' => 'success',
                'message' => 'Payment completed successfully',
                'booking_status' => $payment['booking_status'],
                'transaction_id' => $payment['transaction_id']
            ];
        } else {
            return [
                'status' => 'pending',
                'message' => 'Payment is being processed',
                'payment_status' => $payment['payment_status']
            ];
        }
    }
    
    // Check pending bookings
    $pending_query = "SELECT status FROM pending_bookings WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $pending_query);
    mysqli_stmt_bind_param($stmt, "s", $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($pending = mysqli_fetch_assoc($result)) {
        if ($pending['status'] === 'failed') {
            return [
                'status' => 'failed',
                'message' => 'Payment failed'
            ];
        } else {
            return [
                'status' => 'pending',
                'message' => 'Payment is being processed'
            ];
        }
    }
    
    return [
        'status' => 'not_found',
        'message' => 'Order not found'
    ];
}

function check_upi_payment_status($order_id) {
    global $conn;
    
    // Check if payment is already completed in database
    $status = check_payment_status($order_id);
    
    if ($status['status'] === 'success') {
        return $status;
    }
    
    // Check pending booking status
    $pending_query = "SELECT * FROM pending_bookings WHERE order_id = ? AND status = 'pending'";
    $stmt = mysqli_prepare($conn, $pending_query);
    mysqli_stmt_bind_param($stmt, "s", $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $pending_booking = mysqli_fetch_assoc($result);
    
    if (!$pending_booking) {
        return [
            'status' => 'failed',
            'message' => 'Order not found or expired'
        ];
    }
    
    // For demo purposes, we'll simulate UPI payment success after some time
    // In production, you would integrate with actual UPI payment gateway APIs
    
    // Check if order is older than 2 minutes (for demo auto-success)
    $order_time = strtotime($pending_booking['created_at']);
    $current_time = time();
    $time_diff = $current_time - $order_time;
    
    if ($time_diff > 120) { // 2 minutes for demo
        // Simulate successful payment for demo
        $amount = $pending_booking['amount'];
        
        // Process the payment success
        $success = process_demo_upi_payment($order_id, $amount);
        
        if ($success) {
            return [
                'status' => 'success',
                'message' => 'UPI payment completed successfully'
            ];
        } else {
            return [
                'status' => 'failed',
                'message' => 'Payment processing failed'
            ];
        }
    } else {
        return [
            'status' => 'pending',
            'message' => 'Waiting for UPI payment confirmation'
        ];
    }
}

function process_demo_upi_payment($order_id, $amount) {
    global $conn;
    
    // Get pending booking
    $pending_booking = get_pending_booking($order_id);
    
    if (!$pending_booking) {
        return false;
    }
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Generate final booking ID
        $booking_id = generate_booking_id();
        
        // Get bus_id from route
        $route_query = "SELECT bus_id FROM bus_routes WHERE id = " . $pending_booking['route_id'];
        $route_result = mysqli_query($conn, $route_query);
        $route = mysqli_fetch_assoc($route_result);
        $bus_id = $route['bus_id'];
        
        // Create final booking
        $seats_count = count(explode(',', $pending_booking['seats']));
        $booking_query = "INSERT INTO bookings (
            booking_id, user_id, bus_id, route_id, travel_date, 
            seats_booked, total_seats, total_amount, 
            payment_method, booking_status, payment_status
        ) VALUES (
            '$booking_id',
            {$pending_booking['user_id']},
            $bus_id,
            {$pending_booking['route_id']},
            '{$pending_booking['travel_date']}',
            '{$pending_booking['seats']}',
            $seats_count,
            $amount,
            'upi_qr',
            'confirmed',
            'paid'
        )";
        
        if (mysqli_query($conn, $booking_query)) {
            $booking_insert_id = mysqli_insert_id($conn);
            
            // Create payment record
            $payment_id = 'UPI_' . date('YmdHis') . '_' . rand(1000, 9999);
            $transaction_id = 'UPI_TXN_' . time() . '_' . rand(1000, 9999);
            
            $payment_query = "INSERT INTO payments (
                booking_id, payment_id, order_id, amount, 
                payment_method, payment_status, transaction_id,
                payment_gateway, payment_date
            ) VALUES (
                $booking_insert_id,
                '$payment_id',
                '$order_id',
                $amount,
                'upi_qr',
                'completed',
                '$transaction_id',
                'upi',
                NOW()
            )";
            
            mysqli_query($conn, $payment_query);
            
            // Mark seats as booked
            $seats = explode(',', $pending_booking['seats']);
            foreach ($seats as $seat) {
                $seat = trim($seat);
                $seat_type = strpos($seat, 'U') === 0 ? 'sleeper_upper' : 
                            (strpos($seat, 'L') === 0 ? 'sleeper_lower' : 'seater');
                
                $seat_query = "INSERT INTO seat_availability (
                    bus_id, travel_date, seat_number, seat_type, is_available, booking_id
                ) VALUES (
                    $bus_id,
                    '{$pending_booking['travel_date']}',
                    '$seat',
                    '$seat_type',
                    FALSE,
                    $booking_insert_id
                ) ON DUPLICATE KEY UPDATE is_available = FALSE, booking_id = $booking_insert_id";
                
                mysqli_query($conn, $seat_query);
            }
            
            // Update pending booking status
            complete_pending_booking($order_id, 'completed');
            
            // Commit transaction
            mysqli_commit($conn);
            
            // Store success data in session
            $_SESSION['payment_success'] = true;
            $_SESSION['last_booking_id'] = $booking_insert_id;
            $_SESSION['transaction_id'] = $transaction_id;
            
            // Clear payment session data
            unset($_SESSION['paytm_order_id']);
            unset($_SESSION['paytm_amount']);
            unset($_SESSION['payment_method']);
            unset($_SESSION['selected_seats']);
            unset($_SESSION['route_id']);
            unset($_SESSION['travel_date']);
            unset($_SESSION['total_amount']);
            unset($_SESSION['upi_order_id']);
            unset($_SESSION['upi_amount']);
            unset($_SESSION['upi_url']);
            
            return true;
            
        } else {
            throw new Exception("Booking creation failed: " . mysqli_error($conn));
        }
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        error_log("UPI payment processing failed: " . $e->getMessage());
        complete_pending_booking($order_id, 'failed');
        return false;
    }
}
}
?>