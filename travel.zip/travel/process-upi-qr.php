<?php
require_once 'config.php';
require_once 'paytm-config.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Get order details
$order_id = isset($_SESSION['paytm_order_id']) ? $_SESSION['paytm_order_id'] : generate_order_id();
$amount = isset($_SESSION['paytm_amount']) ? $_SESSION['paytm_amount'] : 0;
$user_id = $_SESSION['user_id'];

if ($amount <= 0) {
    $_SESSION['payment_error'] = 'Invalid payment amount';
    header("Location: payment-failed.php");
    exit();
}

// UPI Configuration
$upi_id = 'srtravels@paytm'; // Your UPI ID
$merchant_name = 'SR Travels';
$transaction_note = 'Bus Booking Payment - ' . $order_id;

// Generate UPI payment URL
$upi_url = generateUPIUrl($upi_id, $merchant_name, $amount, $transaction_note, $order_id);

// Generate QR Code URL (using Google Charts API)
$qr_code_url = generateQRCodeUrl($upi_url);

function generateUPIUrl($upi_id, $name, $amount, $note, $txn_id) {
    $params = [
        'pa' => $upi_id,           // Payee Address
        'pn' => $name,             // Payee Name
        'am' => $amount,           // Amount
        'tn' => $note,             // Transaction Note
        'tr' => $txn_id,           // Transaction Reference
        'cu' => 'INR'              // Currency
    ];
    
    return 'upi://pay?' . http_build_query($params);
}

function generateQRCodeUrl($data) {
    $encoded_data = urlencode($data);
    return "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" . $encoded_data;
}

// Store UPI payment details in session
$_SESSION['upi_order_id'] = $order_id;
$_SESSION['upi_amount'] = $amount;
$_SESSION['upi_url'] = $upi_url;

// Page configuration
$page_title = 'UPI QR Payment';
$page_description = 'Scan QR code with any UPI app to complete your payment';
$show_page_header = true;
$breadcrumbs = [
    ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
    ['title' => 'Book Bus', 'url' => 'enhanced-booking-system.php', 'icon' => 'fas fa-search'],
    ['title' => 'Select Seats', 'url' => 'seat-selection.php', 'icon' => 'fas fa-chair'],
    ['title' => 'Payment', 'url' => 'payment.php', 'icon' => 'fas fa-credit-card'],
    ['title' => 'UPI Payment', 'icon' => 'fas fa-qrcode']
];

// Custom CSS for UPI payment page
$custom_css = '
        .payment-container {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .payment-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .payment-header {
            background: linear-gradient(135deg, #ff9500 0%, #ff6b35 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .payment-body {
            padding: 30px;
        }
        
        .qr-container {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            margin: 20px 0;
        }
        
        .qr-code {
            border: 5px solid #fff;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .amount-display {
            font-size: 2.5rem;
            font-weight: bold;
            color: #28a745;
            margin: 20px 0;
        }
        
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin: 30px 0;
        }
        
        .step {
            flex: 1;
            text-align: center;
            padding: 15px;
            border-radius: 10px;
            margin: 0 5px;
            background: #e9ecef;
            position: relative;
        }
        
        .step.active {
            background: #28a745;
            color: white;
        }
        
        .step.completed {
            background: #6c757d;
            color: white;
        }
        
        .step-number {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #fff;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: bold;
        }
        
        .step.active .step-number {
            background: #fff;
            color: #28a745;
        }
        
        .upi-apps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .upi-app {
            text-align: center;
            padding: 15px;
            border: 2px solid #dee2e6;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            color: inherit;
        }
        
        .upi-app:hover {
            border-color: #28a745;
            transform: translateY(-2px);
            color: inherit;
        }
        
        .payment-status {
            display: none;
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .status-checking {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
        }
        
        .status-success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        
        .status-failed {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        
        @media (max-width: 768px) {
            .payment-body {
                padding: 20px;
            }
            
            .amount-display {
                font-size: 2rem;
            }
            
            .step {
                padding: 10px 5px;
                font-size: 0.9rem;
            }
        }
';

include 'includes/header.php';
?>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .payment-container {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .payment-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        
        .payment-header {
            background: linear-gradient(135deg, #ff9500 0%, #ff6b35 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .payment-body {
            padding: 30px;
        }
        
        .qr-container {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            margin: 20px 0;
        }
        
        .qr-code {
            border: 5px solid #fff;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .amount-display {
            font-size: 2.5rem;
            font-weight: bold;
            color: #28a745;
            margin: 20px 0;
        }
        
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin: 30px 0;
        }
        
        .step {
            flex: 1;
            text-align: center;
            padding: 15px;
            border-radius: 10px;
            margin: 0 5px;
            background: #e9ecef;
            position: relative;
        }
        
        .step.active {
            background: #28a745;
            color: white;
        }
        
        .step.completed {
            background: #6c757d;
            color: white;
        }
        
        .step-number {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #fff;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-weight: bold;
        }
        
        .step.active .step-number {
            background: #fff;
            color: #28a745;
        }
        
        .upi-apps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .upi-app {
            text-align: center;
            padding: 15px;
            border: 2px solid #dee2e6;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            color: inherit;
        }
        
        .upi-app:hover {
            border-color: #28a745;
            transform: translateY(-2px);
            color: inherit;
        }
        
        .upi-app img {
            width: 40px;
            height: 40px;
            margin-bottom: 5px;
        }
        
        .payment-status {
            display: none;
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .status-checking {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
        }
        
        .status-success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        
        .status-failed {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        
        @media (max-width: 768px) {
            .payment-body {
                padding: 20px;
            }
            
            .amount-display {
                font-size: 2rem;
            }
            
            .step {
                padding: 10px 5px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
<!-- Content Section -->
<section class="content-section">
    <div class="container payment-container">
        <div class="payment-card" data-aos="fade-up">
            <!-- Header -->
            <div class="payment-header">
                <h1><i class="fas fa-qrcode"></i> UPI QR Payment</h1>
                <p class="mb-0">Scan QR code with any UPI app to pay</p>
            </div>
            
            <!-- Body -->
            <div class="payment-body">
                <!-- Amount Display -->
                <div class="text-center">
                    <div class="amount-display">₹<?php echo number_format($amount, 2); ?></div>
                    <p class="text-muted">Order ID: <?php echo $order_id; ?></p>
                </div>
                
                <!-- Payment Steps -->
                <div class="step-indicator">
                    <div class="step active">
                        <div class="step-number">1</div>
                        <div>Scan QR</div>
                    </div>
                    <div class="step">
                        <div class="step-number">2</div>
                        <div>Verify Amount</div>
                    </div>
                    <div class="step">
                        <div class="step-number">3</div>
                        <div>Pay & Confirm</div>
                    </div>
                </div>
                
                <!-- QR Code -->
                <div class="qr-container">
                    <img src="<?php echo $qr_code_url; ?>" alt="UPI QR Code" class="qr-code" id="qrCode">
                    <h5>Scan with any UPI app</h5>
                    <p class="text-muted mb-0">Point your camera at the QR code to pay</p>
                </div>
                
                <!-- UPI Apps -->
                <div class="text-center mb-3">
                    <h6>Or open directly in your UPI app:</h6>
                </div>
                
                <div class="upi-apps">
                    <a href="<?php echo $upi_url; ?>" class="upi-app" target="_blank">
                        <i class="fas fa-mobile-alt fa-2x text-primary"></i>
                        <div><small>PhonePe</small></div>
                    </a>
                    <a href="<?php echo $upi_url; ?>" class="upi-app" target="_blank">
                        <i class="fab fa-google-pay fa-2x text-success"></i>
                        <div><small>Google Pay</small></div>
                    </a>
                    <a href="<?php echo $upi_url; ?>" class="upi-app" target="_blank">
                        <i class="fas fa-wallet fa-2x text-info"></i>
                        <div><small>Paytm</small></div>
                    </a>
                    <a href="<?php echo $upi_url; ?>" class="upi-app" target="_blank">
                        <i class="fas fa-university fa-2x text-warning"></i>
                        <div><small>BHIM</small></div>
                    </a>
                </div>
                
                <!-- Payment Status -->
                <div class="payment-status status-checking" id="paymentStatus">
                    <div class="d-flex align-items-center justify-content-center">
                        <div class="spinner-border spinner-border-sm me-2"></div>
                        <span>Waiting for payment confirmation...</span>
                    </div>
                    <small class="d-block mt-2">This may take a few seconds after you complete the payment</small>
                </div>
                
                <!-- Instructions -->
                <div class="alert alert-info">
                    <h6><i class="fas fa-info-circle"></i> How to pay:</h6>
                    <ol class="mb-0">
                        <li>Open any UPI app (PhonePe, Google Pay, Paytm, etc.)</li>
                        <li>Scan the QR code or click on app icons above</li>
                        <li>Verify the amount and merchant details</li>
                        <li>Enter your UPI PIN to complete payment</li>
                        <li>Wait for confirmation on this page</li>
                    </ol>
                </div>
                
                <!-- Action Buttons -->
                <div class="d-grid gap-2">
                    <button class="btn btn-success btn-lg" onclick="checkPaymentStatus()">
                        <i class="fas fa-sync me-2"></i>
                        Check Payment Status
                    </button>
                    
                    <!-- Demo/Test Button -->
                    <button class="btn btn-warning btn-lg" onclick="simulatePaymentSuccess()" style="background: linear-gradient(135deg, #ff9500, #ff6b35);">
                        <i class="fas fa-check-circle me-2"></i>
                        Mark as Paid (Demo)
                    </button>
                    
                    <div class="row g-2">
                        <div class="col-6">
                            <a href="payment.php" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-arrow-left me-2"></i>
                                Back
                            </a>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-outline-primary w-100" onclick="refreshQR()">
                                <i class="fas fa-redo me-2"></i>
                                Refresh QR
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Support Info -->
                <div class="text-center mt-4">
                    <small class="text-muted">
                        <i class="fas fa-shield-alt"></i>
                        Secure UPI Payment | 
                        <i class="fas fa-phone"></i>
                        Support: +91 9356437871
                    </small>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Custom JavaScript for UPI payment
$custom_js = '
        let paymentCheckInterval;
        let checkCount = 0;
        const maxChecks = 60; // Check for 5 minutes (60 * 5 seconds)
        
        // Start checking payment status automatically
        function startPaymentCheck() {
            document.getElementById("paymentStatus").style.display = "block";
            
            paymentCheckInterval = setInterval(function() {
                checkPaymentStatus(false);
                checkCount++;
                
                if (checkCount >= maxChecks) {
                    clearInterval(paymentCheckInterval);
                    showPaymentTimeout();
                }
            }, 5000); // Check every 5 seconds
        }
        
        function checkPaymentStatus(manual = true) {
            if (manual) {
                document.getElementById("paymentStatus").style.display = "block";
                document.getElementById("paymentStatus").className = "payment-status status-checking";
                document.getElementById("paymentStatus").innerHTML = 
                    "<div class=\"d-flex align-items-center justify-content-center\">" +
                    "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
                    "<span>Checking payment status...</span>" +
                    "</div>";
            }
            
            fetch("ajax-handler.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: "action=check_upi_payment&order_id=' . $order_id . '"
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    // Payment successful
                    clearInterval(paymentCheckInterval);
                    showPaymentSuccess();
                    setTimeout(() => {
                        window.location.href = "booking-confirm.php";
                    }, 2000);
                } else if (data.status === "failed") {
                    // Payment failed
                    clearInterval(paymentCheckInterval);
                    showPaymentFailed();
                } else if (manual) {
                    // Still pending
                    document.getElementById("paymentStatus").className = "payment-status status-checking";
                    document.getElementById("paymentStatus").innerHTML = 
                        "<div class=\"d-flex align-items-center justify-content-center\">" +
                        "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
                        "<span>Payment not received yet. Please complete the payment.</span>" +
                        "</div>";
                }
            })
            .catch(error => {
                console.error("Error checking payment status:", error);
                if (manual) {
                    document.getElementById("paymentStatus").className = "payment-status status-failed";
                    document.getElementById("paymentStatus").innerHTML = 
                        "<i class=\"fas fa-exclamation-triangle me-2\"></i>" +
                        "Error checking payment status. Please try again.";
                }
            });
        }
        
        // Demo function to simulate payment success
        function simulatePaymentSuccess() {
            if (confirm("This will mark the payment as successful for demo purposes. Continue?")) {
                document.getElementById("paymentStatus").style.display = "block";
                document.getElementById("paymentStatus").className = "payment-status status-checking";
                document.getElementById("paymentStatus").innerHTML = 
                    "<div class=\"d-flex align-items-center justify-content-center\">" +
                    "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
                    "<span>Processing demo payment...</span>" +
                    "</div>";
                
                // Simulate payment processing
                setTimeout(() => {
                    fetch("payment-callback.php?test=success&order_id=' . $order_id . '&amount=' . $amount . '")
                        .then(() => {
                            showPaymentSuccess();
                            setTimeout(() => {
                                window.location.href = "booking-confirm.php";
                            }, 2000);
                        })
                        .catch(error => {
                            console.error("Error processing demo payment:", error);
                            showPaymentFailed();
                        });
                }, 1500);
            }
        }
        
        function showPaymentSuccess() {
            document.getElementById("paymentStatus").className = "payment-status status-success";
            document.getElementById("paymentStatus").innerHTML = 
                "<i class=\"fas fa-check-circle me-2\"></i>" +
                "Payment successful! Redirecting to confirmation page...";
            
            // Update steps
            document.querySelectorAll(".step").forEach(step => {
                step.classList.add("completed");
                step.classList.remove("active");
            });
        }
        
        function showPaymentFailed() {
            document.getElementById("paymentStatus").className = "payment-status status-failed";
            document.getElementById("paymentStatus").innerHTML = 
                "<i class=\"fas fa-times-circle me-2\"></i>" +
                "Payment failed or cancelled. Please try again.";
        }
        
        function showPaymentTimeout() {
            document.getElementById("paymentStatus").className = "payment-status status-failed";
            document.getElementById("paymentStatus").innerHTML = 
                "<i class=\"fas fa-clock me-2\"></i>" +
                "Payment timeout. Please refresh the page and try again.";
        }
        
        function refreshQR() {
            // Refresh the QR code
            const qrCode = document.getElementById("qrCode");
            const currentSrc = qrCode.src;
            qrCode.src = currentSrc + "&t=" + Date.now();
            
            // Reset payment check
            checkCount = 0;
            if (paymentCheckInterval) {
                clearInterval(paymentCheckInterval);
            }
            startPaymentCheck();
        }
        
        // Start payment checking when page loads
        document.addEventListener("DOMContentLoaded", function() {
            setTimeout(startPaymentCheck, 2000); // Start checking after 2 seconds
        });
        
        // Handle page visibility change
        document.addEventListener("visibilitychange", function() {
            if (document.hidden) {
                // Page is hidden, stop checking
                if (paymentCheckInterval) {
                    clearInterval(paymentCheckInterval);
                }
            } else {
                // Page is visible again, resume checking
                if (checkCount < maxChecks) {
                    startPaymentCheck();
                }
            }
        });
        
        // Prevent accidental navigation
        window.addEventListener("beforeunload", function(e) {
            if (paymentCheckInterval) {
                const confirmationMessage = "Payment is in progress. Are you sure you want to leave?";
                e.returnValue = confirmationMessage;
                return confirmationMessage;
            }
        });
';

include 'includes/footer.php';
?>