<?php
require_once 'config.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Get order details
$order_id = isset($_SESSION['paytm_order_id']) ? $_SESSION['paytm_order_id'] : generate_order_id();
$amount = isset($_SESSION['paytm_amount']) ? $_SESSION['paytm_amount'] : 0;
$user_id = $_SESSION['user_id'];

if ($amount <= 0) {
    $_SESSION['payment_error'] = 'Invalid payment amount';
    header("Location: payment-failed.php");
    exit();
}

// Amazon Pay Configuration
$merchant_name = 'SR Travels';
$transaction_note = 'Bus Booking Payment - ' . $order_id;

// Page configuration
$page_title = 'Amazon Pay Payment';
$page_description = 'Pay securely with Amazon Pay';
$show_page_header = true;
$breadcrumbs = [
    ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
    ['title' => 'Book Bus', 'url' => 'enhanced-booking-system.php', 'icon' => 'fas fa-search'],
    ['title' => 'Select Seats', 'url' => 'seat-selection.php', 'icon' => 'fas fa-chair'],
    ['title' => 'Payment', 'url' => 'payment.php', 'icon' => 'fas fa-credit-card'],
    ['title' => 'Amazon Pay', 'icon' => 'fab fa-amazon-pay']
];

// Custom CSS
$custom_css = '
    .payment-container {
        max-width: 600px;
        margin: 0 auto;
    }
    
    .payment-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        margin-bottom: 30px;
    }
    
    .payment-header {
        background: linear-gradient(135deg, #ff9900 0%, #ff6600 100%);
        color: white;
        padding: 30px;
        text-align: center;
    }
    
    .amazon-logo {
        font-size: 3rem;
        margin-bottom: 15px;
    }
    
    .amount-display {
        font-size: 2.5rem;
        font-weight: bold;
        color: #28a745;
        margin: 20px 0;
    }
    
    .payment-form {
        background: #f8f9fa;
        border-radius: 15px;
        padding: 25px;
        margin: 20px 0;
    }
    
    .benefit-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
        padding: 10px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    
    .benefit-icon {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: #ff9900;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 15px;
        font-size: 0.9rem;
    }
';

include 'includes/header.php';
?>

<!-- Content Section -->
<section class="content-section">
    <div class="container payment-container">
        <div class="payment-card" data-aos="fade-up">
            <!-- Header -->
            <div class="payment-header">
                <div class="amazon-logo">
                    <i class="fab fa-amazon-pay"></i>
                </div>
                <h1>Amazon Pay</h1>
                <p class="mb-0">Pay with your Amazon Pay balance</p>
            </div>
            
            <!-- Body -->
            <div class="card-body p-4">
                <!-- Amount Display -->
                <div class="text-center">
                    <div class="amount-display">₹<?php echo number_format($amount, 2); ?></div>
                    <p class="text-muted">Order ID: <?php echo $order_id; ?></p>
                </div>
                
                <!-- Benefits -->
                <div class="payment-form">
                    <h5 class="mb-3">
                        <i class="fas fa-gift me-2"></i>
                        Amazon Pay Benefits
                    </h5>
                    
                    <div class="benefit-item">
                        <div class="benefit-icon">
                            <i class="fas fa-coins"></i>
                        </div>
                        <div>
                            <strong>Cashback Rewards</strong>
                            <br><small class="text-muted">Get up to 5% cashback on payments</small>
                        </div>
                    </div>
                    
                    <div class="benefit-item">
                        <div class="benefit-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <div>
                            <strong>Secure Payments</strong>
                            <br><small class="text-muted">Protected by Amazon's security</small>
                        </div>
                    </div>
                    
                    <div class="benefit-item">
                        <div class="benefit-icon">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <div>
                            <strong>Instant Processing</strong>
                            <br><small class="text-muted">Quick and seamless payments</small>
                        </div>
                    </div>
                </div>
                
                <!-- Login Form Simulation -->
                <div class="payment-form">
                    <h6 class="mb-3">Login to Amazon Pay</h6>
                    <div class="mb-3">
                        <label class="form-label">Email or Mobile Number</label>
                        <input type="text" class="form-control" placeholder="Enter your Amazon account details" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" placeholder="Enter your password" readonly>
                    </div>
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        This is a demo interface. In production, you would be redirected to Amazon Pay.
                    </small>
                </div>
                
                <!-- Action Buttons -->
                <div class="d-grid gap-2">
                    <button class="btn btn-primary btn-lg" onclick="simulateAmazonPayLogin()" style="background: linear-gradient(135deg, #ff9900, #ff6600);">
                        <i class="fab fa-amazon-pay me-2"></i>
                        Continue with Amazon Pay
                    </button>
                    
                    <button class="btn btn-success btn-lg" onclick="checkPaymentStatus()">
                        <i class="fas fa-sync me-2"></i>
                        Check Payment Status
                    </button>
                    
                    <!-- Demo Button -->
                    <button class="btn btn-warning btn-lg" onclick="simulatePaymentSuccess()">
                        <i class="fas fa-check-circle me-2"></i>
                        Mark as Paid (Demo)
                    </button>
                    
                    <div class="row g-2">
                        <div class="col-6">
                            <a href="payment.php" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-arrow-left me-2"></i>
                                Back
                            </a>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-outline-info w-100" onclick="window.location.reload()">
                                <i class="fas fa-redo me-2"></i>
                                Refresh
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Payment Status -->
                <div class="alert alert-info mt-3" id="paymentStatus" style="display: none;">
                    <div class="d-flex align-items-center">
                        <div class="spinner-border spinner-border-sm me-2"></div>
                        <span>Processing Amazon Pay payment...</span>
                    </div>
                </div>
                
                <!-- Support Info -->
                <div class="text-center mt-4">
                    <small class="text-muted">
                        <i class="fas fa-shield-alt"></i>
                        Secure Amazon Pay Payment | 
                        <i class="fas fa-phone"></i>
                        Support: +91 9356437871
                    </small>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
$custom_js = '
    function simulateAmazonPayLogin() {
        document.getElementById("paymentStatus").style.display = "block";
        document.getElementById("paymentStatus").className = "alert alert-info";
        document.getElementById("paymentStatus").innerHTML = 
            "<div class=\"d-flex align-items-center\">" +
            "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
            "<span>Redirecting to Amazon Pay...</span>" +
            "</div>";
        
        setTimeout(() => {
            document.getElementById("paymentStatus").innerHTML = 
                "<div class=\"d-flex align-items-center\">" +
                "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
                "<span>Processing payment with Amazon Pay...</span>" +
                "</div>";
            
            setTimeout(() => {
                simulatePaymentSuccess();
            }, 3000);
        }, 2000);
    }
    
    function checkPaymentStatus() {
        document.getElementById("paymentStatus").style.display = "block";
        document.getElementById("paymentStatus").className = "alert alert-info";
        document.getElementById("paymentStatus").innerHTML = 
            "<div class=\"d-flex align-items-center\">" +
            "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
            "<span>Checking payment status...</span>" +
            "</div>";
        
        fetch("ajax-handler.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: "action=check_upi_payment&order_id=' . $order_id . '"
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                document.getElementById("paymentStatus").className = "alert alert-success";
                document.getElementById("paymentStatus").innerHTML = 
                    "<i class=\"fas fa-check-circle me-2\"></i>Payment successful! Redirecting...";
                setTimeout(() => {
                    window.location.href = "booking-confirm.php";
                }, 2000);
            } else if (data.status === "failed") {
                document.getElementById("paymentStatus").className = "alert alert-danger";
                document.getElementById("paymentStatus").innerHTML = 
                    "<i class=\"fas fa-times-circle me-2\"></i>Payment failed. Please try again.";
            } else {
                document.getElementById("paymentStatus").className = "alert alert-warning";
                document.getElementById("paymentStatus").innerHTML = 
                    "<i class=\"fas fa-clock me-2\"></i>Payment pending. Please complete the payment.";
            }
        })
        .catch(error => {
            document.getElementById("paymentStatus").className = "alert alert-danger";
            document.getElementById("paymentStatus").innerHTML = 
                "<i class=\"fas fa-exclamation-triangle me-2\"></i>Error checking payment status.";
        });
    }
    
    function simulatePaymentSuccess() {
        if (confirm("This will mark the payment as successful for demo purposes. Continue?")) {
            document.getElementById("paymentStatus").style.display = "block";
            document.getElementById("paymentStatus").className = "alert alert-info";
            document.getElementById("paymentStatus").innerHTML = 
                "<div class=\"d-flex align-items-center\">" +
                "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
                "<span>Processing demo payment...</span>" +
                "</div>";
            
            setTimeout(() => {
                fetch("payment-callback.php?test=success&order_id=' . $order_id . '&amount=' . $amount . '")
                    .then(() => {
                        document.getElementById("paymentStatus").className = "alert alert-success";
                        document.getElementById("paymentStatus").innerHTML = 
                            "<i class=\"fas fa-check-circle me-2\"></i>Payment successful! Redirecting...";
                        setTimeout(() => {
                            window.location.href = "booking-confirm.php";
                        }, 2000);
                    })
                    .catch(error => {
                        document.getElementById("paymentStatus").className = "alert alert-danger";
                        document.getElementById("paymentStatus").innerHTML = 
                            "<i class=\"fas fa-times-circle me-2\"></i>Demo payment failed.";
                    });
            }, 1500);
        }
    }
';

include 'includes/footer.php';
?>