-- Create Database
CREATE DATABASE IF NOT EXISTS srtravels;
USE srtravels;

-- Users Table (Updated with OTP support)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(15),
    address TEXT,
    user_type ENUM('user', 'admin') DEFAULT 'user',
    otp_code VARCHAR(10) NULL,
    otp_expiry DATETIME NULL,
    otp_attempts INT DEFAULT 0,
    last_otp_sent DATETIME NULL,
    reset_token VARCHAR(255) NULL,
    reset_token_expiry DATETIME NULL,
    is_email_verified BOOLEAN DEFAULT FALSE,
    is_phone_verified BOOLEAN DEFAULT FALSE,
    profile_image VARCHAR(255) NULL,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    last_login DATETIME NULL,
    login_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Admin Table (separate table for admin-specific data)
CREATE TABLE admin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    admin_role ENUM('super_admin', 'manager', 'operator') DEFAULT 'operator',
    permissions TEXT,
    last_login DATETIME,
    login_count INT DEFAULT 0,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Buses Table
CREATE TABLE buses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bus_number VARCHAR(20) UNIQUE NOT NULL,
    bus_name VARCHAR(100) NOT NULL,
    bus_type ENUM('seater', 'sleeper') NOT NULL,
    total_seats INT NOT NULL,
    available_seats INT NOT NULL,
    amenities TEXT,
    bus_images TEXT,
    facilities TEXT,
    status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admin(id) ON DELETE SET NULL
);

-- Bus Routes Table
CREATE TABLE bus_routes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bus_id INT,
    from_city VARCHAR(100) NOT NULL,
    to_city VARCHAR(100) NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    duration VARCHAR(20),
    frequency VARCHAR(50),
    fare DECIMAL(10,2) NOT NULL,
    route_details TEXT,
    boarding_points TEXT,
    dropping_points TEXT,
    route_distance DECIMAL(8,2),
    is_active BOOLEAN DEFAULT TRUE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (bus_id) REFERENCES buses(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES admin(id) ON DELETE SET NULL
);

-- Bookings Table
CREATE TABLE bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id VARCHAR(20) UNIQUE NOT NULL,
    user_id INT,
    bus_id INT,
    route_id INT,
    travel_date DATE NOT NULL,
    seats_booked TEXT NOT NULL,
    total_seats INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    booking_status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    payment_method VARCHAR(50),
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    cancellation_date DATETIME NULL,
    cancellation_reason TEXT NULL,
    refund_amount DECIMAL(10,2) DEFAULT 0,
    is_refund_processed BOOLEAN DEFAULT FALSE,
    boarding_pass_generated BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (bus_id) REFERENCES buses(id),
    FOREIGN KEY (route_id) REFERENCES bus_routes(id)
);

-- Seat Availability Table
CREATE TABLE seat_availability (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bus_id INT,
    travel_date DATE NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    seat_type ENUM('seater', 'sleeper_upper', 'sleeper_lower') NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    booking_id INT NULL,
    price DECIMAL(10,2),
    UNIQUE KEY unique_seat (bus_id, travel_date, seat_number),
    FOREIGN KEY (bus_id) REFERENCES buses(id),
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
);

-- Pending Bookings Table (for payment processing)
CREATE TABLE pending_bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id VARCHAR(100) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    route_id INT NOT NULL,
    travel_date DATE NOT NULL,
    seats TEXT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_gateway VARCHAR(50) DEFAULT 'paytm',
    status ENUM('pending', 'completed', 'failed', 'expired') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    INDEX idx_order_id (order_id),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (route_id) REFERENCES bus_routes(id)
);

-- Payments Table
CREATE TABLE payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT,
    payment_id VARCHAR(50) UNIQUE,
    order_id VARCHAR(100),
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_status VARCHAR(50) NOT NULL,
    payment_gateway VARCHAR(50) DEFAULT 'paytm',
    transaction_id VARCHAR(100),
    bank_name VARCHAR(100),
    bank_txn_id VARCHAR(100),
    payment_mode VARCHAR(50),
    currency VARCHAR(10) DEFAULT 'INR',
    gateway_response TEXT,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    refund_date DATETIME NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(id),
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_order_id (order_id)
);

-- Bus Tracking Table
CREATE TABLE bus_tracking (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bus_id INT,
    current_location VARCHAR(100),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    speed DECIMAL(5,2),
    status ENUM('moving', 'stopped', 'breakdown', 'maintenance') DEFAULT 'moving',
    estimated_arrival_time DATETIME,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (bus_id) REFERENCES buses(id)
);

-- OTP Logs Table
CREATE TABLE otp_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) NOT NULL,
    otp_code VARCHAR(10) NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    status ENUM('sent', 'verified', 'failed', 'expired') DEFAULT 'sent',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_status (status)
);

-- Admin Activity Log
CREATE TABLE admin_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    admin_id INT,
    activity VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admin(id) ON DELETE CASCADE
);

-- Notifications Table
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    admin_id INT NULL,
    title VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'success', 'warning', 'danger') DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    is_email_sent BOOLEAN DEFAULT FALSE,
    is_sms_sent BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES admin(id) ON DELETE CASCADE
);

-- Refunds Table
CREATE TABLE refunds (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT,
    payment_id INT,
    user_id INT,
    refund_amount DECIMAL(10,2) NOT NULL,
    refund_reason TEXT,
    status ENUM('pending', 'processed', 'failed') DEFAULT 'pending',
    transaction_id VARCHAR(100),
    processed_by INT NULL,
    processed_date DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id),
    FOREIGN KEY (payment_id) REFERENCES payments(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (processed_by) REFERENCES admin(id) ON DELETE SET NULL
);

-- Cancellation Policy Table
CREATE TABLE cancellation_policies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    hours_before_departure INT NOT NULL,
    refund_percentage DECIMAL(5,2) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admin(id) ON DELETE SET NULL
);

-- Route Stops Table
CREATE TABLE route_stops (
    id INT PRIMARY KEY AUTO_INCREMENT,
    route_id INT,
    stop_name VARCHAR(100) NOT NULL,
    arrival_time TIME NULL,
    departure_time TIME NULL,
    stop_order INT NOT NULL,
    distance_from_start DECIMAL(8,2),
    fare_from_start DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES bus_routes(id) ON DELETE CASCADE
);

-- User Preferences Table
CREATE TABLE user_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    seat_preference VARCHAR(20),
    notification_email BOOLEAN DEFAULT TRUE,
    notification_sms BOOLEAN DEFAULT TRUE,
    notification_push BOOLEAN DEFAULT TRUE,
    preferred_payment_method VARCHAR(50),
    language VARCHAR(10) DEFAULT 'en',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Audit Log Table
CREATE TABLE audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    table_name VARCHAR(50) NOT NULL,
    record_id INT NOT NULL,
    action ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    old_data JSON NULL,
    new_data JSON NULL,
    performed_by INT NULL,
    user_type ENUM('user', 'admin', 'system') DEFAULT 'system',
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_action_date (action, created_at)
);

-- Email Templates Table
CREATE TABLE email_templates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    template_name VARCHAR(100) UNIQUE NOT NULL,
    template_subject VARCHAR(255) NOT NULL,
    template_body TEXT NOT NULL,
    template_variables TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- SMS Templates Table
CREATE TABLE sms_templates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    template_name VARCHAR(100) UNIQUE NOT NULL,
    template_body TEXT NOT NULL,
    template_variables TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Indexes for Performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_bookings_user_id ON bookings(user_id);
CREATE INDEX idx_bookings_booking_date ON bookings(booking_date);
CREATE INDEX idx_bookings_travel_date ON bookings(travel_date);
CREATE INDEX idx_bus_routes_from_to ON bus_routes(from_city, to_city);
CREATE INDEX idx_seat_availability_date ON seat_availability(travel_date);
CREATE INDEX idx_payments_booking_id ON payments(booking_id);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);

-- Insert Sample Data
-- First, insert users
INSERT INTO users (username, email, password, full_name, phone, user_type) VALUES
('admin', 'admin@srtravels.com', '$2y$10$QPLXqQdQLQcXN34n98yPmOZXKJs44dVK.B/E1vgrBkv6sNzxPGFXy', 'Admin User', '9876543210', 'admin'),
('sid_umarane', 'sid@gmail.com', '$2y$10$QPLXqQdQLQcXN34n98yPmOZXKJs44dVK.B/E1vgrBkv6sNzxPGFXy', 'Sid Umarane', '9876543211', 'user'),
('manager1', 'manager@srtravels.com', '$2y$10$QPLXqQdQLQcXN34n98yPmOZXKJs44dVK.B/E1vgrBkv6sNzxPGFXy', 'Manager User', '9876543212', 'admin'),
('customer1', 'customer1@srtravels.com', '$2y$10$QPLXqQdQLQcXN34n98yPmOZXKJs44dVK.B/E1vgrBkv6sNzxPGFXy', 'Customer One', '9876543213', 'user'),
('customer2', 'customer2@srtravels.com', '$2y$10$QPLXqQdQLQcXN34n98yPmOZXKJs44dVK.B/E1vgrBkv6sNzxPGFXy', 'Customer Two', '9876543214', 'user');

-- Then, insert admin records
INSERT INTO admin (user_id, admin_role, permissions) VALUES
(1, 'super_admin', 'all'),
(3, 'manager', 'manage_buses,manage_routes,view_reports,manage_bookings');

-- Insert Sample Buses
INSERT INTO buses (bus_number, bus_name, bus_type, total_seats, available_seats, amenities, facilities) VALUES
('SRT-S001', 'Volvo AC Seater', 'seater', 40, 40, 'AC, WiFi, Charging Points, Water Bottle, Blanket', 'Toilet, Reading Light, Emergency Exit'),
('SRT-S002', 'Mercedes Seater', 'seater', 40, 40, 'AC, WiFi, Entertainment, Snacks', 'Toilet, Reading Light, GPS Tracking'),
('SRT-SL001', 'Volvo AC Sleeper', 'sleeper', 24, 24, 'AC, WiFi, Blanket, Privacy Curtain, Reading Light', 'Toilet, Luggage Space, Emergency Kit'),
('SRT-SL002', 'Scania Sleeper', 'sleeper', 24, 24, 'AC, WiFi, Blanket, Water Bottle, Snacks', 'Toilet, Charging Points, GPS Tracking');

-- Insert Sample Routes
INSERT INTO bus_routes (bus_id, from_city, to_city, departure_time, arrival_time, duration, fare, route_distance, boarding_points, dropping_points, created_by) VALUES
(1, 'Delhi', 'Jaipur', '08:00:00', '14:00:00', '6h', 600.00, 280.50, 'ISBT Delhi, Connaught Place', 'Jaipur Bus Stand, Sindhi Camp', 1),
(1, 'Jaipur', 'Delhi', '15:00:00', '21:00:00', '6h', 600.00, 280.50, 'Jaipur Bus Stand, Sindhi Camp', 'ISBT Delhi, Connaught Place', 1),
(2, 'Mumbai', 'Pune', '10:30:00', '16:00:00', '5.5h', 500.00, 150.75, 'Mumbai Central, Dadar', 'Pune Station, Shivaji Nagar', 1),
(3, 'Delhi', 'Jaipur', '22:00:00', '06:00:00', '8h', 800.00, 280.50, 'ISBT Delhi, Kashmere Gate', 'Jaipur Bus Stand', 1),
(4, 'Bangalore', 'Chennai', '21:00:00', '05:00:00', '8h', 750.00, 350.25, 'Majestic Bus Stand, Electronic City', 'CMBT Chennai, Koyambedu', 1);

-- Insert Route Stops
INSERT INTO route_stops (route_id, stop_name, arrival_time, departure_time, stop_order, distance_from_start, fare_from_start) VALUES
(1, 'Delhi ISBT', NULL, '08:00:00', 1, 0, 0),
(1, 'Gurgaon', '08:45:00', '08:50:00', 2, 25.5, 100),
(1, 'Manesar', '09:30:00', '09:35:00', 3, 60.2, 200),
(1, 'Jaipur', '14:00:00', NULL, 4, 280.5, 600),
(3, 'Mumbai Central', NULL, '10:30:00', 1, 0, 0),
(3, 'Panvel', '11:30:00', '11:35:00', 2, 45.3, 150),
(3, 'Lonavala', '13:00:00', '13:10:00', 3, 100.2, 300),
(3, 'Pune Station', '16:00:00', NULL, 4, 150.75, 500);

-- Insert Sample Seat Availability
INSERT INTO seat_availability (bus_id, travel_date, seat_number, seat_type, is_available, price) VALUES
-- For seater bus SRT-S001 on tomorrow's date
(1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '1', 'seater', TRUE, 600),
(1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '2', 'seater', TRUE, 600),
(1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '3', 'seater', TRUE, 600),
(1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '4', 'seater', TRUE, 600),
-- For sleeper bus SRT-SL001 on tomorrow's date
(3, DATE_ADD(CURDATE(), INTERVAL 1 DAY), 'U1', 'sleeper_upper', TRUE, 800),
(3, DATE_ADD(CURDATE(), INTERVAL 1 DAY), 'L1', 'sleeper_lower', TRUE, 900),
(3, DATE_ADD(CURDATE(), INTERVAL 1 DAY), 'U2', 'sleeper_upper', TRUE, 800),
(3, DATE_ADD(CURDATE(), INTERVAL 1 DAY), 'L2', 'sleeper_lower', TRUE, 900);

-- Insert Sample Bookings
INSERT INTO bookings (booking_id, user_id, bus_id, route_id, travel_date, seats_booked, total_seats, total_amount, booking_status, payment_status, payment_method) VALUES
('BK-' || DATE_FORMAT(NOW(), '%Y%m%d') || '-A1B2C3', 2, 1, 1, DATE_ADD(CURDATE(), INTERVAL 2 DAY), '1,2,3', 3, 1800, 'confirmed', 'paid', 'paytm'),
('BK-' || DATE_FORMAT(NOW(), '%Y%m%d') || '-D4E5F6', 4, 3, 4, DATE_ADD(CURDATE(), INTERVAL 3 DAY), 'U1,U2', 2, 1600, 'confirmed', 'paid', 'card'),
('BK-' || DATE_FORMAT(NOW(), '%Y%m%d') || '-G7H8I9', 5, 2, 3, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '5,6', 2, 1000, 'pending', 'pending', NULL);

-- Insert Sample Payments
INSERT INTO payments (booking_id, payment_id, order_id, amount, payment_method, payment_status, transaction_id, bank_name, payment_gateway) VALUES
(1, 'PAY-' || DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') || '-001', 'ORD-' || DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') || '-001', 1800, 'paytm', 'completed', 'TXN' || FLOOR(RAND() * 1000000), 'PayTM', 'paytm'),
(2, 'PAY-' || DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') || '-002', 'ORD-' || DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') || '-002', 1600, 'card', 'completed', 'TXN' || FLOOR(RAND() * 1000000), 'HDFC Bank', 'paytm');

-- Insert Cancellation Policies
INSERT INTO cancellation_policies (hours_before_departure, refund_percentage, description) VALUES
(48, 90.00, 'Cancel 48+ hours before departure for 90% refund'),
(24, 75.00, 'Cancel 24-48 hours before departure for 75% refund'),
(12, 50.00, 'Cancel 12-24 hours before departure for 50% refund'),
(6, 25.00, 'Cancel 6-12 hours before departure for 25% refund'),
(0, 0.00, 'Cancel less than 6 hours before departure - No refund');

-- Insert Email Templates
INSERT INTO email_templates (template_name, template_subject, template_body, template_variables) VALUES
('booking_confirmation', 'Your SR Travels Booking Confirmation - {booking_id}', '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <h2 style="color: #2a6ebb;">Booking Confirmed!</h2>
    <p>Dear {customer_name},</p>
    <p>Your booking has been confirmed. Here are your booking details:</p>
    <table style="width: 100%; border-collapse: collapse;">
        <tr><td><strong>Booking ID:</strong></td><td>{booking_id}</td></tr>
        <tr><td><strong>Route:</strong></td><td>{from_city} to {to_city}</td></tr>
        <tr><td><strong>Travel Date:</strong></td><td>{travel_date}</td></tr>
        <tr><td><strong>Departure Time:</strong></td><td>{departure_time}</td></tr>
        <tr><td><strong>Seats:</strong></td><td>{seats_booked}</td></tr>
        <tr><td><strong>Total Amount:</strong></td><td>₹{total_amount}</td></tr>
    </table>
    <p>Please carry a valid ID proof during boarding.</p>
    <p>Thank you for choosing SR Travels!</p>
</div>', 'booking_id,customer_name,from_city,to_city,travel_date,departure_time,seats_booked,total_amount'),

('payment_success', 'Payment Successful - SR Travels', '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <h2 style="color: #28a745;">Payment Successful!</h2>
    <p>Dear {customer_name},</p>
    <p>Your payment of ₹{amount} has been successfully processed.</p>
    <p><strong>Transaction ID:</strong> {transaction_id}</p>
    <p><strong>Payment Date:</strong> {payment_date}</p>
    <p>Your booking is now confirmed. You can view your booking details in your account.</p>
    <p>Thank you for choosing SR Travels!</p>
</div>', 'customer_name,amount,transaction_id,payment_date'),

('password_reset', 'Reset Your SR Travels Password', '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <h2 style="color: #2a6ebb;">Password Reset Request</h2>
    <p>You requested to reset your password. Click the link below to reset your password:</p>
    <p><a href="{reset_link}" style="background-color: #2a6ebb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Reset Password</a></p>
    <p>This link will expire in 1 hour.</p>
    <p>If you didn''t request this, please ignore this email.</p>
</div>', 'reset_link');

-- Insert SMS Templates
INSERT INTO sms_templates (template_name, template_body, template_variables) VALUES
('booking_confirmation_sms', 'Your SR Travels booking {booking_id} is confirmed. {from_city} to {to_city} on {travel_date} at {departure_time}. Seats: {seats_booked}. Amount: ₹{total_amount}.', 'booking_id,from_city,to_city,travel_date,departure_time,seats_booked,total_amount'),
('otp_sms', 'Your SR Travels OTP is {otp_code}. Valid for 10 minutes. Do not share with anyone.', 'otp_code'),
('payment_success_sms', 'Payment of ₹{amount} successful for booking {booking_id}. Transaction ID: {transaction_id}.', 'amount,booking_id,transaction_id');

-- Insert User Preferences
INSERT INTO user_preferences (user_id, seat_preference, notification_email, notification_sms, preferred_payment_method) VALUES
(2, 'window', TRUE, TRUE, 'paytm'),
(4, 'aisle', TRUE, FALSE, 'card'),
(5, 'window', FALSE, TRUE, 'upi');

-- Insert Bus Tracking Data
INSERT INTO bus_tracking (bus_id, current_location, latitude, longitude, speed, status, estimated_arrival_time) VALUES
(1, 'Delhi-Gurgaon Highway', 28.4595, 77.0266, 65.5, 'moving', DATE_ADD(NOW(), INTERVAL 4 HOUR)),
(3, 'Delhi-Jaipur Expressway', 27.0238, 76.4965, 70.2, 'moving', DATE_ADD(NOW(), INTERVAL 6 HOUR));

-- Create Views for Reporting
CREATE VIEW booking_summary AS
SELECT 
    b.booking_id,
    u.full_name as customer_name,
    u.email,
    u.phone,
    r.from_city,
    r.to_city,
    b.travel_date,
    b.seats_booked,
    b.total_amount,
    b.booking_status,
    b.payment_status,
    b.booking_date
FROM bookings b
JOIN users u ON b.user_id = u.id
JOIN bus_routes r ON b.route_id = r.id;

CREATE VIEW revenue_report AS
SELECT 
    DATE(b.booking_date) as booking_day,
    COUNT(*) as total_bookings,
    SUM(b.total_amount) as daily_revenue,
    AVG(b.total_amount) as avg_booking_value
FROM bookings b
WHERE b.payment_status = 'paid'
GROUP BY DATE(b.booking_date);

CREATE VIEW bus_utilization AS
SELECT 
    bu.bus_number,
    bu.bus_name,
    bu.bus_type,
    COUNT(b.id) as total_bookings,
    SUM(b.total_seats) as total_seats_sold,
    bu.total_seats,
    ROUND((SUM(b.total_seats) / (bu.total_seats * COUNT(DISTINCT b.travel_date))) * 100, 2) as utilization_percentage
FROM buses bu
LEFT JOIN bookings b ON bu.id = b.bus_id
GROUP BY bu.id;

-- Create Stored Procedures
DELIMITER //

CREATE PROCEDURE GetAvailableSeats(
    IN p_bus_id INT,
    IN p_travel_date DATE
)
BEGIN
    SELECT 
        seat_number,
        seat_type,
        is_available,
        price
    FROM seat_availability
    WHERE bus_id = p_bus_id 
    AND travel_date = p_travel_date
    ORDER BY 
        CASE 
            WHEN seat_type = 'sleeper_lower' THEN 1
            WHEN seat_type = 'sleeper_upper' THEN 2
            WHEN seat_type = 'seater' THEN 3
        END,
        CAST(SUBSTRING(seat_number, 2) AS UNSIGNED);
END //

CREATE PROCEDURE ProcessRefund(
    IN p_booking_id INT,
    IN p_refund_reason TEXT,
    IN p_processed_by INT
)
BEGIN
    DECLARE v_refund_amount DECIMAL(10,2);
    DECLARE v_booking_status VARCHAR(20);
    DECLARE v_payment_id INT;
    
    -- Get booking details
    SELECT booking_status, total_amount INTO v_booking_status, v_refund_amount
    FROM bookings WHERE id = p_booking_id;
    
    SELECT id INTO v_payment_id FROM payments WHERE booking_id = p_booking_id;
    
    IF v_booking_status = 'confirmed' THEN
        -- Start transaction
        START TRANSACTION;
        
        -- Update booking status
        UPDATE bookings 
        SET booking_status = 'cancelled',
            cancellation_date = NOW(),
            cancellation_reason = p_refund_reason,
            refund_amount = v_refund_amount,
            is_refund_processed = TRUE
        WHERE id = p_booking_id;
        
        -- Create refund record
        INSERT INTO refunds (booking_id, payment_id, user_id, refund_amount, refund_reason, status, processed_by, processed_date)
        SELECT b.id, p.id, b.user_id, v_refund_amount, p_refund_reason, 'processed', p_processed_by, NOW()
        FROM bookings b
        JOIN payments p ON b.id = p.booking_id
        WHERE b.id = p_booking_id;
        
        -- Free up seats
        UPDATE seat_availability 
        SET is_available = TRUE, booking_id = NULL
        WHERE booking_id = p_booking_id;
        
        -- Commit transaction
        COMMIT;
        
        SELECT 'Refund processed successfully' as message;
    ELSE
        SELECT 'Booking cannot be refunded' as message;
    END IF;
END //

DELIMITER ;

-- Create Triggers for Audit Log
DELIMITER //

CREATE TRIGGER bookings_audit_insert
AFTER INSERT ON bookings
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, new_data, performed_by, user_type)
    VALUES ('bookings', NEW.id, 'INSERT', JSON_OBJECT(
        'booking_id', NEW.booking_id,
        'user_id', NEW.user_id,
        'total_amount', NEW.total_amount,
        'booking_status', NEW.booking_status
    ), NEW.user_id, 'user');
END //

CREATE TRIGGER users_audit_update
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, old_data, new_data, performed_by, user_type)
    VALUES ('users', NEW.id, 'UPDATE', JSON_OBJECT(
        'email', OLD.email,
        'phone', OLD.phone,
        'status', OLD.status
    ), JSON_OBJECT(
        'email', NEW.email,
        'phone', NEW.phone,
        'status', NEW.status
    ), NEW.id, 'user');
END //

DELIMITER ;

-- Create Event for Cleaning Expired Data
DELIMITER //

CREATE EVENT clean_expired_data
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    -- Clean expired OTPs
    UPDATE users 
    SET otp_code = NULL, otp_expiry = NULL, otp_attempts = 0 
    WHERE otp_expiry < NOW();
    
    -- Clean expired password reset tokens
    UPDATE users 
    SET reset_token = NULL, reset_token_expiry = NULL 
    WHERE reset_token_expiry < NOW();
    
    -- Clean expired pending bookings
    UPDATE pending_bookings 
    SET status = 'expired' 
    WHERE status = 'pending' AND expires_at < NOW();
    
    -- Archive old notifications (older than 30 days)
    DELETE FROM notifications 
    WHERE is_read = TRUE AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
END //

DELIMITER ;

-- Enable the event scheduler
SET GLOBAL event_scheduler = ON;