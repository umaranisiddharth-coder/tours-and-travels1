<?php
require_once 'config.php';

// Page configuration
$page_title = 'India\'s Most Trusted Bus Booking Platform';
$page_description = 'Book bus tickets online with SR Travels. Safe, comfortable, and affordable travel across India with real-time tracking and secure payments.';
$show_page_header = false; // Don't show page header for homepage

// Get statistics for homepage
$total_buses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM buses WHERE status = 'active'"))['count'];
$total_routes = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bus_routes WHERE is_active = 1"))['count'];
$total_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings"))['count'];
$happy_customers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT user_id) as count FROM bookings WHERE booking_status = 'completed'"))['count'];

// Get popular routes
$popular_routes_query = "SELECT r.*, b.bus_type, COUNT(bk.id) as booking_count
                        FROM bus_routes r 
                        JOIN buses b ON r.bus_id = b.id 
                        LEFT JOIN bookings bk ON r.id = bk.route_id
                        WHERE r.is_active = 1
                        GROUP BY r.id
                        ORDER BY booking_count DESC, r.fare ASC
                        LIMIT 6";
$popular_routes = mysqli_query($conn, $popular_routes_query);

// Get testimonials (sample data - in real app, this would come from database)
$testimonials = [
    [
        'name' => 'Priya Sharma',
        'location' => 'Mumbai',
        'rating' => 5,
        'comment' => 'Excellent service! The bus was clean, comfortable, and arrived on time. The online booking process was very smooth.',
        'image' => 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face'
    ],
    [
        'name' => 'Rajesh Kumar',
        'location' => 'Delhi',
        'rating' => 5,
        'comment' => 'Great experience with SR Travels. The sleeper bus was very comfortable for the overnight journey. Highly recommended!',
        'image' => 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
    ],
    [
        'name' => 'Anita Patel',
        'location' => 'Bangalore',
        'rating' => 4,
        'comment' => 'Good service and reasonable prices. The real-time tracking feature is very helpful. Will book again!',
        'image' => 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face'
    ]
];

// Custom CSS for homepage
$custom_css = "
    /* Homepage specific styles */
    .hero-section {
        background: linear-gradient(135deg, rgba(211, 47, 47, 0.9), rgba(244, 67, 54, 0.9)), 
                    url('https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        color: white;
        padding: 120px 0 80px;
        margin-top: 76px;
        position: relative;
        overflow: hidden;
    }
    
    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1000 100\" fill=\"rgba(255,255,255,0.1)\"><polygon points=\"1000,100 1000,0 0,100\"/></svg>');
        background-size: cover;
    }
    
    .hero-content {
        position: relative;
        z-index: 2;
    }
    
    .hero-title {
        font-size: 3.5rem;
        font-weight: 800;
        margin-bottom: 20px;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .hero-subtitle {
        font-size: 1.3rem;
        margin-bottom: 40px;
        opacity: 0.95;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }
    
    .search-form {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 30px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        margin-top: 40px;
    }
    
    .search-form .form-control {
        border: 2px solid #e0e0e0;
        border-radius: 12px;
        padding: 15px 20px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }
    
    .search-form .form-control:focus {
        border-color: #d32f2f;
        box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.1);
    }
    
    .search-btn {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        border: none;
        border-radius: 12px;
        padding: 15px 30px;
        font-weight: 600;
        font-size: 1.1rem;
        transition: all 0.3s ease;
    }
    
    .search-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(211, 47, 47, 0.3);
    }
    
    .stats-section {
        background: white;
        padding: 80px 0;
        position: relative;
    }
    
    .stat-card {
        text-align: center;
        padding: 30px 20px;
        border-radius: 15px;
        background: linear-gradient(135deg, rgba(211, 47, 47, 0.05), rgba(244, 67, 54, 0.05));
        border: 1px solid rgba(211, 47, 47, 0.1);
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(211, 47, 47, 0.15);
    }
    
    .stat-number {
        font-size: 3rem;
        font-weight: 800;
        color: #d32f2f;
        margin-bottom: 10px;
        display: block;
    }
    
    .stat-label {
        font-size: 1.1rem;
        color: #666;
        font-weight: 500;
    }
    
    .features-section {
        background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        padding: 80px 0;
    }
    
    .feature-card {
        background: white;
        border-radius: 20px;
        padding: 40px 30px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        height: 100%;
        border: 1px solid rgba(211, 47, 47, 0.1);
    }
    
    .feature-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    }
    
    .feature-icon {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        font-size: 2rem;
        color: white;
    }
    
    .routes-section {
        background: white;
        padding: 80px 0;
    }
    
    .route-card {
        background: white;
        border-radius: 15px;
        padding: 25px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        border: 1px solid rgba(211, 47, 47, 0.1);
        height: 100%;
    }
    
    .route-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    }
    
    .route-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }
    
    .route-cities {
        font-size: 1.2rem;
        font-weight: 600;
        color: #333;
    }
    
    .route-price {
        font-size: 1.5rem;
        font-weight: 700;
        color: #d32f2f;
    }
    
    .testimonials-section {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        color: white;
        padding: 80px 0;
        position: relative;
        overflow: hidden;
    }
    
    .testimonials-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><circle cx=\"20\" cy=\"20\" r=\"2\" fill=\"rgba(255,255,255,0.1)\"/><circle cx=\"80\" cy=\"80\" r=\"3\" fill=\"rgba(255,255,255,0.1)\"/></svg>');
        background-size: 100px 100px;
    }
    
    .testimonial-card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 30px;
        text-align: center;
        border: 1px solid rgba(255, 255, 255, 0.2);
        height: 100%;
        position: relative;
        z-index: 2;
    }
    
    .testimonial-avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        margin: 0 auto 20px;
        border: 3px solid rgba(255, 255, 255, 0.3);
    }
    
    .testimonial-stars {
        color: #ffc107;
        font-size: 1.2rem;
        margin-bottom: 15px;
    }
    
    .section-title {
        text-align: center;
        margin-bottom: 60px;
    }
    
    .section-title h2 {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 15px;
        color: #333;
    }
    
    .section-title p {
        font-size: 1.1rem;
        color: #666;
        max-width: 600px;
        margin: 0 auto;
    }
    
    @media (max-width: 768px) {
        .hero-title {
            font-size: 2.5rem;
        }
        
        .hero-subtitle {
            font-size: 1.1rem;
        }
        
        .search-form {
            padding: 20px;
        }
        
        .stat-number {
            font-size: 2.5rem;
        }
        
        .feature-card {
            padding: 30px 20px;
        }
    }
";

// Include header
include 'includes/header.php';
?>

<!-- Enhanced Hero Section -->
<section class="hero-section" id="home">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <div class="hero-content" data-aos="fade-up">
                    <h1 class="hero-title">
                        India's Most Trusted<br>
                        <span style="color: #ffc107;">Bus Booking</span> Platform
                    </h1>
                    <p class="hero-subtitle">
                        Experience comfortable, safe, and affordable travel across India with our premium fleet of buses. 
                        Book your journey with confidence and track your bus in real-time.
                    </p>
                    <div class="d-flex flex-wrap gap-3">
                        <a href="enhanced-booking-system.php" class="btn btn-warning btn-lg px-4 py-3">
                            <i class="fas fa-ticket-alt me-2"></i>Book Your Journey
                        </a>
                        <a href="#features" class="btn btn-outline-light btn-lg px-4 py-3">
                            <i class="fas fa-play-circle me-2"></i>Learn More
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Search Form -->
        <div class="row">
            <div class="col-12">
                <div class="search-form" data-aos="fade-up" data-aos-delay="200">
                    <h4 class="text-center mb-4" style="color: #333;">
                        <i class="fas fa-search me-2"></i>Quick Bus Search
                    </h4>
                    <form action="enhanced-booking-system.php" method="GET" class="row g-3">
                        <div class="col-md-3">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="from" name="from" placeholder="From City" required>
                                <label for="from">From City</label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="to" name="to" placeholder="To City" required>
                                <label for="to">To City</label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-floating">
                                <input type="date" class="form-control" id="date" name="date" 
                                       value="<?php echo date('Y-m-d'); ?>" min="<?php echo date('Y-m-d'); ?>" required>
                                <label for="date">Travel Date</label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn search-btn w-100 h-100">
                                <i class="fas fa-search me-2"></i>Search Buses
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Statistics Section -->
<section class="stats-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="stat-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="stat-number" data-count="<?php echo $total_buses; ?>">0</div>
                    <div class="stat-label">Active Buses</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="stat-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="stat-number" data-count="<?php echo $total_routes; ?>">0</div>
                    <div class="stat-label">Routes Available</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="stat-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="stat-number" data-count="<?php echo $total_bookings; ?>">0</div>
                    <div class="stat-label">Bookings Completed</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="stat-card" data-aos="fade-up" data-aos-delay="400">
                    <div class="stat-number" data-count="<?php echo $happy_customers; ?>">0</div>
                    <div class="stat-label">Happy Customers</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Enhanced Bus Types Section -->
<section class="bus-types-section" id="bus-types">
    <div class="container">
        <div class="section-title" data-aos="fade-up">
            <h2>Choose Your Comfort</h2>
            <p>Select from our premium fleet of seater and sleeper buses designed for your comfort and convenience</p>
        </div>
        
        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="feature-icon" style="background: linear-gradient(135deg, #4a90e2, #357abd);">
                        <i class="fas fa-chair"></i>
                    </div>
                    <h3 class="card-title">Seater Buses</h3>
                    <p class="text-muted mb-4">Perfect for day journeys with comfortable seating</p>
                    
                    <div class="row mb-4">
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Reclining Seats</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>AC & Non-AC</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Charging Points</li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Entertainment</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Free WiFi</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Refreshments</li>
                            </ul>
                        </div>
                    </div>
                    
                    <a href="enhanced-booking-system.php?bus_type=seater" class="btn btn-primary">
                        <i class="fas fa-search me-2"></i>Find Seater Buses
                    </a>
                </div>
            </div>
            
            <div class="col-lg-6 mb-4">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="feature-icon" style="background: linear-gradient(135deg, #8e44ad, #732d91);">
                        <i class="fas fa-bed"></i>
                    </div>
                    <h3 class="card-title">Sleeper Buses</h3>
                    <p class="text-muted mb-4">Ideal for overnight journeys with sleeping berths</p>
                    
                    <div class="row mb-4">
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Comfortable Berths</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Privacy Curtains</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Reading Lights</li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Blankets & Pillows</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Personal Storage</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Climate Control</li>
                            </ul>
                        </div>
                    </div>
                    
                    <a href="enhanced-booking-system.php?bus_type=sleeper" class="btn btn-primary">
                        <i class="fas fa-search me-2"></i>Find Sleeper Buses
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features-section" id="features">
    <div class="container">
        <div class="section-title" data-aos="fade-up">
            <h2>Why Choose SR Travels?</h2>
            <p>Experience the difference with our premium services and customer-first approach</p>
        </div>
        
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h4>Safe & Secure</h4>
                    <p>Your safety is our priority. All our buses are regularly maintained and driven by experienced drivers.</p>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="feature-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h4>On-Time Service</h4>
                    <p>We value your time. Our buses follow strict schedules to ensure you reach your destination on time.</p>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="feature-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h4>Live Tracking</h4>
                    <p>Track your bus in real-time and get live updates about arrival times and route progress.</p>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="400">
                    <div class="feature-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <h4>Secure Payments</h4>
                    <p>Multiple payment options with bank-level security. Pay with cards, UPI, or digital wallets.</p>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="500">
                    <div class="feature-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h4>24/7 Support</h4>
                    <p>Our customer support team is available round the clock to assist you with any queries or issues.</p>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-card" data-aos="fade-up" data-aos-delay="600">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h4>Mobile Tickets</h4>
                    <p>Go paperless with mobile tickets. Show your ticket on your phone and board the bus hassle-free.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Popular Routes Section -->
<section class="routes-section" id="routes">
    <div class="container">
        <div class="section-title" data-aos="fade-up">
            <h2>Popular Routes</h2>
            <p>Discover our most traveled routes with the best prices and comfortable buses</p>
        </div>
        
        <div class="row">
            <?php if(mysqli_num_rows($popular_routes) > 0): ?>
                <?php while($route = mysqli_fetch_assoc($popular_routes)): ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="route-card" data-aos="fade-up" data-aos-delay="100">
                            <div class="route-header">
                                <div class="route-cities">
                                    <?php echo $route['from_city']; ?>
                                    <i class="fas fa-arrow-right mx-2" style="color: #d32f2f;"></i>
                                    <?php echo $route['to_city']; ?>
                                </div>
                                <div class="route-price">₹<?php echo number_format($route['fare']); ?></div>
                            </div>
                            
                            <div class="route-details">
                                <div class="row">
                                    <div class="col-6">
                                        <small class="text-muted">Departure</small>
                                        <div class="fw-bold"><?php echo date('h:i A', strtotime($route['departure_time'])); ?></div>
                                    </div>
                                    <div class="col-6">
                                        <small class="text-muted">Arrival</small>
                                        <div class="fw-bold"><?php echo date('h:i A', strtotime($route['arrival_time'])); ?></div>
                                    </div>
                                </div>
                                
                                <div class="mt-3">
                                    <span class="badge bg-primary me-2"><?php echo ucfirst($route['bus_type']); ?></span>
                                    <?php if($route['booking_count'] > 0): ?>
                                        <span class="badge bg-success"><?php echo $route['booking_count']; ?> bookings</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="mt-3">
                                    <a href="enhanced-booking-system.php?from=<?php echo urlencode($route['from_city']); ?>&to=<?php echo urlencode($route['to_city']); ?>" 
                                       class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-ticket-alt me-1"></i>Book Now
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center">
                    <p class="text-muted">No popular routes available at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="enhanced-booking-system.php" class="btn btn-primary btn-lg">
                <i class="fas fa-route me-2"></i>View All Routes
            </a>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="testimonials-section" id="testimonials">
    <div class="container">
        <div class="section-title" data-aos="fade-up">
            <h2 style="color: white;">What Our Customers Say</h2>
            <p style="color: rgba(255,255,255,0.9);">Read reviews from thousands of satisfied customers who trust SR Travels</p>
        </div>
        
        <div class="row">
            <?php foreach($testimonials as $index => $testimonial): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="testimonial-card" data-aos="fade-up" data-aos-delay="<?php echo ($index + 1) * 100; ?>">
                        <img src="<?php echo $testimonial['image']; ?>" alt="<?php echo $testimonial['name']; ?>" class="testimonial-avatar">
                        
                        <div class="testimonial-stars">
                            <?php for($i = 0; $i < $testimonial['rating']; $i++): ?>
                                <i class="fas fa-star"></i>
                            <?php endfor; ?>
                        </div>
                        
                        <p class="testimonial-text">"<?php echo $testimonial['comment']; ?>"</p>
                        
                        <div class="testimonial-author"><?php echo $testimonial['name']; ?></div>
                        <div class="testimonial-location"><?php echo $testimonial['location']; ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
    // Counter Animation
    function animateCounters() {
        const counters = document.querySelectorAll('.stat-number');
        
        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-count'));
            const duration = 2000;
            const step = target / (duration / 16);
            let current = 0;
            
            const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                    counter.textContent = target;
                    clearInterval(timer);
                } else {
                    counter.textContent = Math.floor(current);
                }
            }, 16);
        });
    }
    
    // Trigger counter animation when stats section is visible
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounters();
                observer.unobserve(entry.target);
            }
        });
    });
    
    const statsSection = document.querySelector('.stats-section');
    if (statsSection) {
        observer.observe(statsSection);
    }
    
    // Auto-complete for city names
    const cities = [
        'Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai', 'Kolkata', 'Pune', 'Ahmedabad',
        'Jaipur', 'Surat', 'Lucknow', 'Kanpur', 'Nagpur', 'Indore', 'Thane', 'Bhopal',
        'Visakhapatnam', 'Pimpri-Chinchwad', 'Patna', 'Vadodara', 'Ghaziabad', 'Ludhiana',
        'Agra', 'Nashik', 'Faridabad', 'Meerut', 'Rajkot', 'Kalyan-Dombivali', 'Vasai-Virar',
        'Varanasi', 'Srinagar', 'Aurangabad', 'Dhanbad', 'Amritsar', 'Navi Mumbai', 'Allahabad',
        'Ranchi', 'Howrah', 'Coimbatore', 'Jabalpur', 'Gwalior', 'Vijayawada', 'Jodhpur',
        'Madurai', 'Raipur', 'Kota', 'Chandigarh', 'Guwahati', 'Solapur', 'Hubli-Dharwad'
    ];
    
    function setupAutocomplete(inputId) {
        const input = document.getElementById(inputId);
        if (!input) return;
        
        input.addEventListener('input', function() {
            const value = this.value.toLowerCase();
            const suggestions = cities.filter(city => 
                city.toLowerCase().includes(value)
            ).slice(0, 5);
            
            // Remove existing datalist
            const existingDatalist = document.getElementById(inputId + '-list');
            if (existingDatalist) {
                existingDatalist.remove();
            }
            
            if (suggestions.length > 0 && value.length > 0) {
                const datalist = document.createElement('datalist');
                datalist.id = inputId + '-list';
                
                suggestions.forEach(city => {
                    const option = document.createElement('option');
                    option.value = city;
                    datalist.appendChild(option);
                });
                
                document.body.appendChild(datalist);
                input.setAttribute('list', datalist.id);
            }
        });
    }
    
    setupAutocomplete('from');
    setupAutocomplete('to');
</script>

<?php include 'includes/footer.php'; ?>