<?php
require_once 'config.php';
require_once 'paytm-config.php';

// Razorpay Configuration
define('RAZORPAY_KEY_ID', PAYMENT_TEST_MODE ? 'rzp_test_1234567890' : 'your_live_key_id');
define('RAZORPAY_KEY_SECRET', PAYMENT_TEST_MODE ? 'test_secret_key' : 'your_live_secret_key');

// Get callback data
$razorpay_payment_id = $_POST['razorpay_payment_id'] ?? '';
$razorpay_order_id = $_POST['razorpay_order_id'] ?? '';
$razorpay_signature = $_POST['razorpay_signature'] ?? '';
$order_id = $_POST['order_id'] ?? '';
$amount = $_POST['amount'] ?? 0;

// Log callback for debugging
log_payment_debug('Razorpay Callback Received', [
    'payment_id' => $razorpay_payment_id,
    'order_id' => $razorpay_order_id,
    'signature' => $razorpay_signature,
    'internal_order_id' => $order_id,
    'amount' => $amount
]);

// Verify signature
$signature_valid = verifyRazorpaySignature($razorpay_order_id, $razorpay_payment_id, $razorpay_signature);

if (!$signature_valid) {
    $_SESSION['payment_error'] = 'Payment verification failed. Invalid signature.';
    header("Location: payment-failed.php");
    exit();
}

// Get payment details from Razorpay
$payment_details = getRazorpayPaymentDetails($razorpay_payment_id);

if (!$payment_details || $payment_details['status'] !== 'captured') {
    $_SESSION['payment_error'] = 'Payment not captured successfully.';
    header("Location: payment-failed.php");
    exit();
}

// Process successful payment
handle_successful_razorpay_payment($order_id, $amount, $payment_details);

function verifyRazorpaySignature($order_id, $payment_id, $signature) {
    $expected_signature = hash_hmac('sha256', $order_id . '|' . $payment_id, RAZORPAY_KEY_SECRET);
    return hash_equals($expected_signature, $signature);
}

function getRazorpayPaymentDetails($payment_id) {
    $url = 'https://api.razorpay.com/v1/payments/' . $payment_id;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Basic ' . base64_encode(RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET)
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200) {
        return json_decode($response, true);
    }
    
    return false;
}

function handle_successful_razorpay_payment($order_id, $amount, $payment_details) {
    global $conn;
    
    log_payment_debug('Processing successful Razorpay payment', [
        'order_id' => $order_id,
        'amount' => $amount,
        'payment_details' => $payment_details
    ]);
    
    // Get pending booking
    $pending_booking = get_pending_booking($order_id);
    
    if (!$pending_booking) {
        $_SESSION['payment_error'] = "No pending booking found for order: $order_id";
        header("Location: payment-failed.php");
        exit();
    }
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Generate final booking ID
        $booking_id = generate_booking_id();
        
        // Get bus_id from route
        $route_query = "SELECT bus_id FROM bus_routes WHERE id = " . $pending_booking['route_id'];
        $route_result = mysqli_query($conn, $route_query);
        $route = mysqli_fetch_assoc($route_result);
        $bus_id = $route['bus_id'];
        
        // Create final booking
        $seats_count = count(explode(',', $pending_booking['seats']));
        $booking_query = "INSERT INTO bookings (
            booking_id, user_id, bus_id, route_id, travel_date, 
            seats_booked, total_seats, total_amount, 
            payment_method, booking_status, payment_status
        ) VALUES (
            '$booking_id',
            {$pending_booking['user_id']},
            $bus_id,
            {$pending_booking['route_id']},
            '{$pending_booking['travel_date']}',
            '{$pending_booking['seats']}',
            $seats_count,
            $amount,
            'razorpay',
            'confirmed',
            'paid'
        )";
        
        if (mysqli_query($conn, $booking_query)) {
            $booking_insert_id = mysqli_insert_id($conn);
            
            // Create payment record
            $payment_id = 'PAY_' . date('YmdHis') . '_' . rand(1000, 9999);
            $payment_query = "INSERT INTO payments (
                booking_id, payment_id, order_id, amount, 
                payment_method, payment_status, transaction_id,
                bank_name, bank_txn_id, payment_gateway,
                razorpay_payment_id, razorpay_order_id
            ) VALUES (
                $booking_insert_id,
                '$payment_id',
                '$order_id',
                $amount,
                'razorpay',
                'completed',
                '{$payment_details['id']}',
                '{$payment_details['bank']}',
                '{$payment_details['acquirer_data']['bank_transaction_id']}',
                'razorpay',
                '{$payment_details['id']}',
                '{$payment_details['order_id']}'
            )";
            
            mysqli_query($conn, $payment_query);
            
            // Mark seats as booked
            $seats = explode(',', $pending_booking['seats']);
            foreach ($seats as $seat) {
                $seat_type = strpos($seat, 'U') === 0 ? 'sleeper_upper' : 
                            (strpos($seat, 'L') === 0 ? 'sleeper_lower' : 'seater');
                
                $seat_query = "INSERT INTO seat_availability (
                    bus_id, travel_date, seat_number, seat_type, is_available, booking_id
                ) VALUES (
                    $bus_id,
                    '{$pending_booking['travel_date']}',
                    '$seat',
                    '$seat_type',
                    FALSE,
                    $booking_insert_id
                ) ON DUPLICATE KEY UPDATE is_available = FALSE, booking_id = $booking_insert_id";
                
                mysqli_query($conn, $seat_query);
            }
            
            // Update pending booking status
            complete_pending_booking($order_id, 'completed');
            
            // Commit transaction
            mysqli_commit($conn);
            
            // Log successful payment
            log_payment_attempt($order_id, $pending_booking['user_id'], $amount, 'razorpay', 'completed', 
                              'Razorpay payment successful');
            
            // Store success data in session
            $_SESSION['payment_success'] = true;
            $_SESSION['last_booking_id'] = $booking_insert_id;
            $_SESSION['transaction_id'] = $payment_details['id'];
            $_SESSION['payment_method'] = 'Razorpay';
            
            // Clear payment session
            unset($_SESSION['paytm_order_id']);
            unset($_SESSION['paytm_amount']);
            unset($_SESSION['razorpay_order_id']);
            unset($_SESSION['razorpay_amount']);
            unset($_SESSION['selected_seats']);
            unset($_SESSION['route_id']);
            unset($_SESSION['travel_date']);
            unset($_SESSION['total_amount']);
            
            log_payment_debug('Razorpay payment successful, redirecting to confirmation');
            
            // Redirect to confirmation page
            header("Location: booking-confirm.php");
            exit();
            
        } else {
            throw new Exception("Booking creation failed: " . mysqli_error($conn));
        }
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        
        log_payment_attempt($order_id, $pending_booking['user_id'], $amount, 'razorpay', 'failed', 
                          'Database error: ' . $e->getMessage());
        
        complete_pending_booking($order_id, 'failed');
        
        $_SESSION['payment_error'] = "Payment successful but booking failed. Please contact support with Order ID: $order_id";
        header("Location: payment-failed.php");
        exit();
    }
}
?>