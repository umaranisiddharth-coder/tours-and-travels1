<?php
require_once 'config.php';

// Page configuration
$page_title = 'Reset Your Password';
$page_description = 'Recover access to your SR Travels account';

// Redirect if already logged in
if (is_logged_in()) {
    if (is_admin()) {
        header("Location: admin-dashboard-enhanced.php");
    } else {
        header("Location: user-dashboard-enhanced.php");
    }
    exit();
}

$error = '';
$success = '';
$show_otp_form = false;
$email = '';

// Clean expired OTPs on page load
if (function_exists('clean_expired_otps')) {
    clean_expired_otps();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['send_otp'])) {
        // Step 1: Request OTP
        $email = sanitize_input($_POST['email']);
        
        // Check if email exists
        if (email_exists($email)) {
            // Rate limiting check
            if (function_exists('can_send_otp') && !can_send_otp($email)) {
                $error = "Please wait 60 seconds before requesting another OTP.";
            } else {
                // Generate OTP
                $otp = function_exists('generate_otp') ? generate_otp() : rand(100000, 999999);
                $expiry = date('Y-m-d H:i:s', strtotime('+10 minutes'));
                
                // Store OTP in database
                $update_query = "UPDATE users SET 
                                otp_code = '$otp', 
                                otp_expiry = '$expiry',
                                otp_attempts = 0,
                                last_otp_sent = NOW()
                                WHERE email = '$email'";
                
                if (mysqli_query($conn, $update_query)) {
                    // Send OTP email
                    $email_sent = function_exists('send_otp_email') ? 
                                  send_otp_email($email, $otp) : 
                                  send_email($email, "SR Travels - Password Reset OTP", 
                                           "Your OTP for password reset is: <strong>$otp</strong><br>This OTP will expire in 10 minutes.");
                    
                    if ($email_sent) {
                        $success = "OTP has been sent to your email! It will expire in 10 minutes.";
                        $show_otp_form = true;
                        
                        // Store email in session for verification
                        $_SESSION['reset_email'] = $email;
                        
                        // Log OTP sent
                        if (function_exists('log_otp_activity')) {
                            log_otp_activity($email, $otp, 'sent');
                        }
                    } else {
                        $error = "Failed to send OTP email. Please try again.";
                    }
                } else {
                    $error = "Error generating OTP: " . mysqli_error($conn);
                }
            }
        } else {
            $error = "No account found with that email address.";
        }
        
    } elseif (isset($_POST['verify_otp'])) {
        // Step 2: Verify OTP
        $email = $_SESSION['reset_email'];
        $otp = sanitize_input($_POST['otp']);
        
        $is_valid = function_exists('validate_otp') ? validate_otp($email, $otp) : false;
        
        // Fallback validation if function doesn't exist
        if (!$is_valid && !function_exists('validate_otp')) {
            $query = "SELECT otp_code, otp_expiry FROM users WHERE email = '$email'";
            $result = mysqli_query($conn, $query);
            $user = mysqli_fetch_assoc($result);
            
            if ($user && $user['otp_code'] == $otp && strtotime($user['otp_expiry']) > time()) {
                $is_valid = true;
            }
        }
        
        if ($is_valid) {
            // OTP verified successfully
            // Generate reset token for password reset
            $token = generate_token();
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            $update_query = "UPDATE users SET 
                            reset_token = '$token', 
                            reset_token_expiry = '$expiry',
                            otp_code = NULL,
                            otp_expiry = NULL
                            WHERE email = '$email'";
            
            if (mysqli_query($conn, $update_query)) {
                // Redirect to reset password page
                header("Location: reset-password.php?token=$token");
                exit();
            }
        } else {
            $error = "Invalid or expired OTP. Please try again.";
        }
    }
}

// Custom CSS for RedBus-inspired design
$custom_css = "
    body {
        background: linear-gradient(135deg, #d32f2f 0%, #f44336 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .forgot-wrapper {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    .forgot-container {
        background: white;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        overflow: hidden;
        max-width: 500px;
        width: 100%;
        padding: 40px;
    }
    
    .forgot-header {
        text-align: center;
        margin-bottom: 30px;
    }
    
    .brand-logo {
        font-size: 2.5rem;
        font-weight: 800;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .brand-logo i {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .forgot-title {
        font-size: 1.8rem;
        font-weight: 700;
        color: #333;
        margin-bottom: 10px;
    }
    
    .forgot-subtitle {
        color: #666;
        font-size: 1rem;
        margin-bottom: 0;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #333;
        font-size: 0.9rem;
    }
    
    .form-control {
        width: 100%;
        padding: 15px;
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #fafafa;
    }
    
    .form-control:focus {
        outline: none;
        border-color: #d32f2f;
        background: white;
        box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.1);
    }
    
    .otp-input {
        letter-spacing: 8px;
        font-size: 1.5rem;
        font-weight: bold;
        text-align: center;
        padding: 20px 15px;
    }
    
    .btn-primary {
        width: 100%;
        padding: 15px;
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        color: white;
        border: none;
        border-radius: 10px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-bottom: 15px;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(211, 47, 47, 0.3);
    }
    
    .btn-success {
        background: linear-gradient(135deg, #2e7d32, #388e3c);
        border: none;
    }
    
    .btn-success:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(46, 125, 50, 0.3);
    }
    
    .btn-outline-primary {
        border: 2px solid #d32f2f;
        color: #d32f2f;
        background: transparent;
    }
    
    .btn-outline-primary:hover {
        background: #d32f2f;
        color: white;
    }
    
    .alert {
        padding: 15px 20px;
        border-radius: 10px;
        margin-bottom: 20px;
        font-size: 0.9rem;
        border: none;
    }
    
    .alert-danger {
        background: linear-gradient(135deg, rgba(211, 47, 47, 0.1), rgba(183, 28, 28, 0.1));
        color: #c62828;
        border-left: 4px solid #d32f2f;
    }
    
    .alert-success {
        background: linear-gradient(135deg, rgba(46, 125, 50, 0.1), rgba(56, 142, 60, 0.1));
        color: #2e7d32;
        border-left: 4px solid #4caf50;
    }
    
    .alert-info {
        background: linear-gradient(135deg, rgba(23, 162, 184, 0.1), rgba(32, 201, 151, 0.1));
        color: #17a2b8;
        border-left: 4px solid #17a2b8;
    }
    
    .timer {
        font-size: 0.85rem;
        color: #666;
        margin-top: 8px;
        text-align: center;
    }
    
    .back-link {
        text-align: center;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #e0e0e0;
    }
    
    .back-link a {
        color: #d32f2f;
        text-decoration: none;
        font-weight: 500;
    }
    
    .back-link a:hover {
        text-decoration: underline;
    }
    
    .form-text {
        font-size: 0.85rem;
        color: #666;
        margin-top: 5px;
    }
    
    @media (max-width: 768px) {
        .forgot-container {
            margin: 10px;
            padding: 30px 20px;
        }
        
        .brand-logo {
            font-size: 2rem;
        }
        
        .forgot-title {
            font-size: 1.5rem;
        }
        
        .otp-input {
            font-size: 1.2rem;
            letter-spacing: 5px;
        }
    }
";

// Don't show page header for forgot password
$show_page_header = false;

// Include header
include 'includes/header.php';
?>

<div class="forgot-wrapper">
    <div class="forgot-container" data-aos="fade-up">
        <div class="forgot-header">
            <div class="brand-logo">
                <i class="fas fa-bus"></i>
                <span>SR TRAVELS</span>
            </div>
            <h1 class="forgot-title">
                <?php echo $show_otp_form ? 'Verify OTP' : 'Reset Password'; ?>
            </h1>
            <p class="forgot-subtitle">
                <?php echo $show_otp_form ? 'Enter the verification code sent to your email' : 'We\'ll send you a verification code'; ?>
            </p>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if($success && !$show_otp_form): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if(!$show_otp_form): ?>
            <!-- Step 1: Request OTP -->
            <form method="POST" action="" id="otpRequestForm">
                <div class="form-group">
                    <label class="form-label" for="email">
                        <i class="fas fa-envelope me-2"></i>Email Address
                    </label>
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="Enter your registered email address" required
                           value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                    <div class="form-text">
                        <i class="fas fa-info-circle me-1"></i>
                        We'll send a 6-digit verification code to this email
                    </div>
                </div>
                
                <button type="submit" name="send_otp" class="btn btn-primary">
                    <i class="fas fa-paper-plane me-2"></i>Send Verification Code
                </button>
            </form>
            
            <div class="back-link">
                <p class="mb-0">
                    Remember your password? 
                    <a href="login.php">
                        <i class="fas fa-arrow-left me-1"></i>Back to Login
                    </a>
                </p>
            </div>
        <?php else: ?>
            <!-- Step 2: Verify OTP -->
            <div class="alert alert-success mb-4">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $success; ?>
                <br><small>Check your email for the 6-digit code</small>
            </div>
            
            <form method="POST" action="" id="otpVerifyForm">
                <div class="form-group">
                    <label class="form-label" for="otp">
                        <i class="fas fa-key me-2"></i>Verification Code
                    </label>
                    <input type="text" class="form-control otp-input" id="otp" name="otp" 
                           placeholder="123456" maxlength="6" required
                           pattern="[0-9]{6}" title="Enter 6-digit verification code">
                    <div class="timer">
                        <i class="fas fa-clock me-1"></i>
                        Code expires in: <span id="countdown">10:00</span>
                    </div>
                </div>
                
                <button type="submit" name="verify_otp" class="btn btn-success">
                    <i class="fas fa-check-circle me-2"></i>Verify Code
                </button>
                
                <button type="button" id="resendOtp" class="btn btn-outline-primary" disabled>
                    <i class="fas fa-redo me-2"></i>
                    <span id="resendText">Resend Code (60s)</span>
                </button>
            </form>
            
            <div class="alert alert-info mt-4">
                <h6><i class="fas fa-lightbulb me-2"></i>Didn't receive the code?</h6>
                <ul class="mb-0">
                    <li>Check your spam/junk folder</li>
                    <li>Make sure you entered the correct email</li>
                    <li>Wait 60 seconds before requesting a new code</li>
                </ul>
            </div>
            
            <div class="back-link">
                <a href="forgot-password.php">
                    <i class="fas fa-arrow-left me-1"></i>Use different email
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    <?php if($show_otp_form): ?>
    // Countdown timer for OTP
    let countdown = 600; // 10 minutes in seconds
    const countdownElement = document.getElementById('countdown');
    const resendButton = document.getElementById('resendOtp');
    const resendText = document.getElementById('resendText');
    
    function updateCountdown() {
        const minutes = Math.floor(countdown / 60);
        const seconds = countdown % 60;
        
        countdownElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        if (countdown <= 0) {
            clearInterval(timer);
            countdownElement.textContent = "Expired!";
            countdownElement.style.color = "red";
            alert("Verification code has expired. Please request a new one.");
            window.location.href = 'forgot-password.php';
        }
        
        countdown--;
    }
    
    // Timer for resend button (60 seconds)
    let resendCountdown = 60;
    function updateResendButton() {
        if (resendCountdown <= 0) {
            resendButton.disabled = false;
            resendText.textContent = "Resend Code";
            resendButton.classList.remove('btn-outline-primary');
            resendButton.classList.add('btn-primary');
            clearInterval(resendTimer);
        } else {
            resendText.textContent = `Resend Code (${resendCountdown}s)`;
            resendCountdown--;
        }
    }
    
    // Start timers
    const timer = setInterval(updateCountdown, 1000);
    const resendTimer = setInterval(updateResendButton, 1000);
    
    updateCountdown();
    updateResendButton();
    
    // Resend OTP functionality
    resendButton.addEventListener('click', function() {
        if (!resendButton.disabled) {
            resendButton.disabled = true;
            resendCountdown = 60;
            resendButton.classList.remove('btn-primary');
            resendButton.classList.add('btn-outline-primary');
            updateResendButton();
            
            // Submit form to resend OTP
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '';
            
            const emailInput = document.createElement('input');
            emailInput.type = 'hidden';
            emailInput.name = 'email';
            emailInput.value = '<?php echo $_SESSION['reset_email'] ?? ''; ?>';
            
            const submitInput = document.createElement('input');
            submitInput.type = 'hidden';
            submitInput.name = 'send_otp';
            submitInput.value = '1';
            
            form.appendChild(emailInput);
            form.appendChild(submitInput);
            document.body.appendChild(form);
            form.submit();
        }
    });
    
    // Auto-focus OTP input
    document.getElementById('otp').focus();
    
    // Auto-submit when 6 digits are entered
    document.getElementById('otp').addEventListener('input', function(e) {
        if (this.value.length === 6) {
            document.getElementById('otpVerifyForm').submit();
        }
    });
    <?php endif; ?>
    
    // Form validation
    document.addEventListener('DOMContentLoaded', function() {
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!form.checkValidity()) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                form.classList.add('was-validated');
            });
        });
    });
</script>

<?php include 'includes/footer.php'; ?>