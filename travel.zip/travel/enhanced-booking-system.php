<?php
require_once 'config.php';

if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Page configuration
$page_title = 'Search & Book Buses';
$page_description = 'Find and book the perfect bus for your journey with real-time availability and best prices';
$show_page_header = true;
$breadcrumbs = [
    ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
    ['title' => 'Book Bus', 'icon' => 'fas fa-search']
];

// Get search parameters
$from_city = isset($_GET['from']) ? sanitize_input($_GET['from']) : '';
$to_city = isset($_GET['to']) ? sanitize_input($_GET['to']) : '';
$travel_date = isset($_GET['date']) ? sanitize_input($_GET['date']) : date('Y-m-d');
$bus_type = isset($_GET['bus_type']) ? sanitize_input($_GET['bus_type']) : '';
$sort_by = isset($_GET['sort']) ? sanitize_input($_GET['sort']) : 'departure_time';

// Build search query with prepared statements
$query = "SELECT r.*, b.bus_name, b.bus_number, b.bus_type, b.total_seats, b.amenities, b.facilities,
                 (b.total_seats - COALESCE(booked.seats_count, 0)) as available_seats,
                 CASE 
                    WHEN TIME(NOW()) > r.departure_time AND DATE(NOW()) = ? THEN 'departed'
                    WHEN (b.total_seats - COALESCE(booked.seats_count, 0)) = 0 THEN 'full'
                    ELSE 'available'
                 END as booking_status
          FROM bus_routes r
          JOIN buses b ON r.bus_id = b.id
          LEFT JOIN (
              SELECT route_id, travel_date, SUM(total_seats) as seats_count
              FROM bookings 
              WHERE travel_date = ? AND booking_status IN ('confirmed', 'pending')
              GROUP BY route_id, travel_date
          ) booked ON r.id = booked.route_id
          WHERE r.is_active = 1 AND b.status = 'active'";

$params = [$travel_date, $travel_date];
$types = "ss";

if ($from_city) {
    $query .= " AND r.from_city LIKE ?";
    $params[] = "%$from_city%";
    $types .= "s";
}

if ($to_city) {
    $query .= " AND r.to_city LIKE ?";
    $params[] = "%$to_city%";
    $types .= "s";
}

if ($bus_type) {
    $query .= " AND b.bus_type = ?";
    $params[] = $bus_type;
    $types .= "s";
}

// Add sorting
switch ($sort_by) {
    case 'fare_low':
        $query .= " ORDER BY r.fare ASC";
        break;
    case 'fare_high':
        $query .= " ORDER BY r.fare DESC";
        break;
    case 'duration':
        $query .= " ORDER BY r.duration ASC";
        break;
    case 'departure_time':
    default:
        $query .= " ORDER BY r.departure_time ASC";
        break;
}

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$routes = mysqli_stmt_get_result($stmt);

// Get popular cities for suggestions
$popular_cities_query = "SELECT from_city as city, COUNT(*) as count FROM bus_routes GROUP BY from_city 
                        UNION 
                        SELECT to_city as city, COUNT(*) as count FROM bus_routes GROUP BY to_city 
                        ORDER BY count DESC LIMIT 10";
$popular_cities = mysqli_query($conn, $popular_cities_query);

// Custom CSS for this page
$custom_css = "
    .search-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 30px;
        margin: 20px 0;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .route-card {
        background: white;
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        border-left: 5px solid var(--primary-color);
    }
    
    .route-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .route-card.full {
        border-left-color: var(--danger-color);
        opacity: 0.7;
    }
    
    .route-card.departed {
        border-left-color: var(--warning-color);
        opacity: 0.6;
    }
    
    .bus-info {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
    }
    
    .bus-type-badge {
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    
    .seater { background: #e3f2fd; color: #1976d2; }
    .sleeper { background: #f3e5f5; color: #7b1fa2; }
    
    .price-section {
        text-align: right;
    }
    
    .price {
        font-size: 1.8rem;
        font-weight: bold;
        color: var(--success-color);
    }
    
    .seats-available {
        color: var(--success-color);
        font-weight: 500;
    }
    
    .seats-few {
        color: var(--warning-color);
        font-weight: 500;
    }
    
    .filter-section {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .popular-routes {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        padding: 20px;
        margin-top: 20px;
    }
    
    .popular-route-btn {
        background: rgba(255, 255, 255, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.3);
        color: white;
        border-radius: 20px;
        padding: 8px 16px;
        margin: 5px;
        transition: all 0.3s ease;
    }
    
    .popular-route-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        color: white;
        transform: translateY(-2px);
    }
    
    .content-section {
        background: transparent;
        padding: 40px 0;
    }
";

// Additional head content
$additional_head = '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">';

// Include header
include 'includes/header.php';
?>
<!-- Main Content -->
<div class="content-section">
    <div class="container">
        <!-- Search Form -->
        <div class="search-container" data-aos="fade-up">
            <h3 class="mb-4"><i class="fas fa-search me-2"></i>Search Buses</h3>
            <form method="GET" action="" class="search-form">
                <div class="form-floating">
                    <input type="text" class="form-control" id="from" name="from" 
                           value="<?php echo htmlspecialchars($from_city); ?>" placeholder="From City" required>
                    <label for="from">From City</label>
                    <div class="city-suggestions" id="from-suggestions"></div>
                </div>
                
                <div class="form-floating">
                    <input type="text" class="form-control" id="to" name="to" 
                           value="<?php echo htmlspecialchars($to_city); ?>" placeholder="To City" required>
                    <label for="to">To City</label>
                    <div class="city-suggestions" id="to-suggestions"></div>
                </div>
                
                <div class="form-floating">
                    <input type="date" class="form-control" id="date" name="date" 
                           value="<?php echo $travel_date; ?>" min="<?php echo date('Y-m-d'); ?>" required>
                    <label for="date">Travel Date</label>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Search
                </button>
            </form>
        </div>
            </a>
            <div class="navbar-nav ms-auto">
                <a href="user.php" class="nav-link">
                    <i class="fas fa-user me-1"></i>Dashboard
                </a>
                <a href="bus-tracking.php" class="nav-link">
                    <i class="fas fa-map-marker-alt me-1"></i>Track Bus
                </a>
                <a href="logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <!-- Search Section -->
        <div class="search-container">
            <h2 class="text-center mb-4">
                <i class="fas fa-search me-2"></i>Find Your Perfect Bus Journey
            </h2>
            
            <form method="GET" class="search-form">
                <div class="form-floating">
                    <input type="text" class="form-control" id="from_city" name="from" 
                           value="<?php echo htmlspecialchars($from_city); ?>" 
                           placeholder="From City" autocomplete="off" required>
                    <label for="from_city">From City</label>
                    <div class="city-suggestions" id="from_suggestions"></div>
                </div>
                
                <div class="form-floating">
                    <input type="text" class="form-control" id="to_city" name="to" 
                           value="<?php echo htmlspecialchars($to_city); ?>" 
                           placeholder="To City" autocomplete="off" required>
                    <label for="to_city">To City</label>
                    <div class="city-suggestions" id="to_suggestions"></div>
                </div>
                
                <div class="form-floating">
                    <input type="date" class="form-control" id="travel_date" name="date" 
                           value="<?php echo $travel_date; ?>" min="<?php echo date('Y-m-d'); ?>" required>
                    <label for="travel_date">Travel Date</label>
                </div>
                
                <button type="submit" class="btn book-btn">
                    <i class="fas fa-search me-2"></i>Search Buses
                </button>
            </form>
        </div>

        <!-- Filters and Sorting -->
        <?php if (mysqli_num_rows($routes) > 0): ?>
        <div class="filters-section">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="d-flex gap-3">
                        <select class="form-select" onchange="filterBuses(this.value)" style="width: auto;">
                            <option value="">All Bus Types</option>
                            <option value="seater" <?php echo $bus_type == 'seater' ? 'selected' : ''; ?>>Seater</option>
                            <option value="sleeper" <?php echo $bus_type == 'sleeper' ? 'selected' : ''; ?>>Sleeper</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex justify-content-end gap-3">
                        <select class="form-select" onchange="sortBuses(this.value)" style="width: auto;">
                            <option value="departure_time" <?php echo $sort_by == 'departure_time' ? 'selected' : ''; ?>>Departure Time</option>
                            <option value="fare_low" <?php echo $sort_by == 'fare_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                            <option value="fare_high" <?php echo $sort_by == 'fare_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                            <option value="duration" <?php echo $sort_by == 'duration' ? 'selected' : ''; ?>>Duration</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Results Section -->
        <div class="results-section">
            <?php if (mysqli_num_rows($routes) > 0): ?>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4><?php echo mysqli_num_rows($routes); ?> buses found</h4>
                    <small class="text-muted">for <?php echo date('d M Y', strtotime($travel_date)); ?></small>
                </div>

                <?php while ($route = mysqli_fetch_assoc($routes)): ?>
                <div class="route-card <?php echo $route['booking_status']; ?>">
                    <div class="bus-info">
                        <h5 class="mb-0"><?php echo htmlspecialchars($route['bus_name']); ?></h5>
                        <span class="bus-type-badge bus-type-<?php echo $route['bus_type']; ?>">
                            <?php echo ucfirst($route['bus_type']); ?>
                        </span>
                        <small class="text-muted ms-2"><?php echo htmlspecialchars($route['bus_number']); ?></small>
                    </div>

                    <div class="route-details">
                        <div class="city-info">
                            <div class="city-name"><?php echo htmlspecialchars($route['from_city']); ?></div>
                            <div class="city-time"><?php echo date('H:i', strtotime($route['departure_time'])); ?></div>
                        </div>
                        
                        <div class="route-arrow">
                            <i class="fas fa-arrow-right fa-2x"></i>
                            <div class="duration"><?php echo $route['duration'] ?? calculateDuration($route['departure_time'], $route['arrival_time']); ?></div>
                        </div>
                        
                        <div class="city-info">
                            <div class="city-name"><?php echo htmlspecialchars($route['to_city']); ?></div>
                            <div class="city-time"><?php echo date('H:i', strtotime($route['arrival_time'])); ?></div>
                        </div>
                    </div>

                    <?php if ($route['amenities']): ?>
                    <div class="amenities">
                        <?php 
                        $amenities = explode(',', $route['amenities']);
                        foreach ($amenities as $amenity): 
                        ?>
                        <span class="amenity-tag">
                            <i class="fas fa-check me-1"></i><?php echo trim($amenity); ?>
                        </span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <div class="price-section">
                        <div>
                            <div class="price">₹<?php echo number_format($route['fare'], 2); ?></div>
                            <small class="text-muted">per seat</small>
                        </div>
                        
                        <div class="text-end">
                            <?php if ($route['booking_status'] == 'available'): ?>
                                <div class="seats-available <?php echo $route['available_seats'] <= 5 ? 'seats-few' : ''; ?>">
                                    <?php echo $route['available_seats']; ?> seats available
                                </div>
                                <a href="seat-selection.php?route_id=<?php echo $route['id']; ?>&travel_date=<?php echo $travel_date; ?>" 
                                   class="btn book-btn mt-2">
                                    <i class="fas fa-chair me-2"></i>Select Seats
                                </a>
                            <?php elseif ($route['booking_status'] == 'full'): ?>
                                <div class="seats-full">Bus Full</div>
                                <button class="btn book-btn mt-2" disabled>
                                    <i class="fas fa-times me-2"></i>Not Available
                                </button>
                            <?php else: ?>
                                <div class="text-warning">Departed</div>
                                <button class="btn book-btn mt-2" disabled>
                                    <i class="fas fa-clock me-2"></i>Departed
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>

            <?php else: ?>
                <div class="no-results">
                    <i class="fas fa-search fa-3x mb-3 text-muted"></i>
                    <h4>No buses found</h4>
                    <p class="text-muted">Try adjusting your search criteria or check for different dates.</p>
                    <a href="?" class="btn book-btn">
                        <i class="fas fa-redo me-2"></i>Search Again
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Popular cities for autocomplete
        const popularCities = [
            <?php 
            $cities = [];
            mysqli_data_seek($popular_cities, 0);
            while ($city = mysqli_fetch_assoc($popular_cities)) {
                $cities[] = "'" . addslashes($city['city']) . "'";
            }
            echo implode(',', $cities);
            ?>
        ];

        // Initialize date picker
        flatpickr("#travel_date", {
            minDate: "today",
            maxDate: new Date().fp_incr(90), // 90 days from today
            dateFormat: "Y-m-d"
        });

        // City autocomplete functionality
        function setupCityAutocomplete(inputId, suggestionsId) {
            const input = document.getElementById(inputId);
            const suggestions = document.getElementById(suggestionsId);

            input.addEventListener('input', function() {
                const value = this.value.toLowerCase();
                suggestions.innerHTML = '';
                
                if (value.length < 2) {
                    suggestions.style.display = 'none';
                    return;
                }

                const matches = popularCities.filter(city => 
                    city.toLowerCase().includes(value)
                ).slice(0, 5);

                if (matches.length > 0) {
                    matches.forEach(city => {
                        const div = document.createElement('div');
                        div.className = 'city-suggestion';
                        div.textContent = city;
                        div.onclick = () => {
                            input.value = city;
                            suggestions.style.display = 'none';
                        };
                        suggestions.appendChild(div);
                    });
                    suggestions.style.display = 'block';
                } else {
                    suggestions.style.display = 'none';
                }
            });

            // Hide suggestions when clicking outside
            document.addEventListener('click', function(e) {
                if (!input.contains(e.target) && !suggestions.contains(e.target)) {
                    suggestions.style.display = 'none';
                }
            });
        }

        setupCityAutocomplete('from_city', 'from_suggestions');
        setupCityAutocomplete('to_city', 'to_suggestions');

        // Filter and sort functions
        function filterBuses(busType) {
            const url = new URL(window.location);
            if (busType) {
                url.searchParams.set('bus_type', busType);
            } else {
                url.searchParams.delete('bus_type');
            }
            window.location = url;
        }

        function sortBuses(sortBy) {
            const url = new URL(window.location);
            url.searchParams.set('sort', sortBy);
            window.location = url;
        }

        // Swap cities function
        function swapCities() {
            const fromCity = document.getElementById('from_city');
            const toCity = document.getElementById('to_city');
            const temp = fromCity.value;
            fromCity.value = toCity.value;
            toCity.value = temp;
        }

        // Add swap button
        document.addEventListener('DOMContentLoaded', function() {
            const searchForm = document.querySelector('.search-form');
            const swapBtn = document.createElement('button');
            swapBtn.type = 'button';
            swapBtn.className = 'btn btn-outline-primary';
            swapBtn.innerHTML = '<i class="fas fa-exchange-alt"></i>';
            swapBtn.onclick = swapCities;
            swapBtn.style.position = 'absolute';
            swapBtn.style.right = '50%';
            swapBtn.style.top = '50%';
            swapBtn.style.transform = 'translate(50%, -50%)';
            swapBtn.style.zIndex = '10';
            
            const container = document.createElement('div');
            container.style.position = 'relative';
            container.style.gridColumn = '1 / 3';
            container.appendChild(swapBtn);
            
            searchForm.appendChild(container);
        });
    </script>

<?php
function calculateDuration($departure, $arrival) {
    $dep = new DateTime($departure);
    $arr = new DateTime($arrival);
    
    // Handle next day arrival
    if ($arr < $dep) {
        $arr->add(new DateInterval('P1D'));
    }
    
    $diff = $dep->diff($arr);
    return $diff->format('%h:%I hrs');
}

include 'includes/footer.php'; 
?>