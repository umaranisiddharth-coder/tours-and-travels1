<?php
require_once 'config.php';

if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user details with prepared statement
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $user_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$user_result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($user_result);

// Get user statistics
$stats = [];
$stats['total_bookings'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings WHERE user_id = $user_id"))['count'];
$stats['completed_trips'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings WHERE user_id = $user_id AND booking_status = 'completed'"))['count'];
$stats['total_spent'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount), 0) as total FROM bookings WHERE user_id = $user_id AND payment_status = 'paid'"))['total'];
$stats['upcoming_trips'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings WHERE user_id = $user_id AND booking_status = 'confirmed' AND travel_date >= CURDATE()"))['count'];

// Get recent bookings with prepared statement
$bookings_query = "SELECT b.*, r.from_city, r.to_city, r.departure_time, r.arrival_time, 
                          bus.bus_name, bus.bus_number, bus.bus_type
                   FROM bookings b
                   JOIN bus_routes r ON b.route_id = r.id
                   JOIN buses bus ON b.bus_id = bus.id
                   WHERE b.user_id = ?
                   ORDER BY b.booking_date DESC
                   LIMIT 10";
$stmt = mysqli_prepare($conn, $bookings_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$bookings = mysqli_stmt_get_result($stmt);

// Get upcoming trips
$upcoming_query = "SELECT b.*, r.from_city, r.to_city, r.departure_time, r.arrival_time,
                          bus.bus_name, bus.bus_number, bus.bus_type
                   FROM bookings b
                   JOIN bus_routes r ON b.route_id = r.id
                   JOIN buses bus ON b.bus_id = bus.id
                   WHERE b.user_id = ? AND b.booking_status = 'confirmed' AND b.travel_date >= CURDATE()
                   ORDER BY b.travel_date ASC, r.departure_time ASC
                   LIMIT 5";
$stmt = mysqli_prepare($conn, $upcoming_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$upcoming_trips = mysqli_stmt_get_result($stmt);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $full_name = sanitize_input($_POST['full_name']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    
    $update_query = "UPDATE users SET full_name = ?, phone = ?, address = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "sssi", $full_name, $phone, $address, $user_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $success = "Profile updated successfully!";
        // Refresh user data
        $user['full_name'] = $full_name;
        $user['phone'] = $phone;
        $user['address'] = $address;
    } else {
        $error = "Error updating profile. Please try again.";
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (password_verify($current_password, $user['password'])) {
        if ($new_password === $confirm_password) {
            if (strlen($new_password) >= 6) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $password_query = "UPDATE users SET password = ? WHERE id = ?";
                $stmt = mysqli_prepare($conn, $password_query);
                mysqli_stmt_bind_param($stmt, "si", $hashed_password, $user_id);
                
                if (mysqli_stmt_execute($stmt)) {
                    $success = "Password changed successfully!";
                } else {
                    $error = "Error changing password. Please try again.";
                }
            } else {
                $error = "Password must be at least 6 characters long.";
            }
        } else {
            $error = "New passwords do not match.";
        }
    } else {
        $error = "Current password is incorrect.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #17a2b8;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .dashboard-container {
            padding: 20px;
        }
        
        .welcome-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.95), rgba(255,255,255,0.9));
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.2);
        }
        
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border-left: 5px solid;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 80px;
            height: 80px;
            background: linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.3));
            border-radius: 50%;
            transform: translate(20px, -20px);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        
        .stat-card.primary { border-left-color: var(--primary-color); }
        .stat-card.success { border-left-color: var(--success-color); }
        .stat-card.warning { border-left-color: var(--warning-color); }
        .stat-card.info { border-left-color: var(--info-color); }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: white;
            margin-bottom: 15px;
        }
        
        .stat-icon.primary { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); }
        .stat-icon.success { background: linear-gradient(135deg, var(--success-color), #20c997); }
        .stat-icon.warning { background: linear-gradient(135deg, var(--warning-color), #fd7e14); }
        .stat-icon.info { background: linear-gradient(135deg, var(--info-color), #6f42c1); }
        
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .content-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .trip-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .trip-card:hover {
            transform: translateX(5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        
        .trip-card.upcoming {
            border-left-color: var(--success-color);
            background: linear-gradient(135deg, rgba(40, 167, 69, 0.05), rgba(255,255,255,1));
        }
        
        .trip-card.completed {
            border-left-color: var(--info-color);
            opacity: 0.8;
        }
        
        .trip-card.cancelled {
            border-left-color: var(--danger-color);
            opacity: 0.7;
        }
        
        .route-info {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        
        .city-name {
            font-size: 1.1rem;
            font-weight: bold;
            color: #333;
        }
        
        .route-arrow {
            color: var(--primary-color);
            margin: 0 15px;
        }
        
        .trip-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .detail-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            color: #666;
        }
        
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .navbar-user {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .quick-action-btn {
            background: white;
            border: none;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .quick-action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            color: var(--primary-color);
        }
        
        .profile-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            margin-right: 20px;
        }
        
        .tab-content {
            margin-top: 20px;
        }
        
        .nav-pills .nav-link {
            border-radius: 25px;
            margin-right: 10px;
            transition: all 0.3s ease;
        }
        
        .nav-pills .nav-link.active {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 10px;
            }
            
            .route-info {
                flex-direction: column;
                text-align: center;
            }
            
            .route-arrow {
                transform: rotate(90deg);
                margin: 10px 0;
            }
            
            .trip-details {
                grid-template-columns: 1fr;
            }
            
            .profile-avatar {
                width: 60px;
                height: 60px;
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-user">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="enhanced-booking-system.php">
                <i class="fas fa-bus me-2"></i>
                SR<span class="text-warning">TRAVELS</span>
            </a>
            
            <div class="navbar-nav ms-auto">
                <a href="enhanced-booking-system.php" class="nav-link">
                    <i class="fas fa-search me-1"></i>Book Tickets
                </a>
                <a href="bus-tracking.php" class="nav-link">
                    <i class="fas fa-map-marker-alt me-1"></i>Track Bus
                </a>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i>
                        <?php echo htmlspecialchars($user['full_name']); ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#profile" data-bs-toggle="pill"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="#settings" data-bs-toggle="pill"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="dashboard-container">
        <!-- Welcome Section -->
        <div class="welcome-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2 class="mb-2">
                        Welcome back, <?php echo htmlspecialchars($user['full_name']); ?>! 👋
                    </h2>
                    <p class="text-muted mb-0">
                        Ready for your next journey? Book your tickets or track your upcoming trips.
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="profile-avatar">
                        <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($success)): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="enhanced-booking-system.php" class="quick-action-btn">
                <i class="fas fa-plus-circle fa-2x mb-2 text-success"></i>
                <div><strong>Book New Ticket</strong></div>
                <small class="text-muted">Find and book bus tickets</small>
            </a>
            <a href="bus-tracking.php" class="quick-action-btn">
                <i class="fas fa-map-marker-alt fa-2x mb-2 text-primary"></i>
                <div><strong>Track My Bus</strong></div>
                <small class="text-muted">Real-time bus tracking</small>
            </a>
            <a href="#bookings" data-bs-toggle="pill" class="quick-action-btn">
                <i class="fas fa-history fa-2x mb-2 text-info"></i>
                <div><strong>Booking History</strong></div>
                <small class="text-muted">View all bookings</small>
            </a>
            <a href="#profile" data-bs-toggle="pill" class="quick-action-btn">
                <i class="fas fa-user-edit fa-2x mb-2 text-warning"></i>
                <div><strong>Edit Profile</strong></div>
                <small class="text-muted">Update your details</small>
            </a>
        </div>

        <!-- Statistics Cards -->
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="stat-card primary">
                    <div class="stat-icon primary">
                        <i class="fas fa-ticket-alt"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['total_bookings']); ?></div>
                    <div class="stat-label">Total Bookings</div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="stat-card success">
                    <div class="stat-icon success">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['completed_trips']); ?></div>
                    <div class="stat-label">Completed Trips</div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="stat-card warning">
                    <div class="stat-icon warning">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($stats['upcoming_trips']); ?></div>
                    <div class="stat-label">Upcoming Trips</div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="stat-card info">
                    <div class="stat-icon info">
                        <i class="fas fa-rupee-sign"></i>
                    </div>
                    <div class="stat-value">₹<?php echo number_format($stats['total_spent'], 0); ?></div>
                    <div class="stat-label">Total Spent</div>
                </div>
            </div>
        </div>

        <!-- Tab Navigation -->
        <div class="content-card">
            <ul class="nav nav-pills" id="dashboardTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="upcoming-tab" data-bs-toggle="pill" data-bs-target="#upcoming" type="button" role="tab">
                        <i class="fas fa-calendar-alt me-2"></i>Upcoming Trips
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="bookings-tab" data-bs-toggle="pill" data-bs-target="#bookings" type="button" role="tab">
                        <i class="fas fa-history me-2"></i>Booking History
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="profile-tab" data-bs-toggle="pill" data-bs-target="#profile" type="button" role="tab">
                        <i class="fas fa-user me-2"></i>Profile
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="settings-tab" data-bs-toggle="pill" data-bs-target="#settings" type="button" role="tab">
                        <i class="fas fa-cog me-2"></i>Settings
                    </button>
                </li>
            </ul>

            <div class="tab-content" id="dashboardTabContent">
                <!-- Upcoming Trips -->
                <div class="tab-pane fade show active" id="upcoming" role="tabpanel">
                    <h5 class="mb-4">
                        <i class="fas fa-calendar-alt me-2"></i>
                        Your Upcoming Trips
                    </h5>
                    
                    <?php if (mysqli_num_rows($upcoming_trips) > 0): ?>
                        <?php while ($trip = mysqli_fetch_assoc($upcoming_trips)): ?>
                        <div class="trip-card upcoming">
                            <div class="route-info">
                                <div>
                                    <div class="city-name"><?php echo htmlspecialchars($trip['from_city']); ?></div>
                                    <small class="text-muted"><?php echo date('H:i', strtotime($trip['departure_time'])); ?></small>
                                </div>
                                <div class="route-arrow">
                                    <i class="fas fa-arrow-right fa-2x"></i>
                                </div>
                                <div>
                                    <div class="city-name"><?php echo htmlspecialchars($trip['to_city']); ?></div>
                                    <small class="text-muted"><?php echo date('H:i', strtotime($trip['arrival_time'])); ?></small>
                                </div>
                            </div>
                            
                            <div class="trip-details">
                                <div class="detail-item">
                                    <i class="fas fa-calendar text-primary"></i>
                                    <span><?php echo date('d M Y', strtotime($trip['travel_date'])); ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-bus text-success"></i>
                                    <span><?php echo htmlspecialchars($trip['bus_name']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-chair text-info"></i>
                                    <span>Seats: <?php echo $trip['seats_booked']; ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-rupee-sign text-warning"></i>
                                    <span>₹<?php echo number_format($trip['total_amount'], 2); ?></span>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <span class="status-badge bg-success text-white">
                                    <?php echo ucfirst($trip['booking_status']); ?>
                                </span>
                                <div>
                                    <a href="bus-tracking.php?booking_id=<?php echo $trip['booking_id']; ?>" class="btn btn-outline-primary btn-sm me-2">
                                        <i class="fas fa-map-marker-alt me-1"></i>Track Bus
                                    </a>
                                    <button class="btn btn-outline-secondary btn-sm" onclick="viewBookingDetails('<?php echo $trip['booking_id']; ?>')">
                                        <i class="fas fa-eye me-1"></i>Details
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                            <h5>No Upcoming Trips</h5>
                            <p class="text-muted">You don't have any upcoming trips. Book your next journey!</p>
                            <a href="enhanced-booking-system.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Book New Ticket
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Booking History -->
                <div class="tab-pane fade" id="bookings" role="tabpanel">
                    <h5 class="mb-4">
                        <i class="fas fa-history me-2"></i>
                        Booking History
                    </h5>
                    
                    <?php if (mysqli_num_rows($bookings) > 0): ?>
                        <?php 
                        mysqli_data_seek($bookings, 0);
                        while ($booking = mysqli_fetch_assoc($bookings)): 
                        ?>
                        <div class="trip-card <?php echo $booking['booking_status']; ?>">
                            <div class="route-info">
                                <div>
                                    <div class="city-name"><?php echo htmlspecialchars($booking['from_city']); ?></div>
                                    <small class="text-muted"><?php echo date('H:i', strtotime($booking['departure_time'])); ?></small>
                                </div>
                                <div class="route-arrow">
                                    <i class="fas fa-arrow-right fa-2x"></i>
                                </div>
                                <div>
                                    <div class="city-name"><?php echo htmlspecialchars($booking['to_city']); ?></div>
                                    <small class="text-muted"><?php echo date('H:i', strtotime($booking['arrival_time'])); ?></small>
                                </div>
                            </div>
                            
                            <div class="trip-details">
                                <div class="detail-item">
                                    <i class="fas fa-calendar text-primary"></i>
                                    <span><?php echo date('d M Y', strtotime($booking['travel_date'])); ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-bus text-success"></i>
                                    <span><?php echo htmlspecialchars($booking['bus_name']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-ticket-alt text-info"></i>
                                    <span><?php echo $booking['booking_id']; ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-rupee-sign text-warning"></i>
                                    <span>₹<?php echo number_format($booking['total_amount'], 2); ?></span>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <span class="status-badge 
                                    <?php echo $booking['booking_status'] == 'confirmed' ? 'bg-success' : 
                                             ($booking['booking_status'] == 'pending' ? 'bg-warning' : 
                                             ($booking['booking_status'] == 'cancelled' ? 'bg-danger' : 'bg-info')); ?> text-white">
                                    <?php echo ucfirst($booking['booking_status']); ?>
                                </span>
                                <small class="text-muted">
                                    Booked on <?php echo date('d M Y', strtotime($booking['booking_date'])); ?>
                                </small>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-history fa-3x text-muted mb-3"></i>
                            <h5>No Booking History</h5>
                            <p class="text-muted">You haven't made any bookings yet. Start your journey with us!</p>
                            <a href="enhanced-booking-system.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Book Your First Ticket
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Profile -->
                <div class="tab-pane fade" id="profile" role="tabpanel">
                    <h5 class="mb-4">
                        <i class="fas fa-user me-2"></i>
                        Profile Information
                    </h5>
                    
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="full_name" class="form-label">Full Name</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" 
                                           value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email Address</label>
                                    <input type="email" class="form-control" id="email" 
                                           value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                                    <small class="text-muted">Email cannot be changed</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           value="<?php echo htmlspecialchars($user['phone']); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" 
                                           value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                    <small class="text-muted">Username cannot be changed</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($user['address']); ?></textarea>
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Update Profile
                        </button>
                    </form>
                </div>

                <!-- Settings -->
                <div class="tab-pane fade" id="settings" role="tabpanel">
                    <h5 class="mb-4">
                        <i class="fas fa-cog me-2"></i>
                        Account Settings
                    </h5>
                    
                    <!-- Change Password -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h6 class="mb-0">
                                <i class="fas fa-lock me-2"></i>
                                Change Password
                            </h6>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">Current Password</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="new_password" class="form-label">New Password</label>
                                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                        </div>
                                    </div>
                                </div>
                                
                                <button type="submit" name="change_password" class="btn btn-warning">
                                    <i class="fas fa-key me-2"></i>Change Password
                                </button>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Account Information -->
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">
                                <i class="fas fa-info-circle me-2"></i>
                                Account Information
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Member Since:</strong> <?php echo date('d M Y', strtotime($user['created_at'])); ?></p>
                                    <p><strong>Last Login:</strong> <?php echo $user['last_login'] ? date('d M Y, H:i', strtotime($user['last_login'])) : 'Never'; ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Account Status:</strong> 
                                        <span class="badge bg-success">Active</span>
                                    </p>
                                    <p><strong>Email Verified:</strong> 
                                        <span class="badge <?php echo $user['is_email_verified'] ? 'bg-success' : 'bg-warning'; ?>">
                                            <?php echo $user['is_email_verified'] ? 'Verified' : 'Pending'; ?>
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function viewBookingDetails(bookingId) {
            // This would open a modal or redirect to booking details page
            alert('Viewing details for booking: ' + bookingId);
            // In a real implementation, you might do:
            // window.location.href = 'booking-details.php?id=' + bookingId;
        }

        // Auto-refresh upcoming trips every 5 minutes
        setInterval(function() {
            if (document.getElementById('upcoming-tab').classList.contains('active')) {
                location.reload();
            }
        }, 300000);

        // Password strength indicator
        document.getElementById('new_password').addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            // Add visual feedback for password strength
        });

        function calculatePasswordStrength(password) {
            let strength = 0;
            if (password.length >= 8) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            return strength;
        }

        // Confirm password match
        document.getElementById('confirm_password').addEventListener('input', function() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = this.value;
            
            if (newPassword !== confirmPassword) {
                this.setCustomValidity('Passwords do not match');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>