<?php
require_once 'config.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Get order details
$order_id = isset($_SESSION['paytm_order_id']) ? $_SESSION['paytm_order_id'] : generate_order_id();
$amount = isset($_SESSION['paytm_amount']) ? $_SESSION['paytm_amount'] : 0;
$user_id = $_SESSION['user_id'];

if ($amount <= 0) {
    $_SESSION['payment_error'] = 'Invalid payment amount';
    header("Location: payment-failed.php");
    exit();
}

// Get user details
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $user_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$user_result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($user_result);

// Store order details in session
$_SESSION['razorpay_order_id'] = $order_id;
$_SESSION['razorpay_amount'] = $amount;

// Handle form submission
$error = '';
$card_details = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['process_payment'])) {
    // Validate card details
    $card_number = sanitize_input($_POST['card_number']);
    $expiry_month = sanitize_input($_POST['expiry_month']);
    $expiry_year = sanitize_input($_POST['expiry_year']);
    $cvv = sanitize_input($_POST['cvv']);
    $cardholder_name = sanitize_input($_POST['cardholder_name']);
    
    // Basic validation
    if (empty($card_number) || strlen(str_replace(' ', '', $card_number)) < 13) {
        $error = 'Please enter a valid card number.';
    } elseif (empty($expiry_month) || empty($expiry_year)) {
        $error = 'Please enter valid expiry date.';
    } elseif (empty($cvv) || strlen($cvv) < 3) {
        $error = 'Please enter a valid CVV.';
    } elseif (empty($cardholder_name)) {
        $error = 'Please enter cardholder name.';
    } else {
        // Store card details for processing
        $card_details = [
            'card_number' => $card_number,
            'expiry_month' => $expiry_month,
            'expiry_year' => $expiry_year,
            'cvv' => $cvv,
            'cardholder_name' => $cardholder_name
        ];
        
        // For demo purposes, simulate payment processing
        // In production, you would integrate with actual Razorpay API
        $success = processCardPayment($order_id, $amount, $card_details);
        
        if ($success) {
            // Redirect to success callback
            header("Location: payment-callback.php?test=success&order_id=" . $order_id . "&amount=" . $amount . "&method=razorpay&card_last4=" . substr(str_replace(' ', '', $card_number), -4));
            exit();
        } else {
            $error = 'Payment processing failed. Please check your card details and try again.';
        }
    }
}

function processCardPayment($order_id, $amount, $card_details) {
    // Demo payment processing - always returns true for valid card numbers
    // In production, integrate with Razorpay API
    
    $card_number = str_replace(' ', '', $card_details['card_number']);
    
    // Demo: Reject cards ending with 0000
    if (substr($card_number, -4) === '0000') {
        return false;
    }
    
    // Demo: Accept all other valid-looking card numbers
    return true;
}

// Page configuration
$page_title = 'Card Payment';
$page_description = 'Enter your card details for secure payment';
$show_page_header = true;
$breadcrumbs = [
    ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
    ['title' => 'Book Bus', 'url' => 'enhanced-booking-system.php', 'icon' => 'fas fa-search'],
    ['title' => 'Select Seats', 'url' => 'seat-selection.php', 'icon' => 'fas fa-chair'],
    ['title' => 'Payment', 'url' => 'payment.php', 'icon' => 'fas fa-credit-card'],
    ['title' => 'Card Payment', 'icon' => 'fas fa-credit-card']
];

// Custom CSS for card payment
$custom_css = '
        .payment-container {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .payment-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .payment-header {
            background: linear-gradient(135deg, #3395ff 0%, #1e3c72 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .payment-body {
            padding: 30px;
        }
        
        .amount-display {
            font-size: 2.5rem;
            font-weight: bold;
            color: #28a745;
            margin: 20px 0;
        }
        
        .card-form {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            margin: 20px 0;
        }
        
        .card-visual {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            padding: 20px;
            color: white;
            margin-bottom: 20px;
            min-height: 180px;
            position: relative;
            overflow: hidden;
        }
        
        .card-visual::before {
            content: "";
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
        }
        
        .card-number-display {
            font-family: "Courier New", monospace;
            font-size: 1.2rem;
            letter-spacing: 2px;
            margin: 20px 0;
        }
        
        .card-details {
            display: flex;
            justify-content: space-between;
            align-items: end;
            margin-top: 20px;
        }
        
        .card-holder {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .card-expiry {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .card-logo {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 2rem;
        }
        
        .form-control {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #3395ff;
            box-shadow: 0 0 0 0.2rem rgba(51, 149, 255, 0.25);
        }
        
        .security-features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .security-feature {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            background: rgba(40, 167, 69, 0.1);
            border-radius: 8px;
            border-left: 4px solid #28a745;
        }
        
        .security-feature i {
            color: #28a745;
        }
        
        @media (max-width: 768px) {
            .payment-body {
                padding: 20px;
            }
            
            .amount-display {
                font-size: 2rem;
            }
            
            .card-form {
                padding: 20px;
            }
        }
';

include 'includes/header.php';
?>

<!-- Content Section -->
<section class="content-section">
    <div class="container payment-container">
        <div class="payment-card" data-aos="fade-up">
            <!-- Header -->
            <div class="payment-header">
                <h1><i class="fas fa-credit-card"></i> Card Payment</h1>
                <p class="mb-0">Enter your card details for secure payment</p>
            </div>
            
            <!-- Body -->
            <div class="payment-body">
                <!-- Amount Display -->
                <div class="text-center">
                    <div class="amount-display">₹<?php echo number_format($amount, 2); ?></div>
                    <p class="text-muted">Order ID: <?php echo $order_id; ?></p>
                </div>
                
                <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <!-- Card Form -->
                <form method="POST" id="cardPaymentForm">
                    <div class="card-form">
                        <!-- Card Visual -->
                        <div class="card-visual">
                            <div class="card-logo">
                                <i class="fab fa-cc-visa" id="cardLogo"></i>
                            </div>
                            <div class="card-number-display" id="cardNumberDisplay">
                                **** **** **** ****
                            </div>
                            <div class="card-details">
                                <div class="card-holder">
                                    <div style="font-size: 0.7rem; opacity: 0.7;">CARD HOLDER</div>
                                    <div id="cardHolderDisplay">YOUR NAME</div>
                                </div>
                                <div class="card-expiry">
                                    <div style="font-size: 0.7rem; opacity: 0.7;">EXPIRES</div>
                                    <div id="cardExpiryDisplay">MM/YY</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Card Number -->
                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-credit-card me-2"></i>
                                Card Number
                            </label>
                            <input type="text" class="form-control" name="card_number" id="cardNumber" 
                                   placeholder="1234 5678 9012 3456" maxlength="19" required
                                   oninput="formatCardNumber(this); updateCardDisplay()">
                        </div>
                        
                        <!-- Expiry and CVV -->
                        <div class="row">
                            <div class="col-md-4">
                                <label class="form-label">
                                    <i class="fas fa-calendar me-2"></i>
                                    Expiry Month
                                </label>
                                <select class="form-control" name="expiry_month" id="expiryMonth" required onchange="updateCardDisplay()">
                                    <option value="">MM</option>
                                    <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo sprintf('%02d', $i); ?>"><?php echo sprintf('%02d', $i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">
                                    <i class="fas fa-calendar me-2"></i>
                                    Expiry Year
                                </label>
                                <select class="form-control" name="expiry_year" id="expiryYear" required onchange="updateCardDisplay()">
                                    <option value="">YY</option>
                                    <?php for($i = date('Y'); $i <= date('Y') + 10; $i++): ?>
                                    <option value="<?php echo substr($i, -2); ?>"><?php echo substr($i, -2); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">
                                    <i class="fas fa-lock me-2"></i>
                                    CVV
                                </label>
                                <input type="password" class="form-control" name="cvv" id="cvv" 
                                       placeholder="123" maxlength="4" required>
                            </div>
                        </div>
                        
                        <!-- Cardholder Name -->
                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-user me-2"></i>
                                Cardholder Name
                            </label>
                            <input type="text" class="form-control" name="cardholder_name" id="cardholderName" 
                                   placeholder="Enter name as on card" value="<?php echo htmlspecialchars($user['full_name']); ?>" 
                                   required oninput="updateCardDisplay()">
                        </div>
                    </div>
                    
                    <!-- Security Features -->
                    <div class="security-features">
                        <div class="security-feature">
                            <i class="fas fa-shield-alt"></i>
                            <span>SSL Secured</span>
                        </div>
                        <div class="security-feature">
                            <i class="fas fa-lock"></i>
                            <span>256-bit Encryption</span>
                        </div>
                        <div class="security-feature">
                            <i class="fas fa-credit-card"></i>
                            <span>PCI Compliant</span>
                        </div>
                        <div class="security-feature">
                            <i class="fas fa-check-circle"></i>
                            <span>Secure Processing</span>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="d-grid gap-2">
                        <button type="submit" name="process_payment" class="btn btn-primary btn-lg">
                            <i class="fas fa-lock me-2"></i>
                            Pay ₹<?php echo number_format($amount, 2); ?>
                        </button>
                        
                        <div class="row g-2">
                            <div class="col-6">
                                <a href="payment.php" class="btn btn-outline-secondary w-100">
                                    <i class="fas fa-arrow-left me-2"></i>
                                    Back
                                </a>
                            </div>
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-success w-100" onclick="fillDemoCard()">
                                    <i class="fas fa-magic me-2"></i>
                                    Demo Card
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
                
                <!-- Demo Information -->
                <div class="alert alert-info mt-4">
                    <h6><i class="fas fa-info-circle"></i> Demo Mode:</h6>
                    <ul class="mb-0">
                        <li>Use any valid card number format (e.g., 4111 1111 1111 1111)</li>
                        <li>Cards ending with 0000 will be declined for testing</li>
                        <li>Any future expiry date and 3-digit CVV will work</li>
                        <li>Click "Demo Card" to auto-fill test card details</li>
                    </ul>
                </div>
                
                <!-- Support Info -->
                <div class="text-center mt-4">
                    <small class="text-muted">
                        <i class="fas fa-shield-alt"></i>
                        Your card details are secure and encrypted | 
                        <i class="fas fa-phone"></i>
                        Support: +91 9356437871
                    </small>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Custom JavaScript for card payment
$custom_js = '
        function formatCardNumber(input) {
            let value = input.value.replace(/\s/g, "").replace(/[^0-9]/gi, "");
            let formattedValue = value.match(/.{1,4}/g)?.join(" ") || value;
            input.value = formattedValue;
        }
        
        function updateCardDisplay() {
            const cardNumber = document.getElementById("cardNumber").value || "**** **** **** ****";
            const cardholderName = document.getElementById("cardholderName").value || "YOUR NAME";
            const expiryMonth = document.getElementById("expiryMonth").value || "MM";
            const expiryYear = document.getElementById("expiryYear").value || "YY";
            
            document.getElementById("cardNumberDisplay").textContent = cardNumber;
            document.getElementById("cardHolderDisplay").textContent = cardholderName.toUpperCase();
            document.getElementById("cardExpiryDisplay").textContent = expiryMonth + "/" + expiryYear;
            
            // Update card logo based on card number
            const firstDigit = cardNumber.replace(/\s/g, "")[0];
            const cardLogo = document.getElementById("cardLogo");
            
            switch(firstDigit) {
                case "4":
                    cardLogo.className = "fab fa-cc-visa";
                    break;
                case "5":
                    cardLogo.className = "fab fa-cc-mastercard";
                    break;
                case "3":
                    cardLogo.className = "fab fa-cc-amex";
                    break;
                default:
                    cardLogo.className = "fas fa-credit-card";
            }
        }
        
        function fillDemoCard() {
            document.getElementById("cardNumber").value = "4111 1111 1111 1111";
            document.getElementById("expiryMonth").value = "12";
            document.getElementById("expiryYear").value = "25";
            document.getElementById("cvv").value = "123";
            updateCardDisplay();
        }
        
        // Initialize card display
        document.addEventListener("DOMContentLoaded", function() {
            updateCardDisplay();
        });
        
        // Form validation
        document.getElementById("cardPaymentForm").addEventListener("submit", function(e) {
            const cardNumber = document.getElementById("cardNumber").value.replace(/\s/g, "");
            const cvv = document.getElementById("cvv").value;
            const cardholderName = document.getElementById("cardholderName").value;
            
            if (cardNumber.length < 13) {
                e.preventDefault();
                alert("Please enter a valid card number.");
                return;
            }
            
            if (cvv.length < 3) {
                e.preventDefault();
                alert("Please enter a valid CVV.");
                return;
            }
            
            if (cardholderName.trim().length < 2) {
                e.preventDefault();
                alert("Please enter the cardholder name.");
                return;
            }
        });
';

include 'includes/footer.php';
?>
            padding: 30px;
            text-align: center;
        }
        .payment-body {
            padding: 30px;
        }
        .razorpay-logo {
            width: 150px;
            height: auto;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="payment-card">
        <div class="payment-header">
            <h2><i class="fas fa-credit-card"></i> Razorpay Payment</h2>
            <p class="mb-0">Secure card payment processing</p>
        </div>
        
        <div class="payment-body text-center">
            <div class="mb-4">
                <h4>Amount to Pay</h4>
                <h2 class="text-success">₹<?php echo number_format($amount, 2); ?></h2>
            </div>
            
            <div class="mb-4">
                <p><strong>Order ID:</strong> <?php echo $order_id; ?></p>
                <p><strong>Razorpay Order:</strong> <?php echo $razorpay_order['id']; ?></p>
            </div>
            
            <button id="rzp-button" class="btn btn-primary btn-lg w-100 mb-3">
                <i class="fas fa-lock me-2"></i>
                Pay with Razorpay
            </button>
            
            <a href="payment.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>
                Back to Payment Options
            </a>
            
            <div class="mt-4">
                <small class="text-muted">
                    <i class="fas fa-shield-alt"></i>
                    Secured by Razorpay | PCI DSS Compliant
                </small>
            </div>
        </div>
    </div>

    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        document.getElementById('rzp-button').onclick = function(e) {
            const options = {
                "key": "<?php echo RAZORPAY_KEY_ID; ?>",
                "amount": <?php echo $amount * 100; ?>,
                "currency": "INR",
                "name": "SR Travels",
                "description": "Bus Booking Payment",
                "order_id": "<?php echo $razorpay_order['id']; ?>",
                "handler": function (response) {
                    // Redirect to callback with payment details
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'razorpay-callback.php';
                    
                    const fields = {
                        'razorpay_payment_id': response.razorpay_payment_id,
                        'razorpay_order_id': response.razorpay_order_id,
                        'razorpay_signature': response.razorpay_signature,
                        'order_id': '<?php echo $order_id; ?>',
                        'amount': '<?php echo $amount; ?>'
                    };
                    
                    for (const key in fields) {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = key;
                        input.value = fields[key];
                        form.appendChild(input);
                    }
                    
                    document.body.appendChild(form);
                    form.submit();
                },
                "prefill": {
                    "name": "<?php echo $user['name'] ?? ''; ?>",
                    "email": "<?php echo $user['email'] ?? ''; ?>",
                    "contact": "<?php echo $user['phone'] ?? ''; ?>"
                },
                "theme": {
                    "color": "#3395ff"
                },
                "modal": {
                    "ondismiss": function() {
                        console.log('Payment cancelled by user');
                    }
                }
            };
            
            const rzp = new Razorpay(options);
            rzp.open();
            e.preventDefault();
        }
    </script>
</body>
</html>