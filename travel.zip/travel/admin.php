<?php
require_once 'config.php';

// Check if user is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: admin-login.php");
    exit();
}

// Get statistics
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'];
$total_buses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM buses"))['count'];
$seater_buses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM buses WHERE bus_type = 'seater'"))['count'];
$sleeper_buses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM buses WHERE bus_type = 'sleeper'"))['count'];
$today_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings WHERE DATE(booking_date) = CURDATE()"))['count'];
$total_revenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) as total FROM bookings WHERE payment_status = 'paid'"))['total'];
$total_revenue = $total_revenue ?: 0;

// Get recent bookings
$recent_bookings_query = mysqli_query($conn, 
    "SELECT b.booking_id, u.full_name, b.total_amount, b.booking_status 
     FROM bookings b 
     JOIN users u ON b.user_id = u.id 
     ORDER BY b.booking_date DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <style>
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --accent-color: #ffc107;
            --dark-color: #1a1a2e;
            --light-color: #f8f9fa;
        }
        
        body {
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
            min-height: 100vh;
        }
        
        #bg3d {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 0.3;
        }
        
        .navbar-3d {
            background: rgba(26, 26, 46, 0.9);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(102, 126, 234, 0.3);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            transform-style: preserve-3d;
            transform: translateZ(10px);
        }
        
        .sidebar-3d {
            background: rgba(26, 26, 46, 0.85);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(102, 126, 234, 0.2);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transform-style: preserve-3d;
            transform: translateZ(20px) rotateY(-2deg);
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .sidebar-3d:hover {
            transform: translateZ(30px) rotateY(0deg);
            box-shadow: 0 20px 40px rgba(102, 126, 234, 0.2);
        }
        
        .nav-link-3d {
            color: #fff;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 10px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            transform-style: preserve-3d;
            transform: translateZ(0);
            position: relative;
            overflow: hidden;
        }
        
        .nav-link-3d::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(102, 126, 234, 0.3), transparent);
            transition: left 0.5s;
        }
        
        .nav-link-3d:hover::before {
            left: 100%;
        }
        
        .nav-link-3d:hover {
            background: rgba(102, 126, 234, 0.2);
            transform: translateZ(10px) translateX(10px);
            color: var(--accent-color);
        }
        
        .nav-link-3d.active {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            transform: translateZ(20px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .card-3d {
            background: rgba(26, 26, 46, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            border: 1px solid rgba(102, 126, 234, 0.2);
            color: white;
            transform-style: preserve-3d;
            transform: translateZ(0);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
        }
        
        .card-3d:hover {
            transform: translateZ(20px) translateY(-10px);
            box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3);
            border-color: rgba(102, 126, 234, 0.4);
        }
        
        .card-3d::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.3s ease;
        }
        
        .card-3d:hover::before {
            transform: scaleX(1);
        }
        
        .stat-card {
            padding: 25px;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::after {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(102, 126, 234, 0.1) 0%, transparent 70%);
            transform: rotate(45deg);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
            transition: all 0.3s;
        }
        
        .card-3d:hover .stat-icon {
            transform: scale(1.2) rotate(10deg);
            opacity: 1;
        }
        
        .btn-3d {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            padding: 10px 25px;
            border-radius: 10px;
            font-weight: 600;
            transform-style: preserve-3d;
            transform: translateZ(0);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .btn-3d::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }
        
        .btn-3d:hover {
            transform: translateZ(10px) translateY(-3px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-3d:hover::before {
            left: 100%;
        }
        
        .btn-3d:active {
            transform: translateZ(5px) translateY(-1px);
        }
        
        .table-3d {
            background: rgba(26, 26, 46, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid rgba(102, 126, 234, 0.2);
        }
        
        .table-3d th {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            font-weight: 600;
            padding: 15px;
        }
        
        .table-3d td {
            border-color: rgba(102, 126, 234, 0.2);
            color: #ddd;
            padding: 12px 15px;
            vertical-align: middle;
        }
        
        .table-3d tr:hover td {
            background: rgba(102, 126, 234, 0.1);
            transform: scale(1.02);
            transition: all 0.3s;
        }
        
        .progress-3d {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            height: 8px;
            overflow: hidden;
            transform-style: preserve-3d;
            transform: translateZ(5px);
        }
        
        .progress-bar-3d {
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 10px;
            position: relative;
            overflow: hidden;
        }
        
        .progress-bar-3d::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .badge-3d {
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: 600;
            transform-style: preserve-3d;
            transform: translateZ(5px);
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
        }
        
        .logo-3d {
            font-size: 24px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 2px;
            background: linear-gradient(135deg, #fff, var(--accent-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            transform-style: preserve-3d;
            text-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        
        .admin-welcome {
            font-size: 14px;
            color: #ddd;
            margin-right: 15px;
        }
        
        .admin-name {
            color: var(--accent-color);
            font-weight: 600;
        }
        
        .modal-3d .modal-content {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(102, 126, 234, 0.3);
            color: white;
            transform-style: preserve-3d;
            transform: translateZ(50px);
        }
        
        .modal-3d .modal-header {
            border-bottom: 1px solid rgba(102, 126, 234, 0.3);
        }
        
        .modal-3d .btn-close {
            filter: invert(1);
        }
        
        .floating-element {
            animation: float 6s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px) translateZ(0); }
            50% { transform: translateY(-10px) translateZ(10px); }
        }
        
        .glow-text {
            text-shadow: 0 0 10px rgba(102, 126, 234, 0.5);
        }
        
        .dashboard-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            display: inline-block;
        }
        
        .dashboard-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 25%;
            width: 50%;
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--primary-color), transparent);
            border-radius: 2px;
        }
        
        .chart-container-3d {
            background: rgba(26, 26, 46, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            border: 1px solid rgba(102, 126, 234, 0.2);
            transform-style: preserve-3d;
            transform: translateZ(10px);
        }
        
        /* Loading animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(102, 126, 234, 0.3);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Scrollbar styling */
        ::-webkit-scrollbar {
            width: 10px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(26, 26, 46, 0.5);
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 5px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sidebar-3d {
                transform: none !important;
                margin-bottom: 20px;
            }
            
            .dashboard-title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- 3D Background -->
    <div id="bg3d"></div>
    
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-3d">
        <div class="container-fluid">
            <a class="navbar-brand logo-3d" href="admin.php">
                <i class="fas fa-cube me-2"></i>SR<span style="color: var(--accent-color)">TRAVELS</span> 3D
            </a>
            <div class="d-flex align-items-center">
                <div class="admin-welcome">
                    Welcome, <span class="admin-name"><?php echo $_SESSION['full_name']; ?></span>
                </div>
                <div class="dropdown">
                    <button class="btn btn-3d dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown">
                        <i class="fas fa-user-shield me-2"></i><?php echo $_SESSION['admin_role']; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end modal-3d" style="min-width: 200px;">
                        <li><a class="dropdown-item" href="admin-profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin-settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid py-4">
        <div class="row">
            <!-- 3D Sidebar -->
            <div class="col-lg-2 mb-4">
                <div class="sidebar-3d p-3 floating-element">
                    <nav class="nav flex-column">
                        <a class="nav-link-3d active" href="admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                        <a class="nav-link-3d" href="admin-buses.php">
                            <i class="fas fa-bus me-2"></i> Manage Buses
                        </a>
                        <a class="nav-link-3d" href="admin-routes.php">
                            <i class="fas fa-route me-2"></i> Manage Routes
                        </a>
                        <a class="nav-link-3d" href="admin-booking.php">
                            <i class="fas fa-plus-circle me-2"></i> Create Booking
                        </a>
                        <a class="nav-link-3d" href="admin-bookings.php">
                            <i class="fas fa-ticket-alt me-2"></i> View Bookings
                        </a>
                        <a class="nav-link-3d" href="admin-users.php">
                            <i class="fas fa-users me-2"></i> Users
                        </a>
                        <a class="nav-link-3d" href="admin-manage.php">
                            <i class="fas fa-user-shield me-2"></i> Manage Admins
                        </a>
                        <a class="nav-link-3d" href="admin-payments.php">
                            <i class="fas fa-credit-card me-2"></i> Payments
                        </a>
                        <a class="nav-link-3d" href="admin-reports.php">
                            <i class="fas fa-chart-bar me-2"></i> Reports
                        </a>
                        
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-lg-10">
                <h1 class="dashboard-title glow-text">Admin Dashboard</h1>
                
                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card-3d stat-card floating-element" style="animation-delay: 0s;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-subtitle mb-2 text-muted">Total Users</h6>
                                        <h2 class="card-title mb-0"><?php echo $total_users; ?></h2>
                                        <small class="text-success">+12% this month</small>
                                    </div>
                                    <div class="stat-icon">
                                        <i class="fas fa-users"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card-3d stat-card floating-element" style="animation-delay: 0.2s;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-subtitle mb-2 text-muted">Total Buses</h6>
                                        <h2 class="card-title mb-0"><?php echo $total_buses; ?></h2>
                                        <small><?php echo $seater_buses; ?> Seater, <?php echo $sleeper_buses; ?> Sleeper</small>
                                    </div>
                                    <div class="stat-icon">
                                        <i class="fas fa-bus"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card-3d stat-card floating-element" style="animation-delay: 0.4s;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-subtitle mb-2 text-muted">Today's Bookings</h6>
                                        <h2 class="card-title mb-0"><?php echo $today_bookings; ?></h2>
                                        <small class="text-success">+5 from yesterday</small>
                                    </div>
                                    <div class="stat-icon">
                                        <i class="fas fa-ticket-alt"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card-3d stat-card floating-element" style="animation-delay: 0.6s;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-subtitle mb-2 text-muted">Total Revenue</h6>
                                        <h2 class="card-title mb-0">₹<?php echo number_format($total_revenue, 2); ?></h2>
                                        <small class="text-success">+18% growth</small>
                                    </div>
                                    <div class="stat-icon">
                                        <i class="fas fa-rupee-sign"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Charts and Recent Bookings -->
                <div class="row mb-4">
                    <div class="col-lg-8 mb-4">
                        <div class="card-3d h-100">
                            <div class="card-body">
                                <h5 class="card-title">Bus Type Distribution</h5>
                                <div class="d-flex align-items-center mt-3">
                                    <div class="me-4">
                                        <div class="d-flex align-items-center mb-2">
                                            <div class="bg-info rounded me-2" style="width: 20px; height: 20px;"></div>
                                            <span>Seater Buses: <?php echo $seater_buses; ?></span>
                                        </div>
                                        <div class="d-flex align-items-center">
                                            <div class="bg-warning rounded me-2" style="width: 20px; height: 20px;"></div>
                                            <span>Sleeper Buses: <?php echo $sleeper_buses; ?></span>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="progress progress-3d" style="height: 20px;">
                                            <?php
                                            $seater_percentage = $total_buses > 0 ? ($seater_buses / $total_buses) * 100 : 0;
                                            $sleeper_percentage = $total_buses > 0 ? ($sleeper_buses / $total_buses) * 100 : 0;
                                            ?>
                                            <div class="progress-bar progress-bar-3d bg-info" role="progressbar" 
                                                 style="width: <?php echo $seater_percentage; ?>%" 
                                                 aria-valuenow="<?php echo $seater_percentage; ?>" 
                                                 aria-valuemin="0" 
                                                 aria-valuemax="100">
                                                <?php echo number_format($seater_percentage, 1); ?>%
                                            </div>
                                            <div class="progress-bar progress-bar-3d bg-warning" role="progressbar" 
                                                 style="width: <?php echo $sleeper_percentage; ?>%" 
                                                 aria-valuenow="<?php echo $sleeper_percentage; ?>" 
                                                 aria-valuemin="0" 
                                                 aria-valuemax="100">
                                                <?php echo number_format($sleeper_percentage, 1); ?>%
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mb-4">
                        <div class="card-3d h-100">
                            <div class="card-body">
                                <h5 class="card-title">System Status</h5>
                                <div class="mt-3">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Server Load</span>
                                        <span class="text-success">65%</span>
                                    </div>
                                    <div class="progress progress-3d mb-3">
                                        <div class="progress-bar progress-bar-3d bg-success" style="width: 65%"></div>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Database</span>
                                        <span class="text-info">Connected</span>
                                    </div>
                                    <div class="progress progress-3d mb-3">
                                        <div class="progress-bar progress-bar-3d bg-info" style="width: 100%"></div>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Uptime</span>
                                        <span class="text-warning">99.8%</span>
                                    </div>
                                    <div class="progress progress-3d">
                                        <div class="progress-bar progress-bar-3d bg-warning" style="width: 99.8%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Bookings Table -->
                <div class="row">
                    <div class="col-12">
                        <div class="card-3d">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5 class="card-title mb-0">Recent Bookings</h5>
                                    <a href="admin-bookings.php" class="btn btn-3d btn-sm">
                                        <i class="fas fa-eye me-1"></i> View All
                                    </a>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-3d table-hover">
                                        <thead>
                                            <tr>
                                                <th>Booking ID</th>
                                                <th>User</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while($booking = mysqli_fetch_assoc($recent_bookings_query)): ?>
                                            <tr>
                                                <td><span class="badge bg-dark"><?php echo $booking['booking_id']; ?></span></td>
                                                <td><?php echo $booking['full_name']; ?></td>
                                                <td>₹<?php echo $booking['total_amount']; ?></td>
                                                <td>
                                                    <span class="badge badge-3d bg-<?php 
                                                        echo $booking['booking_status'] == 'confirmed' ? 'success' : 
                                                             ($booking['booking_status'] == 'pending' ? 'warning' : 
                                                             ($booking['booking_status'] == 'completed' ? 'info' : 'danger')); 
                                                    ?>">
                                                        <?php echo ucfirst($booking['booking_status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm btn-3d" onclick="viewBooking('<?php echo $booking['booking_id']; ?>')">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card-3d">
                            <div class="card-body">
                                <h5 class="card-title mb-3">Quick Actions</h5>
                                <div class="d-flex flex-wrap gap-3">
                                    <a href="admin-buses.php?action=add" class="btn btn-3d">
                                        <i class="fas fa-plus me-2"></i> Add New Bus
                                    </a>
                                    <a href="admin-routes.php?action=add" class="btn btn-3d">
                                        <i class="fas fa-route me-2"></i> Add New Route
                                    </a>
                                    <a href="admin-booking.php" class="btn btn-3d">
                                        <i class="fas fa-ticket-alt me-2"></i> Create Booking
                                    </a>
                                    <a href="admin-users.php" class="btn btn-3d">
                                        <i class="fas fa-users me-2"></i> Manage Users
                                    </a>
                                    <a href="admin-reports.php" class="btn btn-3d">
                                        <i class="fas fa-chart-bar me-2"></i> Generate Report
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 3D Background Script -->
    <script>
        // Create 3D scene
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.getElementById('bg3d').appendChild(renderer.domElement);

        // Create floating cubes
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        const material = new THREE.MeshBasicMaterial({ 
            color: 0x667eea,
            wireframe: true,
            transparent: true,
            opacity: 0.1
        });
        
        const cubes = [];
        for (let i = 0; i < 15; i++) {
            const cube = new THREE.Mesh(geometry, material);
            cube.position.x = Math.random() * 40 - 20;
            cube.position.y = Math.random() * 40 - 20;
            cube.position.z = Math.random() * 40 - 20;
            cube.rotationSpeed = Math.random() * 0.02;
            cubes.push(cube);
            scene.add(cube);
        }

        camera.position.z = 5;

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            
            cubes.forEach(cube => {
                cube.rotation.x += cube.rotationSpeed;
                cube.rotation.y += cube.rotationSpeed;
                
                // Slow floating movement
                cube.position.y += Math.sin(Date.now() * 0.001 + cube.position.x) * 0.01;
                cube.position.x += Math.cos(Date.now() * 0.001 + cube.position.y) * 0.01;
            });
            
            renderer.render(scene, camera);
        }
        animate();

        // Handle window resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        // Dashboard functions
        function viewBooking(bookingId) {
            // In a real application, this would fetch booking details
            alert('Viewing booking: ' + bookingId);
            // window.location.href = 'admin-booking-details.php?id=' + bookingId;
        }

        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Add hover effects to cards
        document.querySelectorAll('.card-3d').forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.zIndex = '100';
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.zIndex = '1';
            });
        });

        // Update real-time data
        function updateRealTimeData() {
            // Simulate real-time updates
            document.querySelectorAll('.stat-card').forEach(card => {
                const number = card.querySelector('.card-title');
                if (number) {
                    const current = parseInt(number.textContent.replace(/,/g, ''));
                    if (!isNaN(current) && Math.random() > 0.7) {
                        const newValue = current + Math.floor(Math.random() * 5);
                        number.textContent = newValue.toLocaleString();
                    }
                }
            });
        }

        // Update every 30 seconds
        setInterval(updateRealTimeData, 30000);
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>