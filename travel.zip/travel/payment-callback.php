<?php
// payment-callback.php
session_start();
require_once 'config.php';
require_once 'paytm-config.php';
require_once 'lib_paytm.php';

// Log callback request
log_payment_debug('Callback received', [
    'GET' => $_GET,
    'POST' => $_POST,
    'SESSION' => isset($_SESSION) ? $_SESSION : []
]);

// Handle test callbacks
if (isset($_GET['test'])) {
    handle_test_callback();
    exit();
}

// Handle real PayTM callback
handle_paytm_callback();
exit();

function handle_test_callback() {
    global $conn;
    
    $test_type = $_GET['test'];
    $order_id = isset($_GET['order_id']) ? $_GET['order_id'] : '';
    $amount = isset($_GET['amount']) ? (float)$_GET['amount'] : 0;
    $payment_method = isset($_GET['method']) ? $_GET['method'] : 'test';
    $bank_code = isset($_GET['bank']) ? $_GET['bank'] : '';
    
    log_payment_debug('Test callback', [
        'type' => $test_type, 
        'order_id' => $order_id, 
        'amount' => $amount,
        'method' => $payment_method,
        'bank' => $bank_code
    ]);
    
    if (empty($order_id)) {
        $_SESSION['payment_error'] = 'Invalid test order ID';
        header("Location: payment-failed.php");
        exit();
    }
    
    switch ($test_type) {
        case 'success':
            // Simulate successful payment
            $payment_data = [
                'transaction_id' => 'TEST_' . strtoupper($payment_method) . '_' . time(),
                'payment_mode' => $payment_method,
                'bank_name' => $bank_code ? get_bank_name($bank_code) : '',
                'bank_txn_id' => 'BANK_TXN_' . time() . '_' . rand(1000, 9999)
            ];
            handle_successful_payment($order_id, $amount, true, $payment_data);
            break;
            
        case 'failed':
            // Simulate failed payment
            $error_message = get_payment_error_message($payment_method);
            $_SESSION['payment_error'] = $error_message;
            complete_pending_booking($order_id, 'failed');
            header("Location: payment-failed.php");
            exit();
            break;
            
        case 'pending':
            // Simulate pending payment
            $pending_message = get_payment_pending_message($payment_method);
            $_SESSION['payment_error'] = $pending_message;
            complete_pending_booking($order_id, 'failed');
            header("Location: payment-failed.php");
            exit();
            break;
            
        default:
            $_SESSION['payment_error'] = 'Invalid test type';
            header("Location: payment-failed.php");
            exit();
    }
}

function get_bank_name($bank_code) {
    $banks = [
        'sbi' => 'State Bank of India',
        'hdfc' => 'HDFC Bank',
        'icici' => 'ICICI Bank',
        'axis' => 'Axis Bank',
        'kotak' => 'Kotak Mahindra Bank',
        'pnb' => 'Punjab National Bank',
        'canara' => 'Canara Bank',
        'bob' => 'Bank of Baroda',
        'union' => 'Union Bank of India',
        'idbi' => 'IDBI Bank',
        'yes' => 'Yes Bank',
        'indusind' => 'IndusInd Bank',
        'other' => 'Other Bank'
    ];
    
    return isset($banks[$bank_code]) ? $banks[$bank_code] : 'Unknown Bank';
}

function get_payment_error_message($payment_method) {
    switch ($payment_method) {
        case 'netbanking':
            return 'Net banking payment failed. Please check your bank account and try again.';
        case 'upi_qr':
            return 'UPI payment failed. Please try again with a different UPI app.';
        case 'razorpay':
            return 'Card payment failed. Please check your card details and try again.';
        default:
            return 'Payment failed. Please try again.';
    }
}

function get_payment_pending_message($payment_method) {
    switch ($payment_method) {
        case 'netbanking':
            return 'Net banking payment is pending. Please check with your bank or try again.';
        case 'upi_qr':
            return 'UPI payment is pending. Please complete the payment in your UPI app.';
        case 'razorpay':
            return 'Card payment is pending. Please check your payment status.';
        default:
            return 'Payment is pending. Please check your payment status.';
    }
}
}

function handle_paytm_callback() {
    global $conn;
    
    $paytmChecksum = "";
    $paramList = $_POST;
    $isValidChecksum = "FALSE";
    
    // Get checksum from POST data
    $paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : "";
    
    // Verify checksum
    $isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum);
    
    log_payment_debug('PayTM callback verification', [
        'checksum_valid' => $isValidChecksum,
        'status' => isset($_POST["STATUS"]) ? $_POST["STATUS"] : 'unknown'
    ]);
    
    if ($isValidChecksum == "TRUE") {
        if (isset($_POST["STATUS"]) && $_POST["STATUS"] == "TXN_SUCCESS") {
            // Payment successful
            $order_id = $_POST['ORDERID'];
            $transaction_id = $_POST['TXNID'];
            $amount = $_POST['TXNAMOUNT'];
            $payment_mode = isset($_POST['PAYMENTMODE']) ? $_POST['PAYMENTMODE'] : 'PayTM';
            
            handle_successful_payment($order_id, $amount, false, [
                'transaction_id' => $transaction_id,
                'payment_mode' => $payment_mode,
                'bank_name' => isset($_POST['BANKNAME']) ? $_POST['BANKNAME'] : '',
                'bank_txn_id' => isset($_POST['BANKTXNID']) ? $_POST['BANKTXNID'] : ''
            ]);
            
        } else {
            // Payment failed
            $order_id = isset($_POST['ORDERID']) ? $_POST['ORDERID'] : 'Unknown';
            $status = isset($_POST["STATUS"]) ? $_POST["STATUS"] : 'Unknown';
            
            log_payment_attempt($order_id, isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0, 
                              isset($_POST['TXNAMOUNT']) ? $_POST['TXNAMOUNT'] : 0, 
                              'paytm', 'failed', 'Status: ' . $status);
            
            complete_pending_booking($order_id, 'failed');
            
            $_SESSION['payment_error'] = "Payment failed. Status: " . $status;
            header("Location: payment-failed.php");
            exit();
        }
    } else {
        // Invalid checksum
        log_payment_attempt('unknown', 0, 0, 'paytm', 'failed', 'Invalid checksum');
        
        $_SESSION['payment_error'] = "Security check failed. Invalid transaction.";
        header("Location: payment-failed.php");
        exit();
    }
}

function handle_successful_payment($order_id, $amount, $is_test = false, $payment_data = []) {
    global $conn;
    
    // Enhanced logging
    error_log("Processing successful payment - Order: $order_id, Amount: $amount, Test: " . ($is_test ? 'Yes' : 'No'));
    
    log_payment_debug('Processing successful payment', [
        'order_id' => $order_id,
        'amount' => $amount,
        'is_test' => $is_test,
        'payment_data' => $payment_data
    ]);
    
    // Get pending booking
    $pending_booking = get_pending_booking($order_id);
    
    if (!$pending_booking) {
        error_log("No pending booking found for order: $order_id");
        $_SESSION['payment_error'] = "No pending booking found for order: $order_id";
        header("Location: payment-failed.php");
        exit();
    }
    
    error_log("Pending booking found: " . print_r($pending_booking, true));
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Generate final booking ID
        $booking_id = generate_booking_id();
        
        // Get bus_id from route
        $route_query = "SELECT bus_id FROM bus_routes WHERE id = " . $pending_booking['route_id'];
        $route_result = mysqli_query($conn, $route_query);
        $route = mysqli_fetch_assoc($route_result);
        $bus_id = $route['bus_id'];
        
        // Create final booking
        $seats_count = count(explode(',', $pending_booking['seats']));
        $booking_query = "INSERT INTO bookings (
            booking_id, user_id, bus_id, route_id, travel_date, 
            seats_booked, total_seats, total_amount, 
            payment_method, booking_status, payment_status
        ) VALUES (
            '$booking_id',
            {$pending_booking['user_id']},
            $bus_id,
            {$pending_booking['route_id']},
            '{$pending_booking['travel_date']}',
            '{$pending_booking['seats']}',
            $seats_count,
            $amount,
            '" . ($is_test ? 'test' : ($payment_data['payment_mode'] ?? 'paytm')) . "',
            'confirmed',
            'paid'
        )";
        
        if (mysqli_query($conn, $booking_query)) {
            $booking_insert_id = mysqli_insert_id($conn);
            
            // Create payment record
            $payment_id = 'PAY_' . date('YmdHis') . '_' . rand(1000, 9999);
            $payment_query = "INSERT INTO payments (
                booking_id, payment_id, order_id, amount, 
                payment_method, payment_status, transaction_id,
                bank_name, bank_txn_id, payment_gateway
            ) VALUES (
                $booking_insert_id,
                '$payment_id',
                '$order_id',
                $amount,
                '" . ($is_test ? 'test' : ($payment_data['payment_mode'] ?? 'paytm')) . "',
                'completed',
                '" . ($payment_data['transaction_id'] ?? 'TEST_TXN_' . time()) . "',
                '" . ($payment_data['bank_name'] ?? '') . "',
                '" . ($payment_data['bank_txn_id'] ?? '') . "',
                'paytm'
            )";
            
            mysqli_query($conn, $payment_query);
            
            // Mark seats as booked
            $seats = explode(',', $pending_booking['seats']);
            foreach ($seats as $seat) {
                $seat_type = strpos($seat, 'U') === 0 ? 'sleeper_upper' : 
                            (strpos($seat, 'L') === 0 ? 'sleeper_lower' : 'seater');
                
                $seat_query = "INSERT INTO seat_availability (
                    bus_id, travel_date, seat_number, seat_type, is_available, booking_id
                ) VALUES (
                    $bus_id,
                    '{$pending_booking['travel_date']}',
                    '$seat',
                    '$seat_type',
                    FALSE,
                    $booking_insert_id
                ) ON DUPLICATE KEY UPDATE is_available = FALSE, booking_id = $booking_insert_id";
                
                mysqli_query($conn, $seat_query);
            }
            
            // Update pending booking status
            complete_pending_booking($order_id, 'completed');
            
            // Commit transaction
            mysqli_commit($conn);
            
            // Log successful payment
            log_payment_attempt($order_id, $pending_booking['user_id'], $amount, 'paytm', 'completed', 
                              $is_test ? 'Test payment' : 'Real payment');
            
            // Store success data in session
            $_SESSION['payment_success'] = true;
            $_SESSION['last_booking_id'] = $booking_insert_id;
            $_SESSION['transaction_id'] = $payment_data['transaction_id'] ?? 'TEST_TXN_' . time();
            
            // Clear payment session
            unset($_SESSION['paytm_order_id']);
            unset($_SESSION['paytm_amount']);
            unset($_SESSION['payment_method']);
            unset($_SESSION['selected_seats']);
            unset($_SESSION['route_id']);
            unset($_SESSION['travel_date']);
            unset($_SESSION['total_amount']);
            
            log_payment_debug('Payment successful, redirecting to confirmation');
            
            // Redirect to confirmation page
            header("Location: booking-confirm.php");
            exit();
            
        } else {
            throw new Exception("Booking creation failed: " . mysqli_error($conn));
        }
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        
        log_payment_attempt($order_id, $pending_booking['user_id'], $amount, 'paytm', 'failed', 
                          'Database error: ' . $e->getMessage());
        
        complete_pending_booking($order_id, 'failed');
        
        $_SESSION['payment_error'] = "Payment successful but booking failed. Please contact support with Order ID: $order_id";
        header("Location: payment-failed.php");
        exit();
    }
}
?>