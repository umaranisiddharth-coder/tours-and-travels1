<?php
require_once 'config.php';

// Check admin permissions
if (!is_logged_in() || !is_admin()) {
    header("Location: admin-login.php");
    exit();
}

$error = '';
$success = '';
$current_admin_id = $_SESSION['admin_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        $full_name = sanitize_input($_POST['full_name']);
        $email = sanitize_input($_POST['email']);
        $phone = sanitize_input($_POST['phone']);
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Get current user data
        $user_id = $_SESSION['user_id'];
        $user_sql = "SELECT password FROM users WHERE id = $user_id";
        $user_result = mysqli_query($conn, $user_sql);
        $user = mysqli_fetch_assoc($user_result);
        
        $valid = true;
        
        // Check if password change is requested
        if (!empty($new_password)) {
            if (empty($current_password)) {
                $error = "Current password is required to change password.";
                $valid = false;
            } elseif (!password_verify($current_password, $user['password'])) {
                $error = "Current password is incorrect.";
                $valid = false;
            } elseif ($new_password !== $confirm_password) {
                $error = "New passwords do not match.";
                $valid = false;
            } elseif (strlen($new_password) < 6) {
                $error = "New password must be at least 6 characters.";
                $valid = false;
            }
        }
        
        if ($valid) {
            // Update user profile
            $update_sql = "UPDATE users SET full_name = '$full_name', email = '$email', phone = '$phone'";
            
            // Update password if provided
            if (!empty($new_password)) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_sql .= ", password = '$hashed_password'";
            }
            
            $update_sql .= " WHERE id = $user_id";
            
            if (mysqli_query($conn, $update_sql)) {
                $_SESSION['full_name'] = $full_name;
                $_SESSION['email'] = $email;
                
                $success = "Profile updated successfully!";
                log_admin_activity("Updated admin profile");
                
                // If password was changed, show special message
                if (!empty($new_password)) {
                    $success .= " Password has been changed.";
                }
            } else {
                $error = "Error updating profile: " . mysqli_error($conn);
            }
        }
    }
    
    if (isset($_POST['update_preferences'])) {
        $theme = sanitize_input($_POST['theme']);
        $timezone = sanitize_input($_POST['timezone']);
        $notifications = isset($_POST['notifications']) ? 1 : 0;
        $email_alerts = isset($_POST['email_alerts']) ? 1 : 0;
        
        $pref_sql = "REPLACE INTO admin_preferences (admin_id, theme, timezone, notifications, email_alerts) 
                     VALUES ($current_admin_id, '$theme', '$timezone', $notifications, $email_alerts)";
        
        if (mysqli_query($conn, $pref_sql)) {
            $success = "Preferences saved successfully!";
            log_admin_activity("Updated admin preferences");
        } else {
            $error = "Error saving preferences: " . mysqli_error($conn);
        }
    }
    
    if (isset($_POST['update_security'])) {
        $two_factor = isset($_POST['two_factor']) ? 1 : 0;
        $session_timeout = intval($_POST['session_timeout']);
        $login_notifications = isset($_POST['login_notifications']) ? 1 : 0;
        
        $security_sql = "REPLACE INTO admin_security (admin_id, two_factor, session_timeout, login_notifications) 
                         VALUES ($current_admin_id, $two_factor, $session_timeout, $login_notifications)";
        
        if (mysqli_query($conn, $security_sql)) {
            $success = "Security settings updated successfully!";
            log_admin_activity("Updated admin security settings");
        } else {
            $error = "Error updating security settings: " . mysqli_error($conn);
        }
    }
    
    if (isset($_POST['update_system'])) {
        // Only super admin can update system settings
        if (is_super_admin()) {
            $site_name = sanitize_input($_POST['site_name']);
            $site_email = sanitize_input($_POST['site_email']);
            $booking_cutoff = intval($_POST['booking_cutoff']);
            $currency = sanitize_input($_POST['currency']);
            $maintenance_mode = isset($_POST['maintenance_mode']) ? 1 : 0;
            
            $system_sql = "REPLACE INTO system_settings 
                           (setting_key, setting_value) VALUES 
                           ('site_name', '$site_name'),
                           ('site_email', '$site_email'),
                           ('booking_cutoff', '$booking_cutoff'),
                           ('currency', '$currency'),
                           ('maintenance_mode', '$maintenance_mode')";
            
            if (mysqli_query($conn, $system_sql)) {
                $success = "System settings updated successfully!";
                log_admin_activity("Updated system settings");
            } else {
                $error = "Error updating system settings: " . mysqli_error($conn);
            }
        } else {
            $error = "Only super admin can update system settings.";
        }
    }
}

// Get admin profile data
$profile_sql = "SELECT u.*, a.admin_role 
                FROM users u 
                JOIN admin a ON u.id = a.user_id 
                WHERE a.id = $current_admin_id";
$profile_result = mysqli_query($conn, $profile_sql);
$admin_profile = mysqli_fetch_assoc($profile_result);

// Get admin preferences
$pref_sql = "SELECT * FROM admin_preferences WHERE admin_id = $current_admin_id";
$pref_result = mysqli_query($conn, $pref_sql);
$preferences = mysqli_fetch_assoc($pref_result);

// Get security settings
$security_sql = "SELECT * FROM admin_security WHERE admin_id = $current_admin_id";
$security_result = mysqli_query($conn, $security_sql);
$security = mysqli_fetch_assoc($security_result);

// Get system settings
$system_sql = "SELECT * FROM system_settings";
$system_result = mysqli_query($conn, $system_sql);
$system_settings = [];
while ($row = mysqli_fetch_assoc($system_result)) {
    $system_settings[$row['setting_key']] = $row['setting_value'];
}

// Get recent activities
$activities_sql = "SELECT * FROM admin_activity_log 
                   WHERE admin_id = $current_admin_id 
                   ORDER BY created_at DESC LIMIT 10";
$activities_result = mysqli_query($conn, $activities_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <style>
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --accent-color: #ffc107;
            --dark-color: #1a1a2e;
            --light-color: #f8f9fa;
        }
        
        body {
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
            min-height: 100vh;
        }
        
        #bg3d {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 0.3;
        }
        
        .navbar-3d {
            background: rgba(26, 26, 46, 0.9);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(102, 126, 234, 0.3);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
        }
        
        .sidebar-3d {
            background: rgba(26, 26, 46, 0.85);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(102, 126, 234, 0.2);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transform-style: preserve-3d;
            transform: translateZ(20px) rotateY(-2deg);
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .sidebar-3d:hover {
            transform: translateZ(30px) rotateY(0deg);
        }
        
        .nav-link-3d {
            color: #fff;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 10px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
        }
        
        .nav-link-3d:hover {
            background: rgba(102, 126, 234, 0.2);
            transform: translateX(10px);
            color: var(--accent-color);
        }
        
        .nav-link-3d.active {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            transform: translateX(10px) scale(1.05);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .card-3d {
            background: rgba(26, 26, 46, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            border: 1px solid rgba(102, 126, 234, 0.2);
            color: white;
            transform-style: preserve-3d;
            transform: translateZ(0);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
        }
        
        .card-3d:hover {
            transform: translateZ(20px) translateY(-5px);
            box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3);
            border-color: rgba(102, 126, 234, 0.4);
        }
        
        .card-header-3d {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.2), rgba(118, 75, 162, 0.2));
            border-bottom: 1px solid rgba(102, 126, 234, 0.2);
            padding: 20px;
        }
        
        .form-control-3d {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(102, 126, 234, 0.3);
            color: white;
            border-radius: 10px;
            padding: 12px 15px;
            transition: all 0.3s;
        }
        
        .form-control-3d:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
            color: white;
        }
        
        .form-control-3d::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        
        .form-label-3d {
            color: #ddd;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .btn-3d {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            transform-style: preserve-3d;
            transform: translateZ(0);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .btn-3d:hover {
            transform: translateZ(10px) translateY(-3px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-3d:active {
            transform: translateZ(5px) translateY(-1px);
        }
        
        .switch-3d {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }
        
        .switch-3d input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider-3d {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(102, 126, 234, 0.3);
            transition: .4s;
            border-radius: 34px;
        }
        
        .slider-3d:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 3px;
            background: rgba(255, 255, 255, 0.3);
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .slider-3d {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }
        
        input:checked + .slider-3d:before {
            transform: translateX(28px);
            background: white;
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: white;
            margin: 0 auto 20px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            transform-style: preserve-3d;
            transform: translateZ(30px);
        }
        
        .setting-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            margin-right: 15px;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        .activity-item {
            padding: 15px;
            border-bottom: 1px solid rgba(102, 126, 234, 0.2);
            transition: all 0.3s;
        }
        
        .activity-item:hover {
            background: rgba(102, 126, 234, 0.1);
            transform: translateX(5px);
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            background: rgba(102, 126, 234, 0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: var(--accent-color);
            margin-right: 15px;
        }
        
        .tab-3d {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(102, 126, 234, 0.2);
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
        }
        
        .tab-3d:hover {
            background: rgba(102, 126, 234, 0.2);
            transform: translateX(5px);
        }
        
        .tab-3d.active {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            transform: translateX(10px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .logo-3d {
            font-size: 24px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 2px;
            background: linear-gradient(135deg, #fff, var(--accent-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        
        .admin-welcome {
            font-size: 14px;
            color: #ddd;
            margin-right: 15px;
        }
        
        .admin-name {
            color: var(--accent-color);
            font-weight: 600;
        }
        
        .modal-3d .modal-content {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(102, 126, 234, 0.3);
            color: white;
        }
        
        .modal-3d .modal-header {
            border-bottom: 1px solid rgba(102, 126, 234, 0.3);
        }
        
        .modal-3d .btn-close {
            filter: invert(1);
        }
        
        .floating-element {
            animation: float 6s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px) translateZ(0); }
            50% { transform: translateY(-10px) translateZ(10px); }
        }
        
        .glow-text {
            text-shadow: 0 0 10px rgba(102, 126, 234, 0.5);
        }
        
        .settings-title {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            display: inline-block;
        }
        
        .settings-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 25%;
            width: 50%;
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--primary-color), transparent);
            border-radius: 2px;
        }
        
        .alert-3d {
            background: rgba(26, 26, 46, 0.9);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(102, 126, 234, 0.3);
            color: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .alert-3d.alert-danger {
            border-color: rgba(220, 53, 69, 0.5);
            background: rgba(220, 53, 69, 0.1);
        }
        
        .alert-3d.alert-success {
            border-color: rgba(40, 167, 69, 0.5);
            background: rgba(40, 167, 69, 0.1);
        }
        
        .password-strength {
            height: 5px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 3px;
            margin-top: 5px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, #dc3545, #ffc107, #28a745);
            border-radius: 3px;
            transition: width 0.3s;
        }
        
        .system-status {
            display: inline-flex;
            align-items: center;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .system-status.online {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
        }
        
        .system-status.offline {
            background: rgba(220, 53, 69, 0.2);
            color: #dc3545;
        }
        
        .backup-card {
            background: linear-gradient(135deg, rgba(26, 26, 46, 0.8), rgba(26, 26, 46, 0.6));
            border: 2px dashed rgba(102, 126, 234, 0.3);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .backup-card:hover {
            border-color: var(--primary-color);
            background: rgba(102, 126, 234, 0.1);
            transform: translateY(-5px);
        }
        
        .help-card {
            background: rgba(255, 193, 7, 0.1);
            border: 1px solid rgba(255, 193, 7, 0.3);
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar-3d {
                transform: none !important;
                margin-bottom: 20px;
            }
            
            .settings-title {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- 3D Background -->
    <div id="bg3d"></div>
    
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-3d">
        <div class="container-fluid">
            <a class="navbar-brand logo-3d" href="admin.php">
                <i class="fas fa-cube me-2"></i>SR<span style="color: var(--accent-color)">TRAVELS</span> 3D
            </a>
            <div class="d-flex align-items-center">
                <div class="admin-welcome">
                    <i class="fas fa-cog me-1"></i> Settings Panel
                </div>
                <div class="dropdown">
                    <button class="btn btn-3d dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown">
                        <i class="fas fa-user-shield me-2"></i><?php echo $_SESSION['admin_role']; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end modal-3d" style="min-width: 200px;">
                        <li><a class="dropdown-item" href="admin-profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid py-4">
        <div class="row">
            <!-- 3D Sidebar -->
            <div class="col-lg-3 col-xl-2 mb-4">
                <div class="sidebar-3d p-3 floating-element">
                    <div class="profile-avatar floating-element">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <h5 class="text-center mb-3"><?php echo $_SESSION['full_name']; ?></h5>
                    <p class="text-center text-muted mb-4">
                        <i class="fas fa-shield-alt me-1"></i>
                        <?php echo ucfirst($_SESSION['admin_role']); ?> Admin
                    </p>
                    
                    <nav class="nav flex-column">
                        <div class="tab-3d active" onclick="showTab('profile')">
                            <i class="fas fa-user-circle me-3"></i> Profile Settings
                        </div>
                        <div class="tab-3d" onclick="showTab('preferences')">
                            <i class="fas fa-sliders-h me-3"></i> Preferences
                        </div>
                        <div class="tab-3d" onclick="showTab('security')">
                            <i class="fas fa-shield-alt me-3"></i> Security
                        </div>
                        <?php if (is_super_admin()): ?>
                        <div class="tab-3d" onclick="showTab('system')">
                            <i class="fas fa-cogs me-3"></i> System Settings
                        </div>
                        <div class="tab-3d" onclick="showTab('backup')">
                            <i class="fas fa-database me-3"></i> Backup
                        </div>
                        <?php endif; ?>
                        <div class="tab-3d" onclick="showTab('logs')">
                            <i class="fas fa-history me-3"></i> Activity Logs
                        </div>
                        <div class="tab-3d" onclick="showTab('help')">
                            <i class="fas fa-question-circle me-3"></i> Help & Support
                        </div>
                    </nav>
                    
                    <div class="mt-4 pt-3 border-top border-secondary">
                        <div class="system-status online mb-2">
                            <i class="fas fa-circle me-2"></i> System Online
                        </div>
                        <small class="text-muted d-block">
                            <i class="fas fa-clock me-1"></i>
                            Last login: <?php echo date('M d, H:i'); ?>
                        </small>
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-lg-9 col-xl-10">
                <h1 class="settings-title glow-text">Admin Settings</h1>
                
                <?php if($error): ?>
                    <div class="alert-3d alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if($success): ?>
                    <div class="alert-3d alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Profile Settings Tab -->
                <div class="tab-content" id="profile">
                    <div class="card-3d mb-4">
                        <div class="card-header-3d">
                            <div class="d-flex align-items-center">
                                <div class="setting-icon">
                                    <i class="fas fa-user-edit"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0">Profile Settings</h4>
                                    <p class="text-muted mb-0">Update your personal information and password</p>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" id="profileForm">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Full Name</label>
                                        <input type="text" class="form-control form-control-3d" name="full_name" 
                                               value="<?php echo $admin_profile['full_name']; ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Email Address</label>
                                        <input type="email" class="form-control form-control-3d" name="email" 
                                               value="<?php echo $admin_profile['email']; ?>" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Phone Number</label>
                                        <input type="tel" class="form-control form-control-3d" name="phone" 
                                               value="<?php echo $admin_profile['phone'] ?? ''; ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Admin Role</label>
                                        <input type="text" class="form-control form-control-3d" 
                                               value="<?php echo ucfirst($admin_profile['admin_role']); ?>" readonly>
                                    </div>
                                </div>
                                
                                <hr class="my-4">
                                
                                <h5 class="mb-3">Change Password</h5>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label-3d">Current Password</label>
                                        <input type="password" class="form-control form-control-3d" name="current_password" id="currentPassword">
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label-3d">New Password</label>
                                        <input type="password" class="form-control form-control-3d" name="new_password" id="newPassword">
                                        <div class="password-strength">
                                            <div class="password-strength-bar" id="passwordStrength"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label-3d">Confirm New Password</label>
                                        <input type="password" class="form-control form-control-3d" name="confirm_password" id="confirmPassword">
                                        <small class="text-muted" id="passwordMatch"></small>
                                    </div>
                                </div>
                                
                                <div class="mt-4">
                                    <button type="submit" name="update_profile" class="btn btn-3d">
                                        <i class="fas fa-save me-2"></i> Save Changes
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Preferences Tab -->
                <div class="tab-content d-none" id="preferences">
                    <div class="card-3d mb-4">
                        <div class="card-header-3d">
                            <div class="d-flex align-items-center">
                                <div class="setting-icon">
                                    <i class="fas fa-palette"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0">Preferences</h4>
                                    <p class="text-muted mb-0">Customize your admin panel experience</p>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Theme</label>
                                        <select class="form-control form-control-3d" name="theme">
                                            <option value="dark" <?php echo ($preferences['theme'] ?? 'dark') == 'dark' ? 'selected' : ''; ?>>Dark Theme</option>
                                            <option value="light" <?php echo ($preferences['theme'] ?? '') == 'light' ? 'selected' : ''; ?>>Light Theme</option>
                                            <option value="auto" <?php echo ($preferences['theme'] ?? '') == 'auto' ? 'selected' : ''; ?>>Auto (System)</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Timezone</label>
                                        <select class="form-control form-control-3d" name="timezone">
                                            <option value="Asia/Kolkata" <?php echo ($preferences['timezone'] ?? 'Asia/Kolkata') == 'Asia/Kolkata' ? 'selected' : ''; ?>>India (IST)</option>
                                            <option value="UTC" <?php echo ($preferences['timezone'] ?? '') == 'UTC' ? 'selected' : ''; ?>>UTC</option>
                                            <option value="America/New_York" <?php echo ($preferences['timezone'] ?? '') == 'America/New_York' ? 'selected' : ''; ?>>New York (EST)</option>
                                            <option value="Europe/London" <?php echo ($preferences['timezone'] ?? '') == 'Europe/London' ? 'selected' : ''; ?>>London (GMT)</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center justify-content-between mb-3">
                                            <div>
                                                <label class="form-label-3d mb-0">Enable Notifications</label>
                                                <p class="text-muted small mb-0">Get notified about new bookings</p>
                                            </div>
                                            <label class="switch-3d">
                                                <input type="checkbox" name="notifications" <?php echo ($preferences['notifications'] ?? 1) ? 'checked' : ''; ?>>
                                                <span class="slider-3d"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center justify-content-between mb-3">
                                            <div>
                                                <label class="form-label-3d mb-0">Email Alerts</label>
                                                <p class="text-muted small mb-0">Receive email notifications</p>
                                            </div>
                                            <label class="switch-3d">
                                                <input type="checkbox" name="email_alerts" <?php echo ($preferences['email_alerts'] ?? 1) ? 'checked' : ''; ?>>
                                                <span class="slider-3d"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mt-4">
                                    <button type="submit" name="update_preferences" class="btn btn-3d">
                                        <i class="fas fa-save me-2"></i> Save Preferences
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Security Tab -->
                <div class="tab-content d-none" id="security">
                    <div class="card-3d mb-4">
                        <div class="card-header-3d">
                            <div class="d-flex align-items-center">
                                <div class="setting-icon">
                                    <i class="fas fa-shield-alt"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0">Security Settings</h4>
                                    <p class="text-muted mb-0">Manage your account security</p>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="row">
                                    <div class="col-md-6 mb-4">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <h6>Two-Factor Authentication</h6>
                                                <p class="text-muted small mb-0">Add an extra layer of security</p>
                                            </div>
                                            <label class="switch-3d">
                                                <input type="checkbox" name="two_factor" <?php echo ($security['two_factor'] ?? 0) ? 'checked' : ''; ?>>
                                                <span class="slider-3d"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-4">
                                        <label class="form-label-3d">Session Timeout</label>
                                        <select class="form-control form-control-3d" name="session_timeout">
                                            <option value="15" <?php echo ($security['session_timeout'] ?? 30) == 15 ? 'selected' : ''; ?>>15 minutes</option>
                                            <option value="30" <?php echo ($security['session_timeout'] ?? 30) == 30 ? 'selected' : ''; ?>>30 minutes</option>
                                            <option value="60" <?php echo ($security['session_timeout'] ?? 30) == 60 ? 'selected' : ''; ?>>1 hour</option>
                                            <option value="120" <?php echo ($security['session_timeout'] ?? 30) == 120 ? 'selected' : ''; ?>>2 hours</option>
                                            <option value="480" <?php echo ($security['session_timeout'] ?? 30) == 480 ? 'selected' : ''; ?>>8 hours</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <h6>Login Notifications</h6>
                                                <p class="text-muted small mb-0">Get notified for new logins</p>
                                            </div>
                                            <label class="switch-3d">
                                                <input type="checkbox" name="login_notifications" <?php echo ($security['login_notifications'] ?? 1) ? 'checked' : ''; ?>>
                                                <span class="slider-3d"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <h6>Show Last Login</h6>
                                                <p class="text-muted small mb-0">Display last login info</p>
                                            </div>
                                            <label class="switch-3d">
                                                <input type="checkbox" checked disabled>
                                                <span class="slider-3d"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="alert-3d alert-warning mt-4">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Security Tip:</strong> Always use strong passwords and enable two-factor authentication for maximum security.
                                </div>
                                
                                <div class="mt-4">
                                    <button type="submit" name="update_security" class="btn btn-3d">
                                        <i class="fas fa-save me-2"></i> Update Security Settings
                                    </button>
                                    <button type="button" class="btn btn-3d btn-outline ms-2" onclick="showSessions()">
                                        <i class="fas fa-list me-2"></i> View Active Sessions
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- System Settings Tab (Super Admin Only) -->
                <?php if (is_super_admin()): ?>
                <div class="tab-content d-none" id="system">
                    <div class="card-3d mb-4">
                        <div class="card-header-3d">
                            <div class="d-flex align-items-center">
                                <div class="setting-icon">
                                    <i class="fas fa-cogs"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0">System Settings</h4>
                                    <p class="text-muted mb-0">Manage system-wide configurations</p>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Site Name</label>
                                        <input type="text" class="form-control form-control-3d" name="site_name" 
                                               value="<?php echo $system_settings['site_name'] ?? 'SR Travels'; ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Site Email</label>
                                        <input type="email" class="form-control form-control-3d" name="site_email" 
                                               value="<?php echo $system_settings['site_email'] ?? 'admin@srtravels.com'; ?>" required>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Booking Cut-off Time (minutes)</label>
                                        <input type="number" class="form-control form-control-3d" name="booking_cutoff" 
                                               value="<?php echo $system_settings['booking_cutoff'] ?? 30; ?>" min="5" max="1440">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label-3d">Currency</label>
                                        <select class="form-control form-control-3d" name="currency">
                                            <option value="INR" <?php echo ($system_settings['currency'] ?? 'INR') == 'INR' ? 'selected' : ''; ?>>Indian Rupee (₹)</option>
                                            <option value="USD" <?php echo ($system_settings['currency'] ?? '') == 'USD' ? 'selected' : ''; ?>>US Dollar ($)</option>
                                            <option value="EUR" <?php echo ($system_settings['currency'] ?? '') == 'EUR' ? 'selected' : ''; ?>>Euro (€)</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <h6>Maintenance Mode</h6>
                                                <p class="text-muted small mb-0">Take site offline for maintenance</p>
                                            </div>
                                            <label class="switch-3d">
                                                <input type="checkbox" name="maintenance_mode" <?php echo ($system_settings['maintenance_mode'] ?? 0) ? 'checked' : ''; ?>>
                                                <span class="slider-3d"></span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <h6>Allow Registrations</h6>
                                                <p class="text-muted small mb-0">Allow new user registrations</p>
                                            </div>
                                            <label class="switch-3d">
                                                <input type="checkbox" checked disabled>
                                                <span class="slider-3d"></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="alert-3d alert-danger mt-4">
                                    <i class="fas fa-exclamation-circle me-2"></i>
                                    <strong>Warning:</strong> These settings affect the entire system. Changes may impact all users.
                                </div>
                                
                                <div class="mt-4">
                                    <button type="submit" name="update_system" class="btn btn-3d">
                                        <i class="fas fa-save me-2"></i> Save System Settings
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Backup Tab -->
                <div class="tab-content d-none" id="backup">
                    <div class="card-3d mb-4">
                        <div class="card-header-3d">
                            <div class="d-flex align-items-center">
                                <div class="setting-icon">
                                    <i class="fas fa-database"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0">Database Backup</h4>
                                    <p class="text-muted mb-0">Backup and restore your database</p>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <div class="backup-card" onclick="createBackup()">
                                        <i class="fas fa-plus-circle fa-3x mb-3" style="color: var(--primary-color);"></i>
                                        <h5>Create Backup</h5>
                                        <p class="text-muted">Create a new database backup</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="backup-card" onclick="restoreBackup()">
                                        <i class="fas fa-undo fa-3x mb-3" style="color: var(--accent-color);"></i>
                                        <h5>Restore Backup</h5>
                                        <p class="text-muted">Restore from a previous backup</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <h5>Recent Backups</h5>
                                <div class="table-responsive">
                                    <table class="table table-dark table-hover">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Size</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><?php echo date('Y-m-d H:i:s'); ?></td>
                                                <td>2.4 MB</td>
                                                <td><span class="badge bg-success">Complete</span></td>
                                                <td>
                                                    <button class="btn btn-sm btn-3d" onclick="downloadBackup()">
                                                        <i class="fas fa-download"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><?php echo date('Y-m-d H:i:s', strtotime('-1 day')); ?></td>
                                                <td>2.3 MB</td>
                                                <td><span class="badge bg-success">Complete</span></td>
                                                <td>
                                                    <button class="btn btn-sm btn-3d" onclick="downloadBackup()">
                                                        <i class="fas fa-download"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Activity Logs Tab -->
                <div class="tab-content d-none" id="logs">
                    <div class="card-3d mb-4">
                        <div class="card-header-3d">
                            <div class="d-flex align-items-center">
                                <div class="setting-icon">
                                    <i class="fas fa-history"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0">Activity Logs</h4>
                                    <p class="text-muted mb-0">View your recent activities</p>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <div class="input-group">
                                    <input type="text" class="form-control form-control-3d" placeholder="Search activities...">
                                    <button class="btn btn-3d">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="activity-list">
                                <?php if (mysqli_num_rows($activities_result) > 0): ?>
                                    <?php while ($activity = mysqli_fetch_assoc($activities_result)): ?>
                                    <div class="activity-item">
                                        <div class="d-flex align-items-center">
                                            <div class="activity-icon">
                                                <i class="fas fa-user-cog"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?php echo $activity['activity']; ?></h6>
                                                <div class="d-flex justify-content-between">
                                                    <small class="text-muted">
                                                        <i class="fas fa-clock me-1"></i>
                                                        <?php echo format_date($activity['created_at']) . ' ' . format_time($activity['created_at']); ?>
                                                    </small>
                                                    <small class="text-muted">
                                                        <i class="fas fa-globe me-1"></i>
                                                        <?php echo $activity['ip_address']; ?>
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <div class="text-center py-5">
                                        <i class="fas fa-history fa-3x mb-3 text-muted"></i>
                                        <h5>No activities found</h5>
                                        <p class="text-muted">Your activities will appear here</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mt-4 text-center">
                                <button class="btn btn-3d" onclick="loadMoreActivities()">
                                    <i class="fas fa-sync me-2"></i> Load More
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Help Tab -->
                <div class="tab-content d-none" id="help">
                    <div class="card-3d mb-4">
                        <div class="card-header-3d">
                            <div class="d-flex align-items-center">
                                <div class="setting-icon">
                                    <i class="fas fa-question-circle"></i>
                                </div>
                                <div>
                                    <h4 class="mb-0">Help & Support</h4>
                                    <p class="text-muted mb-0">Get help and support resources</p>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <div class="card-3d h-100">
                                        <div class="card-body text-center">
                                            <i class="fas fa-book fa-3x mb-3" style="color: var(--primary-color);"></i>
                                            <h5>Documentation</h5>
                                            <p class="text-muted">Read our comprehensive guides</p>
                                            <button class="btn btn-3d" onclick="openDocumentation()">
                                                <i class="fas fa-external-link-alt me-2"></i> View Docs
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="card-3d h-100">
                                        <div class="card-body text-center">
                                            <i class="fas fa-headset fa-3x mb-3" style="color: var(--accent-color);"></i>
                                            <h5>Contact Support</h5>
                                            <p class="text-muted">Get help from our support team</p>
                                            <button class="btn btn-3d" onclick="contactSupport()">
                                                <i class="fas fa-envelope me-2"></i> Contact
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="help-card">
                                <h5><i class="fas fa-lightbulb me-2"></i> Quick Tips</h5>
                                <ul class="mb-0">
                                    <li>Use strong passwords and enable two-factor authentication</li>
                                    <li>Regularly backup your database</li>
                                    <li>Keep your admin panel updated</li>
                                    <li>Review activity logs regularly</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 3D Background Script -->
    <script>
        // Create 3D scene
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.getElementById('bg3d').appendChild(renderer.domElement);

        // Create floating spheres
        const geometry = new THREE.SphereGeometry(0.5, 32, 32);
        const material = new THREE.MeshBasicMaterial({ 
            color: 0x667eea,
            wireframe: true,
            transparent: true,
            opacity: 0.1
        });
        
        const spheres = [];
        for (let i = 0; i < 10; i++) {
            const sphere = new THREE.Mesh(geometry, material);
            sphere.position.x = Math.random() * 30 - 15;
            sphere.position.y = Math.random() * 30 - 15;
            sphere.position.z = Math.random() * 30 - 15;
            sphere.rotationSpeed = Math.random() * 0.01;
            spheres.push(sphere);
            scene.add(sphere);
        }

        camera.position.z = 5;

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            
            spheres.forEach(sphere => {
                sphere.rotation.x += sphere.rotationSpeed;
                sphere.rotation.y += sphere.rotationSpeed;
                
                // Slow floating movement
                sphere.position.y += Math.sin(Date.now() * 0.001 + sphere.position.x) * 0.005;
            });
            
            renderer.render(scene, camera);
        }
        animate();

        // Handle window resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        // Tab switching
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.add('d-none');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab-3d').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabName).classList.remove('d-none');
            
            // Set active tab in sidebar
            event.currentTarget.classList.add('active');
            
            // Scroll to top
            window.scrollTo({ top: 300, behavior: 'smooth' });
        }

        // Password strength checker
        document.getElementById('newPassword').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('passwordStrength');
            let strength = 0;
            
            if (password.length >= 8) strength += 25;
            if (/[A-Z]/.test(password)) strength += 25;
            if (/[0-9]/.test(password)) strength += 25;
            if (/[^A-Za-z0-9]/.test(password)) strength += 25;
            
            strengthBar.style.width = strength + '%';
            
            if (strength < 50) {
                strengthBar.style.background = '#dc3545';
            } else if (strength < 75) {
                strengthBar.style.background = '#ffc107';
            } else {
                strengthBar.style.background = '#28a745';
            }
        });

        // Password match checker
        document.getElementById('confirmPassword').addEventListener('input', function() {
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = this.value;
            const matchText = document.getElementById('passwordMatch');
            
            if (confirmPassword === '') {
                matchText.textContent = '';
                matchText.style.color = '';
            } else if (newPassword === confirmPassword) {
                matchText.textContent = '✓ Passwords match';
                matchText.style.color = '#28a745';
            } else {
                matchText.textContent = '✗ Passwords do not match';
                matchText.style.color = '#dc3545';
            }
        });

        // Backup functions
        function createBackup() {
            if (confirm('Create a new database backup? This may take a few moments.')) {
                // Simulate backup process
                const btn = event.target.closest('.backup-card');
                btn.innerHTML = '<div class="loading"></div>';
                
                setTimeout(() => {
                    alert('Backup created successfully!');
                    location.reload();
                }, 2000);
            }
        }

        function restoreBackup() {
            alert('Restore functionality would be implemented here.');
        }

        function downloadBackup() {
            alert('Download functionality would be implemented here.');
        }

        function showSessions() {
            alert('Active sessions would be displayed here.');
        }

        function openDocumentation() {
            window.open('https://docs.srtravels.com', '_blank');
        }

        function contactSupport() {
            window.location.href = 'mailto:support@srtravels.com';
        }

        function loadMoreActivities() {
            alert('Loading more activities...');
        }

        // Initialize form validation
        document.getElementById('profileForm').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (newPassword && newPassword !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return false;
            }
            
            if (newPassword && newPassword.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters!');
                return false;
            }
            
            return true;
        });

        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>