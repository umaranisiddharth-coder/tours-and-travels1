<?php
require_once 'config.php';

if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user bookings
$bookings_query = "SELECT b.*, r.from_city, r.to_city, r.departure_time, r.arrival_time, 
                          bus.bus_name, bus.bus_type 
                   FROM bookings b 
                   JOIN bus_routes r ON b.route_id = r.id 
                   JOIN buses bus ON b.bus_id = bus.id 
                   WHERE b.user_id = $user_id 
                   ORDER BY b.booking_date DESC";
$bookings_result = mysqli_query($conn, $bookings_query);

// Get upcoming trips
$upcoming_query = "SELECT b.*, r.from_city, r.to_city, r.departure_time, bus.bus_name 
                   FROM bookings b 
                   JOIN bus_routes r ON b.route_id = r.id 
                   JOIN buses bus ON b.bus_id = bus.id 
                   WHERE b.user_id = $user_id 
                   AND b.travel_date >= CURDATE() 
                   AND b.booking_status = 'confirmed' 
                   ORDER BY b.travel_date ASC 
                   LIMIT 3";
$upcoming_result = mysqli_query($conn, $upcoming_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3D User Dashboard - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/three@0.132.2/build/three.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #f1f5f9;
        }

        /* 3D Card Styling */
        .card-3d {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            transform-style: preserve-3d;
            transform: perspective(1000px) rotateX(0deg) rotateY(0deg);
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        }

        .card-3d:hover {
            transform: perspective(1000px) rotateX(5deg) rotateY(5deg) translateY(-10px);
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.3);
        }

        /* Floating Animation */
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .float-animation {
            animation: float 6s ease-in-out infinite;
        }

        /* 3D Sidebar */
        .sidebar-3d {
            background: rgba(15, 23, 42, 0.8);
            border-radius: 20px;
            padding: 30px;
            transform: perspective(800px) rotateY(-5deg);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: -20px 0 40px rgba(0, 0, 0, 0.2);
        }

        /* 3D Button */
        .btn-3d {
            position: relative;
            border: none;
            border-radius: 12px;
            padding: 12px 24px;
            margin: 8px;
            transform: perspective(500px) translateZ(0);
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .btn-3d:hover {
            transform: perspective(500px) translateZ(20px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
        }

        /* 3D Table */
        .table-3d {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            overflow: hidden;
        }

        .table-3d th, .table-3d td {
            border-color: rgba(255, 255, 255, 0.1);
            padding: 15px;
        }

        /* 3D Navigation */
        .navbar-3d {
            background: rgba(15, 23, 42, 0.9) !important;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Three.js Canvas */
        #threejs-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }
    </style>
</head>
<body>
    <!-- Three.js Background Canvas -->
    <canvas id="threejs-canvas"></canvas>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light navbar-3d">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="index.php">
                <i class="fas fa-bus me-2"></i>SR<span class="text-warning">TRAVELS</span>
            </a>
            <div class="d-flex align-items-center">
                <div class="me-3 text-light">
                    <i class="fas fa-user-circle me-2"></i>
                    <?php echo $_SESSION['full_name']; ?>
                </div>
                <a href="logout.php" class="btn-3d btn btn-outline-light">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row">
            <!-- 3D Sidebar -->
            <div class="col-lg-3 mb-4">
                <div class="sidebar-3d float-animation">
                    <div class="text-center mb-4">
                        <div class="mb-3">
                            <i class="fas fa-user-circle fa-5x text-primary"></i>
                        </div>
                        <h4 class="fw-bold"><?php echo $_SESSION['full_name']; ?></h4>
                        <p class="text-muted">@<?php echo $_SESSION['username']; ?></p>
                        <hr class="bg-light">
                    </div>
                    <div class="d-grid gap-3">
                        <a href="user.php" class="btn-3d btn btn-primary">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a href="booking.php" class="btn-3d btn btn-outline-light">
                            <i class="fas fa-plus-circle me-2"></i>Book New Trip
                        </a>
                        <a href="bus-tracking.php" class="btn-3d btn btn-outline-light">
                            <i class="fas fa-map-marker-alt me-2"></i>Track Bus
                        </a>
                        <a href="user-profile.php" class="btn-3d btn btn-outline-light">
                            <i class="fas fa-user-edit me-2"></i>Edit Profile
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Main 3D Content -->
            <div class="col-lg-9">
                <!-- Welcome Card -->
                <div class="card-3d mb-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="fw-bold">Welcome back, <?php echo explode(' ', $_SESSION['full_name'])[0]; ?>! 👋</h3>
                            <p class="text-muted">Manage your trips, track buses, and explore new destinations.</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <i class="fas fa-bus fa-4x text-warning"></i>
                        </div>
                    </div>
                </div>

                <!-- Upcoming Trips -->
                <div class="card-3d mb-4">
                    <h4 class="card-title fw-bold mb-4">
                        <i class="fas fa-route me-2"></i>Upcoming Trips
                    </h4>
                    <?php if(mysqli_num_rows($upcoming_result) > 0): ?>
                        <div class="row">
                            <?php while($trip = mysqli_fetch_assoc($upcoming_result)): ?>
                            <div class="col-md-4 mb-3">
                                <div class="card-3d h-100">
                                    <div class="card-body">
                                        <h6 class="fw-bold"><?php echo $trip['from_city']; ?> → <?php echo $trip['to_city']; ?></h6>
                                        <p class="mb-1">
                                            <i class="far fa-calendar me-1"></i>
                                            <?php echo format_date($trip['travel_date']); ?>
                                        </p>
                                        <p class="mb-1">
                                            <i class="far fa-clock me-1"></i>
                                            <?php echo format_time($trip['departure_time']); ?>
                                        </p>
                                        <p class="mb-3">
                                            <i class="fas fa-bus me-1"></i>
                                            <?php echo $trip['bus_name']; ?>
                                        </p>
                                        <span class="badge bg-success px-3 py-2 rounded-pill">Confirmed</span>
                                        <a href="booking-details.php?id=<?php echo $trip['id']; ?>" 
                                           class="btn-3d btn btn-sm btn-outline-primary mt-3 w-100">
                                            View Details
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">
                            No upcoming trips. 
                            <a href="booking.php" class="text-warning text-decoration-none">
                                Book a new trip! <i class="fas fa-arrow-right"></i>
                            </a>
                        </p>
                    <?php endif; ?>
                </div>
                
                <!-- Booking History -->
                <div class="card-3d">
                    <h4 class="card-title fw-bold mb-4">
                        <i class="fas fa-history me-2"></i>Booking History
                    </h4>
                    <div class="table-responsive">
                        <table class="table table-dark table-3d">
                            <thead>
                                <tr>
                                    <th>Booking ID</th>
                                    <th>Route</th>
                                    <th>Date</th>
                                    <th>Seats</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($booking = mysqli_fetch_assoc($bookings_result)): ?>
                                <tr>
                                    <td class="fw-bold">#<?php echo $booking['booking_id']; ?></td>
                                    <td>
                                        <i class="fas fa-route me-1"></i>
                                        <?php echo $booking['from_city']; ?> → <?php echo $booking['to_city']; ?>
                                    </td>
                                    <td><?php echo format_date($booking['travel_date']); ?></td>
                                    <td>
                                        <span class="badge bg-info"><?php echo $booking['seats_booked']; ?> seats</span>
                                    </td>
                                    <td class="fw-bold text-warning">₹<?php echo $booking['total_amount']; ?></td>
                                    <td>
                                        <span class="badge px-3 py-2 bg-<?php 
                                            echo $booking['booking_status'] == 'confirmed' ? 'success' : 
                                                 ($booking['booking_status'] == 'pending' ? 'warning' : 'danger'); 
                                        ?>">
                                            <?php echo ucfirst($booking['booking_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="booking-details.php?id=<?php echo $booking['id']; ?>" 
                                           class="btn-3d btn btn-sm btn-outline-light">View</a>
                                        <?php if($booking['booking_status'] == 'pending'): ?>
                                            <a href="payment.php?booking_id=<?php echo $booking['id']; ?>" 
                                               class="btn-3d btn btn-sm btn-warning mt-1">Pay Now</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Three.js 3D Background -->
    <script>
        // Setup Three.js scene
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({
            canvas: document.getElementById('threejs-canvas'),
            alpha: true,
            antialias: true
        });

        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(window.devicePixelRatio);

        // Add 3D objects (floating spheres)
        const geometry = new THREE.SphereGeometry(1, 32, 32);
        const material = new THREE.MeshPhongMaterial({
            color: 0x3b82f6,
            shininess: 100,
            transparent: true,
            opacity: 0.1
        });

        const spheres = [];
        for (let i = 0; i < 20; i++) {
            const sphere = new THREE.Mesh(geometry, material);
            sphere.position.set(
                Math.random() * 40 - 20,
                Math.random() * 40 - 20,
                Math.random() * 100 - 50
            );
            sphere.scale.setScalar(Math.random() * 3 + 1);
            scene.add(sphere);
            spheres.push(sphere);
        }

        // Add lights
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(1, 1, 1);
        scene.add(directionalLight);

        camera.position.z = 30;

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            
            spheres.forEach((sphere, i) => {
                sphere.rotation.x += 0.01;
                sphere.rotation.y += 0.01;
                sphere.position.y += Math.sin(Date.now() * 0.001 + i) * 0.02;
            });

            renderer.render(scene, camera);
        }

        animate();

        // Handle window resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        // 3D Card Hover Effect
        document.querySelectorAll('.card-3d').forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                const centerX = rect.width / 2;
                const centerY = rect.height / 2;

                const rotateY = ((x - centerX) / centerX) * 5;
                const rotateX = ((centerY - y) / centerY) * 5;

                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-10px)`;
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)';
            });
        });
    </script>
</body>
</html>