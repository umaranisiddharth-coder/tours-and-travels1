[file name]: phonepay-callback.php
[file content begin]
<?php
require_once 'config.php';
require_once 'paytm-config.php';

// Get callback data
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE);

// Log callback for debugging
log_payment_debug('PhonePe Callback Received', $input);

if ($input && isset($input['success']) && $input['success']) {
    $merchantTransactionId = $input['data']['merchantTransactionId'];
    $transactionId = $input['data']['transactionId'];
    $amount = $input['data']['amount'] / 100; // Convert from paise to rupees
    $paymentMethod = $input['data']['paymentInstrument']['type'] ?? 'PHONEPE';
    $paymentStatus = $input['data']['state'];
    
    // Get pending booking
    $pending_query = "SELECT * FROM pending_bookings WHERE order_id = '$merchantTransactionId'";
    $pending_result = mysqli_query($conn, $pending_query);
    $pending_booking = mysqli_fetch_assoc($pending_result);
    
    if ($pending_booking && $paymentStatus == 'COMPLETED') {
        // Start transaction
        mysqli_begin_transaction($conn);
        
        try {
            // Generate final booking ID
            $booking_id = generate_booking_id();
            
            // Create final booking
            $booking_query = "INSERT INTO bookings (booking_id, user_id, bus_id, route_id, travel_date, 
                            seats_booked, total_seats, total_amount, payment_method, booking_status, payment_status) 
                            VALUES ('$booking_id', {$pending_booking['user_id']}, 
                            (SELECT bus_id FROM bus_routes WHERE id = {$pending_booking['route_id']}), 
                            {$pending_booking['route_id']}, '{$pending_booking['travel_date']}', 
                            '{$pending_booking['seats']}', " . count(explode(',', $pending_booking['seats'])) . ", 
                            $amount, '$paymentMethod', 'confirmed', 'paid')";
            
            if (mysqli_query($conn, $booking_query)) {
                $booking_insert_id = mysqli_insert_id($conn);
                
                // Mark seats as booked
                $seats = explode(',', $pending_booking['seats']);
                foreach($seats as $seat) {
                    $seat_type = strpos($seat, 'U') === 0 ? 'sleeper_upper' : 
                                (strpos($seat, 'L') === 0 ? 'sleeper_lower' : 'seater');
                    
                    $seat_query = "INSERT INTO seat_availability (bus_id, travel_date, seat_number, seat_type, is_available, booking_id) 
                                  VALUES ((SELECT bus_id FROM bus_routes WHERE id = {$pending_booking['route_id']}), 
                                  '{$pending_booking['travel_date']}', '$seat', '$seat_type', FALSE, $booking_insert_id) 
                                  ON DUPLICATE KEY UPDATE is_available = FALSE, booking_id = $booking_insert_id";
                    mysqli_query($conn, $seat_query);
                }
                
                // Create payment record
                $payment_query = "INSERT INTO payments (booking_id, payment_id, transaction_id, amount, 
                                 payment_method, payment_status, payment_date) 
                                 VALUES ($booking_insert_id, '$merchantTransactionId', '$transactionId', $amount, 
                                 '$paymentMethod', 'completed', NOW())";
                mysqli_query($conn, $payment_query);
                
                // Update pending booking status
                $update_pending = "UPDATE pending_bookings SET status = 'completed' WHERE order_id = '$merchantTransactionId'";
                mysqli_query($conn, $update_pending);
                
                // Commit transaction
                mysqli_commit($conn);
                
                // Store success data in session
                session_start();
                $_SESSION['payment_success'] = true;
                $_SESSION['last_booking_id'] = $booking_insert_id;
                $_SESSION['transaction_id'] = $transactionId;
                
                // Clear payment session
                unset($_SESSION['paytm_order_id']);
                unset($_SESSION['paytm_amount']);
                unset($_SESSION['payment_method']);
                
                // Send success response to PhonePe
                $response = [
                    'success' => true,
                    'code' => 'PAYMENT_SUCCESS',
                    'message' => 'Your payment is successful'
                ];
                
                http_response_code(200);
                header('Content-Type: application/json');
                echo json_encode($response);
                
            } else {
                throw new Exception("Booking creation failed");
            }
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            
            // Send failure response to PhonePe
            $response = [
                'success' => false,
                'code' => 'PAYMENT_ERROR',
                'message' => 'Payment failed'
            ];
            
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode($response);
            
            // Log error
            error_log("PhonePe Payment Error: " . $e->getMessage());
        }
    } else {
        // Payment failed or pending
        $response = [
            'success' => false,
            'code' => 'PAYMENT_' . $paymentStatus,
            'message' => 'Payment ' . strtolower($paymentStatus)
        ];
        
        http_response_code(400);
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // Invalid callback
    $response = [
        'success' => false,
        'code' => 'INVALID_CALLBACK',
        'message' => 'Invalid callback data'
    ];
    
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode($response);
}

// Log response for debugging
log_payment_debug('PhonePe Callback Response', $response ?? []);
?>
[file content end]