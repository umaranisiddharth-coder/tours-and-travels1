<?php
require_once 'config.php';

// Page configuration
$page_title = 'Login to Your Account';
$page_description = 'Access your SR Travels account to manage bookings and profile';

// Redirect if already logged in
if (is_logged_in()) {
    if (is_admin()) {
        header("Location: admin-dashboard-enhanced.php");
    } else {
        header("Location: user-dashboard-enhanced.php");
    }
    exit();
}

$error = '';
$success = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    $remember_me = isset($_POST['remember_me']);
    
    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        // Check user credentials
        $user = get_user_by_email($email);
        
        if ($user && password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['email'] = $user['email'];
            
            // Update last login
            $update_login = "UPDATE users SET last_login = NOW(), login_count = login_count + 1 WHERE id = " . $user['id'];
            mysqli_query($conn, $update_login);
            
            // Set remember me cookie if requested
            if ($remember_me) {
                $token = generate_token();
                setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/'); // 30 days
            }
            
            // Redirect based on user type
            if ($user['user_type'] == 'admin') {
                header("Location: admin-dashboard-enhanced.php");
            } else {
                header("Location: user-dashboard-enhanced.php");
            }
            exit();
        } else {
            $error = 'Invalid email or password.';
        }
    }
}

// Custom CSS for RedBus-inspired design
$custom_css = "
    body {
        background: linear-gradient(135deg, #d32f2f 0%, #f44336 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .login-wrapper {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    .login-container {
        background: white;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        overflow: hidden;
        max-width: 900px;
        width: 100%;
        display: grid;
        grid-template-columns: 1fr 1fr;
        min-height: 500px;
    }
    
    .login-left {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        color: white;
        padding: 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }
    
    .login-left::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><circle cx=\"20\" cy=\"20\" r=\"2\" fill=\"rgba(255,255,255,0.1)\"/><circle cx=\"80\" cy=\"80\" r=\"3\" fill=\"rgba(255,255,255,0.1)\"/><circle cx=\"40\" cy=\"60\" r=\"1\" fill=\"rgba(255,255,255,0.1)\"/></svg>');
        background-size: 100px 100px;
    }
    
    .login-brand {
        position: relative;
        z-index: 2;
    }
    
    .brand-logo {
        font-size: 3rem;
        font-weight: 800;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .brand-logo i {
        background: rgba(255,255,255,0.2);
        padding: 15px;
        border-radius: 15px;
        font-size: 2rem;
    }
    
    .brand-tagline {
        font-size: 1.2rem;
        opacity: 0.9;
        margin-bottom: 30px;
        line-height: 1.6;
    }
    
    .features-list {
        list-style: none;
        padding: 0;
    }
    
    .features-list li {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
        font-size: 1rem;
        opacity: 0.9;
    }
    
    .features-list i {
        margin-right: 12px;
        width: 20px;
        color: #ffeb3b;
    }
    
    .login-right {
        padding: 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
    
    .login-header {
        text-align: center;
        margin-bottom: 30px;
    }
    
    .login-title {
        font-size: 2rem;
        font-weight: 700;
        color: #333;
        margin-bottom: 10px;
    }
    
    .login-subtitle {
        color: #666;
        font-size: 1rem;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #333;
        font-size: 0.9rem;
    }
    
    .form-control {
        width: 100%;
        padding: 15px;
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #fafafa;
    }
    
    .form-control:focus {
        outline: none;
        border-color: #d32f2f;
        background: white;
        box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.1);
    }
    
    .form-check {
        display: flex;
        align-items: center;
        margin-bottom: 25px;
    }
    
    .form-check-input {
        margin-right: 10px;
        transform: scale(1.2);
    }
    
    .form-check-label {
        color: #666;
        font-size: 0.9rem;
    }
    
    .btn-login {
        width: 100%;
        padding: 15px;
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        color: white;
        border: none;
        border-radius: 10px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-bottom: 20px;
    }
    
    .btn-login:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(211, 47, 47, 0.3);
    }
    
    .btn-login:active {
        transform: translateY(0);
    }
    
    .divider {
        text-align: center;
        margin: 25px 0;
        position: relative;
    }
    
    .divider::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 0;
        right: 0;
        height: 1px;
        background: #e0e0e0;
    }
    
    .divider span {
        background: white;
        padding: 0 20px;
        color: #999;
        font-size: 0.9rem;
    }
    
    .forgot-password {
        text-align: center;
        margin-bottom: 20px;
    }
    
    .forgot-password a {
        color: #d32f2f;
        text-decoration: none;
        font-weight: 500;
        font-size: 0.9rem;
    }
    
    .forgot-password a:hover {
        text-decoration: underline;
    }
    
    .register-link {
        text-align: center;
        padding-top: 20px;
        border-top: 1px solid #e0e0e0;
    }
    
    .register-link a {
        color: #d32f2f;
        text-decoration: none;
        font-weight: 600;
    }
    
    .register-link a:hover {
        text-decoration: underline;
    }
    
    .alert {
        padding: 12px 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-size: 0.9rem;
    }
    
    .alert-danger {
        background: #ffebee;
        color: #c62828;
        border: 1px solid #ffcdd2;
    }
    
    .alert-success {
        background: #e8f5e8;
        color: #2e7d32;
        border: 1px solid #c8e6c9;
    }
    
    @media (max-width: 768px) {
        .login-container {
            grid-template-columns: 1fr;
            margin: 10px;
        }
        
        .login-left {
            padding: 30px 20px;
            text-align: center;
        }
        
        .login-right {
            padding: 30px 20px;
        }
        
        .brand-logo {
            font-size: 2.5rem;
            justify-content: center;
        }
        
        .login-title {
            font-size: 1.8rem;
        }
    }
";

// Don't show page header for login
$show_page_header = false;

// Include header
include 'includes/header.php';
?>

<div class="login-wrapper">
    <div class="login-container" data-aos="fade-up">
        <!-- Left Side - Branding -->
        <div class="login-left">
            <div class="login-brand">
                <div class="brand-logo">
                    <i class="fas fa-bus"></i>
                    <span>SR TRAVELS</span>
                </div>
                <div class="brand-tagline">
                    India's most trusted bus booking platform with safe, comfortable, and affordable travel.
                </div>
                <ul class="features-list">
                    <li><i class="fas fa-check-circle"></i> 50,000+ Happy Customers</li>
                    <li><i class="fas fa-check-circle"></i> 500+ Routes Across India</li>
                    <li><i class="fas fa-check-circle"></i> 24/7 Customer Support</li>
                    <li><i class="fas fa-check-circle"></i> Secure Payment Gateway</li>
                    <li><i class="fas fa-check-circle"></i> Real-time Bus Tracking</li>
                </ul>
            </div>
        </div>
        
        <!-- Right Side - Login Form -->
        <div class="login-right">
            <div class="login-header">
                <h1 class="login-title">Welcome Back!</h1>
                <p class="login-subtitle">Sign in to your account to continue</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label" for="email">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="Enter your email address" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" 
                           placeholder="Enter your password" required>
                </div>
                
                <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="remember_me" name="remember_me">
                    <label class="form-check-label" for="remember_me">
                        Keep me signed in for 30 days
                    </label>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt me-2"></i>Sign In to Account
                </button>
            </form>
            
            <div class="forgot-password">
                <a href="forgot-password.php">
                    <i class="fas fa-key me-1"></i>Forgot your password?
                </a>
            </div>
            
            <div class="divider">
                <span>New to SR Travels?</span>
            </div>
            
            <div class="register-link">
                <p>Don't have an account? 
                    <a href="register.php">Create Account - It's Free!</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>