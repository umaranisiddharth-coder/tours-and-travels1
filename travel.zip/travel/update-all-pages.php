<?php
// Script to update all pages with consistent header and footer
echo "<h1>SR Travels - Page Update Script</h1>";

// List of pages to update
$pages_to_update = [
    'enhanced-booking-system.php' => [
        'title' => 'Search & Book Buses',
        'description' => 'Find and book the perfect bus for your journey with real-time availability',
        'breadcrumbs' => [
            ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
            ['title' => 'Book Bus', 'icon' => 'fas fa-search']
        ]
    ],
    'seat-selection.php' => [
        'title' => 'Select Your Seats',
        'description' => 'Choose your preferred seats from our interactive seat map',
        'breadcrumbs' => [
            ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
            ['title' => 'Book Bus', 'url' => 'enhanced-booking-system.php', 'icon' => 'fas fa-search'],
            ['title' => 'Select Seats', 'icon' => 'fas fa-chair']
        ]
    ],
    'payment.php' => [
        'title' => 'Secure Payment',
        'description' => 'Complete your booking with our secure payment gateway',
        'breadcrumbs' => [
            ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
            ['title' => 'Book Bus', 'url' => 'enhanced-booking-system.php', 'icon' => 'fas fa-search'],
            ['title' => 'Payment', 'icon' => 'fas fa-credit-card']
        ]
    ],
    'user-dashboard-enhanced.php' => [
        'title' => 'My Dashboard',
        'description' => 'Manage your bookings, profile, and travel history',
        'breadcrumbs' => [
            ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
            ['title' => 'Dashboard', 'icon' => 'fas fa-tachometer-alt']
        ]
    ],
    'admin-dashboard-enhanced.php' => [
        'title' => 'Admin Dashboard',
        'description' => 'Manage buses, routes, bookings, and system analytics',
        'breadcrumbs' => [
            ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
            ['title' => 'Admin Dashboard', 'icon' => 'fas fa-tachometer-alt']
        ]
    ]
];

echo "<h2>Pages to Update:</h2>";
echo "<ul>";
foreach ($pages_to_update as $file => $config) {
    echo "<li><strong>$file</strong> - {$config['title']}</li>";
}
echo "</ul>";

echo "<h2>Update Process:</h2>";
echo "<p>1. ✅ Created common header template (includes/header.php)</p>";
echo "<p>2. ✅ Created common footer template (includes/footer.php)</p>";
echo "<p>3. 🔄 Updating individual pages...</p>";

// Create backup directory
if (!is_dir('backups')) {
    mkdir('backups', 0755, true);
    echo "<p>✅ Created backup directory</p>";
}

// Function to backup a file
function backup_file($filename) {
    if (file_exists($filename)) {
        $backup_name = 'backups/' . $filename . '.backup.' . date('Y-m-d-H-i-s');
        copy($filename, $backup_name);
        return true;
    }
    return false;
}

// Function to update page header
function update_page_header($filename, $config) {
    if (!file_exists($filename)) {
        return "File not found: $filename";
    }
    
    // Backup original file
    backup_file($filename);
    
    $content = file_get_contents($filename);
    
    // Extract PHP code before HTML
    preg_match('/^<\?php.*?\?>/s', $content, $php_matches);
    $php_code = $php_matches[0] ?? '';
    
    // Create new header configuration
    $header_config = "<?php\n";
    $header_config .= "require_once 'config.php';\n\n";
    $header_config .= "// Page configuration\n";
    $header_config .= "\$page_title = '{$config['title']}';\n";
    $header_config .= "\$page_description = '{$config['description']}';\n";
    $header_config .= "\$show_page_header = true;\n";
    
    if (isset($config['breadcrumbs'])) {
        $header_config .= "\$breadcrumbs = [\n";
        foreach ($config['breadcrumbs'] as $crumb) {
            $header_config .= "    [";
            $header_config .= "'title' => '{$crumb['title']}', ";
            if (isset($crumb['url'])) {
                $header_config .= "'url' => '{$crumb['url']}', ";
            }
            $header_config .= "'icon' => '{$crumb['icon']}'";
            $header_config .= "],\n";
        }
        $header_config .= "];\n\n";
    }
    
    $header_config .= "// Include header\n";
    $header_config .= "include 'includes/header.php';\n";
    $header_config .= "?>\n\n";
    
    // Find where main content starts (after navigation)
    $content_start = strpos($content, '<div class="container');
    if ($content_start === false) {
        $content_start = strpos($content, '<section');
    }
    if ($content_start === false) {
        $content_start = strpos($content, '<main');
    }
    
    if ($content_start !== false) {
        $main_content = substr($content, $content_start);
        
        // Remove closing body and html tags
        $main_content = preg_replace('/<\/body>\s*<\/html>\s*$/s', '', $main_content);
        
        // Add footer include
        $main_content .= "\n\n<?php include 'includes/footer.php'; ?>";
        
        // Combine new structure
        $new_content = $header_config . $main_content;
        
        // Write updated file
        file_put_contents($filename, $new_content);
        
        return "✅ Updated successfully";
    } else {
        return "❌ Could not find content start";
    }
}

// Update each page
foreach ($pages_to_update as $filename => $config) {
    echo "<h3>Updating $filename</h3>";
    $result = update_page_header($filename, $config);
    echo "<p>$result</p>";
}

echo "<h2>✅ Update Complete!</h2>";
echo "<p>All pages have been updated with:</p>";
echo "<ul>";
echo "<li>✅ Consistent navigation header</li>";
echo "<li>✅ Professional page headers with breadcrumbs</li>";
echo "<li>✅ Unified styling and branding</li>";
echo "<li>✅ Responsive design</li>";
echo "<li>✅ Common footer with links</li>";
echo "</ul>";

echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>Test all pages for functionality</li>";
echo "<li>Check responsive design on mobile</li>";
echo "<li>Verify all links work correctly</li>";
echo "<li>Update any custom styling as needed</li>";
echo "</ol>";

echo "<h3>Backup Files:</h3>";
echo "<p>Original files have been backed up to the 'backups' directory.</p>";

if (is_dir('backups')) {
    $backups = glob('backups/*.backup.*');
    echo "<ul>";
    foreach ($backups as $backup) {
        echo "<li>" . basename($backup) . "</li>";
    }
    echo "</ul>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h1, h2, h3 { color: #333; }
ul, ol { margin: 10px 0; }
li { margin: 5px 0; }
</style>