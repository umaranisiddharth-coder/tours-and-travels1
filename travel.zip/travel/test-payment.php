<?php
// test-payment.php
session_start();
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Payment System - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background: #f8f9fa; }
        .test-card { max-width: 800px; margin: 0 auto; }
        .test-section { margin-bottom: 30px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card test-card">
            <div class="card-header bg-primary text-white">
                <h3 class="mb-0"><i class="fas fa-vial"></i> Payment System Test Page</h3>
            </div>
            <div class="card-body">
                
                <div class="alert alert-warning test-section">
                    <h5><i class="fas fa-exclamation-triangle"></i> Test Mode Active</h5>
                    <p>This page is for testing the payment system. No real payments will be processed.</p>
                </div>
                
                <div class="test-section">
                    <h5>1. Test Database Connection</h5>
                    <?php
                    if ($conn) {
                        echo '<div class="alert alert-success">';
                        echo '<i class="fas fa-check-circle"></i> Database connected successfully';
                        echo '</div>';
                        
                        // Check required tables
                        $tables = ['users', 'buses', 'bus_routes', 'bookings', 'pending_bookings', 'payments'];
                        $missing_tables = [];
                        foreach ($tables as $table) {
                            $result = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
                            if (mysqli_num_rows($result) == 0) {
                                $missing_tables[] = $table;
                            }
                        }
                        
                        if (empty($missing_tables)) {
                            echo '<div class="alert alert-success">';
                            echo '<i class="fas fa-check-circle"></i> All required tables exist';
                            echo '</div>';
                        } else {
                            echo '<div class="alert alert-danger">';
                            echo '<i class="fas fa-times-circle"></i> Missing tables: ' . implode(', ', $missing_tables);
                            echo '</div>';
                        }
                        
                    } else {
                        echo '<div class="alert alert-danger">';
                        echo '<i class="fas fa-times-circle"></i> Database connection failed';
                        echo '</div>';
                    }
                    ?>
                </div>
                
                <div class="test-section">
                    <h5>2. Test Payment Flow</h5>
                    <p>Simulate a complete payment flow:</p>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <div class="card">
                                <div class="card-body text-center">
                                    <h6>Step 1: Create Test Data</h6>
                                    <button onclick="createTestData()" class="btn btn-primary">
                                        <i class="fas fa-database"></i> Create Test Data
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <div class="card">
                                <div class="card-body text-center">
                                    <h6>Step 2: Test Payment</h6>
                                    <a href="payment.php" class="btn btn-success">
                                        <i class="fas fa-credit-card"></i> Go to Payment
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <div class="card">
                                <div class="card-body text-center">
                                    <h6>Step 3: View Logs</h6>
                                    <button onclick="viewLogs()" class="btn btn-info">
                                        <i class="fas fa-file-alt"></i> View Debug Logs
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="test-section">
                    <h5>3. Test Files Check</h5>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>File</th>
                                <th>Status</th>
                                <th>Size</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $files = [
                                'config.php',
                                'paytm-config.php',
                                'encdec_paytm.php',
                                'payment.php',
                                'process-payment.php',
                                'payment-callback.php',
                                'booking-confirm.php',
                                'payment-failed.php'
                            ];
                            
                            foreach ($files as $file) {
                                if (file_exists($file)) {
                                    $size = filesize($file);
                                    echo "<tr>";
                                    echo "<td>$file</td>";
                                    echo "<td><span class='badge bg-success'>Exists</span></td>";
                                    echo "<td>" . number_format($size) . " bytes</td>";
                                    echo "</tr>";
                                } else {
                                    echo "<tr>";
                                    echo "<td>$file</td>";
                                    echo "<td><span class='badge bg-danger'>Missing</span></td>";
                                    echo "<td>-</td>";
                                    echo "</tr>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="test-section">
                    <h5>4. Session Data</h5>
                    <pre class="bg-light p-3"><?php print_r($_SESSION); ?></pre>
                </div>
                
                <div class="test-section">
                    <h5>5. Quick Test Links</h5>
                    <div class="d-grid gap-2">
                        <a href="payment-callback.php?test=success&order_id=TEST_ORDER&amount=1000" 
                           class="btn btn-success">
                            <i class="fas fa-check"></i> Test Successful Payment
                        </a>
                        <a href="payment-callback.php?test=failed&order_id=TEST_ORDER" 
                           class="btn btn-danger">
                            <i class="fas fa-times"></i> Test Failed Payment
                        </a>
                        <a href="debug-info.php" class="btn btn-info">
                            <i class="fas fa-bug"></i> View Debug Information
                        </a>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    
    <script>
    function createTestData() {
        if (confirm('This will create test data in the database. Continue?')) {
            // AJAX call to create test data
            fetch('test-setup.php')
                .then(response => response.text())
                .then(data => {
                    alert('Test data created: ' + data);
                    location.reload();
                })
                .catch(error => {
                    alert('Error: ' + error);
                });
        }
    }
    
    function viewLogs() {
        // Check if debug log exists
        fetch('payment_debug.log')
            .then(response => response.text())
            .then(data => {
                alert('Debug Log:\n\n' + data.substring(0, 2000));
            })
            .catch(error => {
                alert('No debug log found or error: ' + error);
            });
    }
    </script>
</body>
</html>