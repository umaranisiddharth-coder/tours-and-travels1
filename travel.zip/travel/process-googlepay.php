<?php
require_once 'config.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Get order details
$order_id = isset($_SESSION['paytm_order_id']) ? $_SESSION['paytm_order_id'] : generate_order_id();
$amount = isset($_SESSION['paytm_amount']) ? $_SESSION['paytm_amount'] : 0;
$user_id = $_SESSION['user_id'];

if ($amount <= 0) {
    $_SESSION['payment_error'] = 'Invalid payment amount';
    header("Location: payment-failed.php");
    exit();
}

// Google Pay Configuration
$merchant_name = 'SR Travels';
$transaction_note = 'Bus Booking Payment - ' . $order_id;

// Generate Google Pay URL
$gpay_url = generateGooglePayUrl($merchant_name, $amount, $transaction_note, $order_id);

function generateGooglePayUrl($name, $amount, $note, $txn_id) {
    // Google Pay uses UPI protocol
    $upi_id = 'srtravels@paytm'; // Your UPI ID
    $params = [
        'pa' => $upi_id,
        'pn' => $name,
        'am' => $amount,
        'tn' => $note,
        'tr' => $txn_id,
        'cu' => 'INR'
    ];
    
    return 'upi://pay?' . http_build_query($params);
}

// Page configuration
$page_title = 'Google Pay Payment';
$page_description = 'Pay securely with Google Pay';
$show_page_header = true;
$breadcrumbs = [
    ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
    ['title' => 'Book Bus', 'url' => 'enhanced-booking-system.php', 'icon' => 'fas fa-search'],
    ['title' => 'Select Seats', 'url' => 'seat-selection.php', 'icon' => 'fas fa-chair'],
    ['title' => 'Payment', 'url' => 'payment.php', 'icon' => 'fas fa-credit-card'],
    ['title' => 'Google Pay', 'icon' => 'fab fa-google-pay']
];

// Custom CSS
$custom_css = '
    .payment-container {
        max-width: 600px;
        margin: 0 auto;
    }
    
    .payment-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        margin-bottom: 30px;
    }
    
    .payment-header {
        background: linear-gradient(135deg, #4285f4 0%, #34a853 100%);
        color: white;
        padding: 30px;
        text-align: center;
    }
    
    .gpay-logo {
        font-size: 3rem;
        margin-bottom: 15px;
    }
    
    .amount-display {
        font-size: 2.5rem;
        font-weight: bold;
        color: #28a745;
        margin: 20px 0;
    }
    
    .payment-steps {
        background: #f8f9fa;
        border-radius: 15px;
        padding: 25px;
        margin: 20px 0;
    }
    
    .step-item {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
        padding: 10px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    .step-number {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: #4285f4;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 15px;
        font-weight: bold;
    }
';

include 'includes/header.php';
?>

<!-- Content Section -->
<section class="content-section">
    <div class="container payment-container">
        <div class="payment-card" data-aos="fade-up">
            <!-- Header -->
            <div class="payment-header">
                <div class="gpay-logo">
                    <i class="fab fa-google-pay"></i>
                </div>
                <h1>Google Pay</h1>
                <p class="mb-0">Pay securely with Google Pay</p>
            </div>
            
            <!-- Body -->
            <div class="card-body p-4">
                <!-- Amount Display -->
                <div class="text-center">
                    <div class="amount-display">₹<?php echo number_format($amount, 2); ?></div>
                    <p class="text-muted">Order ID: <?php echo $order_id; ?></p>
                </div>
                
                <!-- Payment Steps -->
                <div class="payment-steps">
                    <h5 class="mb-3">
                        <i class="fas fa-list-ol me-2"></i>
                        How to pay with Google Pay
                    </h5>
                    
                    <div class="step-item">
                        <div class="step-number">1</div>
                        <div>
                            <strong>Open Google Pay</strong>
                            <br><small class="text-muted">Click the button below to open Google Pay app</small>
                        </div>
                    </div>
                    
                    <div class="step-item">
                        <div class="step-number">2</div>
                        <div>
                            <strong>Verify Payment Details</strong>
                            <br><small class="text-muted">Check amount and merchant details</small>
                        </div>
                    </div>
                    
                    <div class="step-item">
                        <div class="step-number">3</div>
                        <div>
                            <strong>Complete Payment</strong>
                            <br><small class="text-muted">Enter your UPI PIN to pay</small>
                        </div>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="d-grid gap-2">
                    <a href="<?php echo $gpay_url; ?>" class="btn btn-primary btn-lg" style="background: linear-gradient(135deg, #4285f4, #34a853);">
                        <i class="fab fa-google-pay me-2"></i>
                        Open Google Pay
                    </a>
                    
                    <button class="btn btn-success btn-lg" onclick="checkPaymentStatus()">
                        <i class="fas fa-sync me-2"></i>
                        Check Payment Status
                    </button>
                    
                    <!-- Demo Button -->
                    <button class="btn btn-warning btn-lg" onclick="simulatePaymentSuccess()">
                        <i class="fas fa-check-circle me-2"></i>
                        Mark as Paid (Demo)
                    </button>
                    
                    <div class="row g-2">
                        <div class="col-6">
                            <a href="payment.php" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-arrow-left me-2"></i>
                                Back
                            </a>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-outline-info w-100" onclick="window.location.reload()">
                                <i class="fas fa-redo me-2"></i>
                                Refresh
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Payment Status -->
                <div class="alert alert-info mt-3" id="paymentStatus" style="display: none;">
                    <div class="d-flex align-items-center">
                        <div class="spinner-border spinner-border-sm me-2"></div>
                        <span>Checking payment status...</span>
                    </div>
                </div>
                
                <!-- Support Info -->
                <div class="text-center mt-4">
                    <small class="text-muted">
                        <i class="fas fa-shield-alt"></i>
                        Secure Google Pay Payment | 
                        <i class="fas fa-phone"></i>
                        Support: +91 9356437871
                    </small>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
$custom_js = '
    function checkPaymentStatus() {
        document.getElementById("paymentStatus").style.display = "block";
        document.getElementById("paymentStatus").className = "alert alert-info";
        document.getElementById("paymentStatus").innerHTML = 
            "<div class=\"d-flex align-items-center\">" +
            "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
            "<span>Checking payment status...</span>" +
            "</div>";
        
        fetch("ajax-handler.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: "action=check_upi_payment&order_id=' . $order_id . '"
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                document.getElementById("paymentStatus").className = "alert alert-success";
                document.getElementById("paymentStatus").innerHTML = 
                    "<i class=\"fas fa-check-circle me-2\"></i>Payment successful! Redirecting...";
                setTimeout(() => {
                    window.location.href = "booking-confirm.php";
                }, 2000);
            } else if (data.status === "failed") {
                document.getElementById("paymentStatus").className = "alert alert-danger";
                document.getElementById("paymentStatus").innerHTML = 
                    "<i class=\"fas fa-times-circle me-2\"></i>Payment failed. Please try again.";
            } else {
                document.getElementById("paymentStatus").className = "alert alert-warning";
                document.getElementById("paymentStatus").innerHTML = 
                    "<i class=\"fas fa-clock me-2\"></i>Payment pending. Please complete the payment in Google Pay.";
            }
        })
        .catch(error => {
            document.getElementById("paymentStatus").className = "alert alert-danger";
            document.getElementById("paymentStatus").innerHTML = 
                "<i class=\"fas fa-exclamation-triangle me-2\"></i>Error checking payment status.";
        });
    }
    
    function simulatePaymentSuccess() {
        if (confirm("This will mark the payment as successful for demo purposes. Continue?")) {
            document.getElementById("paymentStatus").style.display = "block";
            document.getElementById("paymentStatus").className = "alert alert-info";
            document.getElementById("paymentStatus").innerHTML = 
                "<div class=\"d-flex align-items-center\">" +
                "<div class=\"spinner-border spinner-border-sm me-2\"></div>" +
                "<span>Processing demo payment...</span>" +
                "</div>";
            
            setTimeout(() => {
                fetch("payment-callback.php?test=success&order_id=' . $order_id . '&amount=' . $amount . '")
                    .then(() => {
                        document.getElementById("paymentStatus").className = "alert alert-success";
                        document.getElementById("paymentStatus").innerHTML = 
                            "<i class=\"fas fa-check-circle me-2\"></i>Payment successful! Redirecting...";
                        setTimeout(() => {
                            window.location.href = "booking-confirm.php";
                        }, 2000);
                    })
                    .catch(error => {
                        document.getElementById("paymentStatus").className = "alert alert-danger";
                        document.getElementById("paymentStatus").innerHTML = 
                            "<i class=\"fas fa-times-circle me-2\"></i>Demo payment failed.";
                    });
            }, 1500);
        }
    }
    
    // Auto-check payment status every 10 seconds
    setInterval(checkPaymentStatus, 10000);
';

include 'includes/footer.php';
?>