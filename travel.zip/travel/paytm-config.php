
<?php
// paytm-config.php - CONFIGURATION ONLY

// Payment Gateway Configuration
define('PAYMENT_TEST_MODE', true); // Set to false for production

// Available Payment Methods
$payment_methods = [
    'paytm' => [
        'name' => 'PayTM',
        'icon' => 'fa-wallet',
        'enabled' => true
    ],
    'phonepay' => [
        'name' => 'PhonePe',
        'icon' => 'fa-mobile-alt',
        'enabled' => true
    ],
    'upi' => [
        'name' => 'UPI',
        'icon' => 'fa-qrcode',
        'enabled' => true
    ],
    'card' => [
        'name' => 'Card',
        'icon' => 'fa-credit-card',
        'enabled' => true
    ],
    'netbanking' => [
        'name' => 'Net Banking',
        'icon' => 'fa-university',
        'enabled' => true
    ]
];

// PhonePe Configuration
if (PAYMENT_TEST_MODE) {
    // Test Mode Configuration
    define('PAYTM_ENVIRONMENT', 'TEST');
    define('PAYTM_MERCHANT_KEY', 'test_merchant_key');
    define('PAYTM_MERCHANT_MID', 'test_mid');
    define('PAYTM_MERCHANT_WEBSITE', 'WEBSTAGING');
    
    // PhonePe Test Configuration
    define('PHONEPE_ENVIRONMENT', 'TEST');
    define('PHONEPE_MERCHANT_ID', 'test_merchant_id');
    define('PHONEPE_SALT_KEY', 'test_salt_key');
    define('PHONEPE_SALT_INDEX', 1);
} else {
    // Production Mode Configuration
    define('PAYTM_ENVIRONMENT', 'PROD');
    define('PAYTM_MERCHANT_KEY', 'your_production_key_here');
    define('PAYTM_MERCHANT_MID', 'your_production_mid_here');
    define('PAYTM_MERCHANT_WEBSITE', 'your_website_name');
    
    // PhonePe Production Configuration
    define('PHONEPE_ENVIRONMENT', 'PROD');
    define('PHONEPE_MERCHANT_ID', 'your_production_merchant_id');
    define('PHONEPE_SALT_KEY', 'your_production_salt_key');
    define('PHONEPE_SALT_INDEX', 1);
}

// Razorpay Configuration
if (PAYMENT_TEST_MODE) {
    define('RAZORPAY_KEY_ID', 'rzp_test_1234567890');
    define('RAZORPAY_KEY_SECRET', 'test_secret_key_razorpay');
} else {
    define('RAZORPAY_KEY_ID', 'your_live_razorpay_key_id');
    define('RAZORPAY_KEY_SECRET', 'your_live_razorpay_secret');
}

// UPI Configuration
define('UPI_MERCHANT_ID', 'srtravels@paytm');
define('UPI_MERCHANT_NAME', 'SR Travels');

// URLs Configuration
if (PAYTM_ENVIRONMENT == 'PROD') {
    define('PAYTM_TXN_URL', 'https://securegw.paytm.in/theia/processTransaction');
    define('PAYTM_STATUS_URL', 'https://securegw.paytm.in/merchant-status/getTxnStatus');
} else {
    define('PAYTM_TXN_URL', 'https://securegw-stage.paytm.in/theia/processTransaction');
    define('PAYTM_STATUS_URL', 'https://securegw-stage.paytm.in/merchant-status/getTxnStatus');
}

// PhonePe URLs Configuration
if (PHONEPE_ENVIRONMENT == 'PROD') {
    define('PHONEPE_BASE_URL', 'https://api.phonepe.com/apis/hermes');
} else {
    define('PHONEPE_BASE_URL', 'https://api-preprod.phonepe.com/apis/hermes');
}

define('PHONEPE_PAY_URL', PHONEPE_BASE_URL . '/pg/v1/pay');
define('PHONEPE_STATUS_URL', PHONEPE_BASE_URL . '/pg/v1/status');

// Site URL Configuration
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
$script_path = isset($_SERVER['SCRIPT_NAME']) ? dirname($_SERVER['SCRIPT_NAME']) : '';
define('SITE_URL', rtrim($protocol . $host . $script_path, '/'));

// Callback URLs
define('PAYTM_CALLBACK_URL', SITE_URL . '/payment-callback.php');
define('PHONEPE_CALLBACK_URL', SITE_URL . '/phonepay-callback.php');

// Payment Settings
define('CURRENCY', 'INR');
define('MIN_PAYMENT_AMOUNT', 10);
define('MAX_PAYMENT_AMOUNT', 100000);
define('PAYMENT_TIMEOUT_MINUTES', 30);

// Email Settings
define('PAYMENT_FROM_EMAIL', 'payments@srtravels.com');
define('PAYMENT_FROM_NAME', 'SR Travels');

// Configuration Helper Functions (NO database functions)
function is_payment_test_mode() {
    return defined('PAYMENT_TEST_MODE') && PAYMENT_TEST_MODE;
}

function get_active_payment_methods() {
    global $payment_methods;
    $active = [];
    foreach ($payment_methods as $key => $method) {
        if ($method['enabled']) {
            $active[$key] = $method;
        }
    }
    return $active;
}

function validate_payment_amount($amount) {
    if ($amount < MIN_PAYMENT_AMOUNT) {
        return ['success' => false, 'message' => 'Minimum payment amount is ₹' . MIN_PAYMENT_AMOUNT];
    }
    if ($amount > MAX_PAYMENT_AMOUNT) {
        return ['success' => false, 'message' => 'Maximum payment amount is ₹' . MAX_PAYMENT_AMOUNT];
    }
    return ['success' => true, 'message' => 'Amount validated'];
}

function get_payment_method_name($method) {
    global $payment_methods;
    return isset($payment_methods[$method]) ? $payment_methods[$method]['name'] : 'Unknown';
}

function get_payment_method_icon($method) {
    global $payment_methods;
    return isset($payment_methods[$method]) ? $payment_methods[$method]['icon'] : 'fa-money-bill';
}

function generate_test_order_id() {
    return 'TEST_' . date('YmdHis') . '_' . rand(1000, 9999);
}

function log_payment_debug($message, $data = null) {
    if (is_payment_test_mode()) {
        $log_file = __DIR__ . '/payment_debug.log';
        $log_message = '[' . date('Y-m-d H:i:s') . '] ' . $message;
        if ($data) {
            $log_message .= ' - ' . print_r($data, true);
        }
        $log_message .= "\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);
    }
}

// PhonePe Helper Functions
function generate_phonepe_signature($data) {
    $signature = hash('sha256', $data . PHONEPE_SALT_KEY) . '###' . PHONEPE_SALT_INDEX;
    return $signature;
}

function validate_phonepe_response($response) {
    $data = json_decode($response, true);
    if (!isset($data['success']) || !$data['success']) {
        return false;
    }
    
    // Verify signature if present
    if (isset($data['data']['signature'])) {
        $signature = $data['data']['signature'];
        $payload = $data['data']['response'];
        $expected_signature = generate_phonepe_signature($payload);
        return hash_equals($signature, $expected_signature);
    }
    
    return true;
}
