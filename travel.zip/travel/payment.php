<?php
require_once 'config.php';

// Page configuration
$page_title = 'Secure Payment';
$page_description = 'Complete your bus booking with secure payment options';
$show_page_header = true;
$breadcrumbs = [
    ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
    ['title' => 'Book Bus', 'url' => 'enhanced-booking-system.php', 'icon' => 'fas fa-search'],
    ['title' => 'Select Seats', 'url' => 'seat-selection.php', 'icon' => 'fas fa-chair'],
    ['title' => 'Payment', 'icon' => 'fas fa-credit-card']
];

if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Check if booking data exists
if (!isset($_SESSION['selected_seats']) || !isset($_SESSION['route_id'])) {
    set_flash_message('error', 'No booking data found. Please select seats first.');
    header("Location: enhanced-booking-system.php");
    exit();
}

// Ensure selected_seats is an array
if (is_string($_SESSION['selected_seats'])) {
    $json_decoded = json_decode($_SESSION['selected_seats'], true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($json_decoded)) {
        $_SESSION['selected_seats'] = $json_decoded;
    } else {
        $_SESSION['selected_seats'] = explode(',', $_SESSION['selected_seats']);
    }
}

$route_id = $_SESSION['route_id'];
$travel_date = $_SESSION['travel_date'];
$selected_seats = $_SESSION['selected_seats'];
$total_amount = $_SESSION['total_amount'];
$user_id = $_SESSION['user_id'];

// Get route details
$route_query = "SELECT r.*, b.bus_name, b.bus_number, b.bus_type 
                FROM bus_routes r 
                JOIN buses b ON r.bus_id = b.id 
                WHERE r.id = ?";
$stmt = mysqli_prepare($conn, $route_query);
mysqli_stmt_bind_param($stmt, "i", $route_id);
mysqli_stmt_execute($stmt);
$route_result = mysqli_stmt_get_result($stmt);
$route = mysqli_fetch_assoc($route_result);

if (!$route) {
    set_flash_message('error', 'Route not found');
    header("Location: enhanced-booking-system.php");
    exit();
}

// Get user details
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $user_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$user_result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($user_result);

$error = '';
$success = '';

// Process payment initiation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['initiate_payment'])) {
    $payment_method = sanitize_input($_POST['payment_method']);
    
    // Validate amount
    if ($total_amount <= 0) {
        $error = "Invalid payment amount.";
    } elseif (empty($payment_method)) {
        $error = "Please select a payment method.";
    } else {
        // Generate order ID
        $order_id = generate_order_id();
        
        // Create pending booking
        $seats_string = implode(',', $selected_seats);
        if (create_pending_booking($order_id, $user_id, $route_id, $travel_date, $seats_string, $total_amount)) {
            
            // Store payment data in session
            $_SESSION['paytm_order_id'] = $order_id;
            $_SESSION['paytm_amount'] = $total_amount;
            $_SESSION['payment_method'] = $payment_method;
            
            // Log payment attempt
            log_payment_attempt($order_id, $user_id, $total_amount, $payment_method, 'initiated');
            
            // Redirect based on payment method
            switch ($payment_method) {
                case 'phonepe':
                    header("Location: process-phonepay.php");
                    break;
                case 'googlepay':
                    header("Location: process-googlepay.php");
                    break;
                case 'paytm':
                    header("Location: process-payment.php");
                    break;
                case 'amazonpay':
                    header("Location: process-amazonpay.php");
                    break;
                case 'bhim_upi':
                case 'mobikwik':
                case 'freecharge':
                case 'upi_qr':
                    header("Location: process-upi-qr.php");
                    break;
                case 'razorpay':
                case 'emi':
                case 'international_cards':
                    header("Location: process-razorpay.php");
                    break;
                case 'netbanking':
                    header("Location: process-netbanking.php");
                    break;
                case 'simpl':
                    header("Location: process-simpl.php");
                    break;
                case 'lazypay':
                    header("Location: process-lazypay.php");
                    break;
                case 'ola_money':
                    header("Location: process-ola-money.php");
                    break;
                case 'test_success':
                    // Test mode - simulate successful payment
                    header("Location: payment-callback.php?test=success&order_id=" . $order_id . "&amount=" . $total_amount);
                    break;
                case 'test_failed':
                    // Test mode - simulate failed payment
                    header("Location: payment-callback.php?test=failed&order_id=" . $order_id . "&amount=" . $total_amount);
                    break;
                default:
                    header("Location: process-payment.php");
            }
            exit();
            
        } else {
            $error = "Failed to create booking. Please try again.";
        }
    }
}

// Custom CSS for payment page
$custom_css = "
    .payment-container {
        max-width: 900px;
        margin: 0 auto;
    }
    
    .payment-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        margin-bottom: 30px;
        border: 1px solid rgba(211, 47, 47, 0.1);
    }
    
    .booking-summary {
        background: linear-gradient(135deg, rgba(211, 47, 47, 0.1), rgba(244, 67, 54, 0.1));
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 30px;
        border-left: 5px solid #d32f2f;
    }
    
    .payment-method-card {
        border: 2px solid #e9ecef;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 15px;
        cursor: pointer;
        transition: all 0.3s ease;
        background: white;
    }
    
    .payment-method-card:hover {
        border-color: #d32f2f;
        background: rgba(211, 47, 47, 0.05);
        transform: translateY(-3px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }
    
    .payment-method-card.selected {
        border-color: #d32f2f;
        background: linear-gradient(135deg, rgba(211, 47, 47, 0.1), rgba(244, 67, 54, 0.1));
        transform: translateY(-3px);
        box-shadow: 0 10px 25px rgba(211, 47, 47, 0.2);
    }
    
    .payment-icon {
        font-size: 2.5rem;
        margin-bottom: 10px;
        color: #d32f2f;
    }
    
    .amount-display {
        font-size: 3rem;
        font-weight: 800;
        color: #28a745;
        text-align: center;
        margin: 30px 0;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .payment-category {
        margin-bottom: 30px;
    }
    
    .payment-category h6 {
        font-weight: 600;
        color: #333;
        border-bottom: 2px solid #d32f2f;
        padding-bottom: 10px;
        margin-bottom: 20px;
    }
    
    .test-mode-badge {
        position: fixed;
        top: 100px;
        right: 20px;
        background: #ffc107;
        color: #333;
        padding: 10px 20px;
        border-radius: 25px;
        font-weight: bold;
        font-size: 0.9rem;
        z-index: 1000;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .btn-payment {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        border: none;
        border-radius: 10px;
        padding: 15px 30px;
        font-weight: 600;
        font-size: 1.1rem;
        transition: all 0.3s ease;
    }
    
    .btn-payment:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(211, 47, 47, 0.3);
    }
    
    .security-info {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 20px;
        margin-top: 20px;
    }
    
    @media (max-width: 768px) {
        .amount-display {
            font-size: 2.5rem;
        }
        
        .payment-method-card {
            padding: 15px;
        }
    }
";

// Include header
include 'includes/header.php';
?>

<div class="content-section">
    <div class="container payment-container">
        <!-- Test Mode Badge -->
        <div class="test-mode-badge">
            <i class="fas fa-vial me-2"></i>TEST MODE
        </div>
        
        <div class="payment-card">
            <!-- Header -->
            <div class="card-header text-center">
                <h1><i class="fas fa-lock me-2"></i>Secure Payment</h1>
                <p class="mb-0">Complete your booking with a secure payment</p>
            </div>
            
            <!-- Body -->
            <div class="card-body p-4">
                <!-- Booking Summary -->
                <div class="booking-summary">
                    <h5><i class="fas fa-receipt me-2"></i>Booking Summary</h5>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <p><strong>Route:</strong> <?php echo $route['from_city']; ?> to <?php echo $route['to_city']; ?></p>
                            <p><strong>Date:</strong> <?php echo format_date($travel_date); ?></p>
                            <p><strong>Time:</strong> <?php echo format_time($route['departure_time']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Bus:</strong> <?php echo $route['bus_name']; ?> (<?php echo $route['bus_number']; ?>)</p>
                            <p><strong>Seats:</strong> <?php echo implode(', ', $selected_seats); ?></p>
                            <p><strong>Bus Type:</strong> <?php echo ucfirst($route['bus_type']); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Amount Display -->
                <div class="amount-display">
                    ₹<?php echo number_format($total_amount, 2); ?>
                </div>
                
                <!-- Flash Messages -->
                <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                </div>
                <?php endif; ?>
                
                <!-- Payment Methods -->
                <form method="POST" action="" id="paymentForm">
                    <h5 class="mb-4">
                        <i class="fas fa-credit-card me-2"></i>
                        Choose Your Payment Method
                    </h5>
                    
                    <!-- UPI Payment Options -->
                    <div class="payment-category">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-mobile-alt me-2"></i>
                            UPI & Digital Wallets
                        </h6>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('phonepe')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #5f259f;">
                                            <i class="fas fa-mobile-alt"></i>
                                        </div>
                                        <h6>PhonePe</h6>
                                        <p class="text-muted mb-0">Pay with PhonePe UPI</p>
                                        <small class="text-success">✓ Instant</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('googlepay')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #4285f4;">
                                            <i class="fab fa-google-pay"></i>
                                        </div>
                                        <h6>Google Pay</h6>
                                        <p class="text-muted mb-0">Pay with Google Pay</p>
                                        <small class="text-success">✓ Rewards</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('paytm')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #00baf2;">
                                            <i class="fas fa-wallet"></i>
                                        </div>
                                        <h6>Paytm</h6>
                                        <p class="text-muted mb-0">Paytm Wallet & UPI</p>
                                        <small class="text-success">✓ Cashback</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('amazonpay')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #ff9900;">
                                            <i class="fab fa-amazon-pay"></i>
                                        </div>
                                        <h6>Amazon Pay</h6>
                                        <p class="text-muted mb-0">Amazon Pay Balance</p>
                                        <small class="text-success">✓ Cashback</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('bhim_upi')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #ff6b35;">
                                            <i class="fas fa-university"></i>
                                        </div>
                                        <h6>BHIM UPI</h6>
                                        <p class="text-muted mb-0">BHIM & Other UPI</p>
                                        <small class="text-success">✓ Direct</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('mobikwik')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #d32f2f;">
                                            <i class="fas fa-mobile-alt"></i>
                                        </div>
                                        <h6>MobiKwik</h6>
                                        <p class="text-muted mb-0">MobiKwik Wallet</p>
                                        <small class="text-success">✓ SuperCash</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('freecharge')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #00d4aa;">
                                            <i class="fas fa-bolt"></i>
                                        </div>
                                        <h6>FreeCharge</h6>
                                        <p class="text-muted mb-0">FreeCharge Wallet</p>
                                        <small class="text-success">✓ Instant</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('upi_qr')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #ff9500;">
                                            <i class="fas fa-qrcode"></i>
                                        </div>
                                        <h6>UPI QR Code</h6>
                                        <p class="text-muted mb-0">Scan & Pay</p>
                                        <small class="text-success">✓ Any UPI App</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Card Payment Options -->
                    <div class="payment-category">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-credit-card me-2"></i>
                            Cards & Net Banking
                        </h6>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('razorpay')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #3395ff;">
                                            <i class="fas fa-credit-card"></i>
                                        </div>
                                        <h6>Credit/Debit Card</h6>
                                        <p class="text-muted mb-0">Visa, MasterCard, RuPay</p>
                                        <small class="text-info">✓ All Banks</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('netbanking')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #ff6b35;">
                                            <i class="fas fa-university"></i>
                                        </div>
                                        <h6>Net Banking</h6>
                                        <p class="text-muted mb-0">All major banks</p>
                                        <small class="text-info">✓ Direct</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('emi')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #28a745;">
                                            <i class="fas fa-calendar-alt"></i>
                                        </div>
                                        <h6>EMI Options</h6>
                                        <p class="text-muted mb-0">3, 6, 9, 12 months</p>
                                        <small class="text-info">✓ 0% Interest*</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('international_cards')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #6c757d;">
                                            <i class="fas fa-globe"></i>
                                        </div>
                                        <h6>International Cards</h6>
                                        <p class="text-muted mb-0">Visa, MasterCard</p>
                                        <small class="text-info">✓ Global</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Buy Now Pay Later Options -->
                    <div class="payment-category">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-clock me-2"></i>
                            Buy Now Pay Later
                        </h6>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('simpl')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #ff6b35;">
                                            <i class="fas fa-handshake"></i>
                                        </div>
                                        <h6>Simpl</h6>
                                        <p class="text-muted mb-0">Pay in 1 click, pay later</p>
                                        <small class="text-warning">✓ 15 days credit</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('lazypay')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #4caf50;">
                                            <i class="fas fa-leaf"></i>
                                        </div>
                                        <h6>LazyPay</h6>
                                        <p class="text-muted mb-0">Pay next month</p>
                                        <small class="text-warning">✓ Credit limit</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('ola_money')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #00d4aa;">
                                            <i class="fas fa-car"></i>
                                        </div>
                                        <h6>Ola Money</h6>
                                        <p class="text-muted mb-0">Ola Money Postpaid</p>
                                        <small class="text-warning">✓ Postpaid</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Test Payment Options -->
                    <div class="payment-category">
                        <h6 class="text-warning mb-3">
                            <i class="fas fa-vial me-2"></i>
                            Test Payment Options
                        </h6>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('test_success')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #28a745;">
                                            <i class="fas fa-check-circle"></i>
                                        </div>
                                        <h6>Test Success</h6>
                                        <p class="text-muted mb-0">Simulate successful payment</p>
                                        <small class="text-success">✓ For Testing</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('test_failed')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #dc3545;">
                                            <i class="fas fa-times-circle"></i>
                                        </div>
                                        <h6>Test Failed</h6>
                                        <p class="text-muted mb-0">Simulate failed payment</p>
                                        <small class="text-danger">✓ For Testing</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="payment-method-card" onclick="selectPaymentMethod('paytm')">
                                    <div class="text-center">
                                        <div class="payment-icon" style="color: #00baf2;">
                                            <i class="fas fa-wallet"></i>
                                        </div>
                                        <h6>PayTM Gateway</h6>
                                        <p class="text-muted mb-0">Real PayTM integration</p>
                                        <small class="text-info">✓ Live Gateway</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Payment Gateway Selection -->
                    <div class="payment-gateway-info mb-4" id="gatewayInfo" style="display: none;">
                        <div class="alert alert-info">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-info-circle me-2"></i>
                                <div>
                                    <strong>Selected Payment Method:</strong>
                                    <span id="selectedMethodName">None</span>
                                    <br>
                                    <small id="selectedMethodDesc">Please select a payment method above</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Hidden input for payment method -->
                    <input type="hidden" id="payment_method" name="payment_method" value="">
                    
                    <!-- Terms and Conditions -->
                    <div class="terms-section mb-4">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="terms" required>
                            <label class="form-check-label" for="terms">
                                I agree to the Terms & Conditions and Cancellation Policy
                            </label>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="privacy" required>
                            <label class="form-check-label" for="privacy">
                                I consent to processing of my personal data for payment processing
                            </label>
                        </div>
                    </div>
                    
                    <!-- Payment Button -->
                    <div class="payment-actions">
                        <div class="d-grid gap-2">
                            <button type="submit" name="initiate_payment" class="btn btn-primary btn-lg btn-payment" id="paymentBtn" disabled>
                                <div class="d-flex align-items-center justify-content-center">
                                    <i class="fas fa-lock me-2"></i>
                                    <span>Pay Securely ₹<?php echo number_format($total_amount, 2); ?></span>
                                    <div class="spinner-border spinner-border-sm ms-2 d-none" id="paymentSpinner"></div>
                                </div>
                            </button>
                            
                            <div class="row g-2">
                                <div class="col-6">
                                    <a href="seat-selection.php" class="btn btn-outline-secondary w-100">
                                        <i class="fas fa-arrow-left me-2"></i> Back to Seats
                                    </a>
                                </div>
                                <div class="col-6">
                                    <a href="enhanced-booking-system.php" class="btn btn-outline-info w-100">
                                        <i class="fas fa-search me-2"></i> New Search
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                
                <!-- Security Info -->
                <div class="security-info">
                    <div class="row">
                        <div class="col-md-6">
                            <h6><i class="fas fa-shield-alt text-success me-2"></i>100% Secure Payment</h6>
                            <ul class="mb-0 small">
                                <li>256-bit SSL encryption</li>
                                <li>PCI DSS compliant</li>
                                <li>No card details stored</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h6><i class="fas fa-headset text-primary me-2"></i>24/7 Support</h6>
                            <ul class="mb-0 small">
                                <li>Phone: +91 9356437871</li>
                                <li>Email: support@srtravels.com</li>
                                <li>Instant chat support</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Payment method data
    const paymentMethods = {
        // UPI & Digital Wallets
        'phonepe': {
            name: 'PhonePe',
            desc: 'Pay instantly using PhonePe UPI. No additional charges.',
            gateway: 'phonepe'
        },
        'googlepay': {
            name: 'Google Pay',
            desc: 'Pay with Google Pay and earn rewards on every transaction.',
            gateway: 'googlepay'
        },
        'paytm': {
            name: 'Paytm',
            desc: 'Pay using Paytm Wallet or UPI. Get cashback on payments.',
            gateway: 'paytm'
        },
        'amazonpay': {
            name: 'Amazon Pay',
            desc: 'Pay with Amazon Pay balance and get cashback.',
            gateway: 'amazonpay'
        },
        'bhim_upi': {
            name: 'BHIM UPI',
            desc: 'Pay using BHIM or any other UPI app directly.',
            gateway: 'bhim_upi'
        },
        'mobikwik': {
            name: 'MobiKwik',
            desc: 'Pay with MobiKwik wallet and earn SuperCash.',
            gateway: 'mobikwik'
        },
        'freecharge': {
            name: 'FreeCharge',
            desc: 'Pay instantly with FreeCharge wallet.',
            gateway: 'freecharge'
        },
        'upi_qr': {
            name: 'UPI QR Code',
            desc: 'Scan QR code with any UPI app to pay.',
            gateway: 'upi_qr'
        },
        
        // Cards & Net Banking
        'razorpay': {
            name: 'Credit/Debit Card',
            desc: 'Pay with Visa, MasterCard, RuPay cards via Razorpay.',
            gateway: 'razorpay'
        },
        'netbanking': {
            name: 'Net Banking',
            desc: 'Direct payment from your bank account.',
            gateway: 'netbanking'
        },
        'emi': {
            name: 'EMI Options',
            desc: 'Pay in easy monthly installments. 0% interest available.',
            gateway: 'emi'
        },
        'international_cards': {
            name: 'International Cards',
            desc: 'Pay with international Visa/MasterCard.',
            gateway: 'international_cards'
        },
        
        // Buy Now Pay Later
        'simpl': {
            name: 'Simpl',
            desc: 'Pay in 1 click now, pay later in 15 days.',
            gateway: 'simpl'
        },
        'lazypay': {
            name: 'LazyPay',
            desc: 'Pay next month with LazyPay credit.',
            gateway: 'lazypay'
        },
        'ola_money': {
            name: 'Ola Money',
            desc: 'Pay with Ola Money Postpaid.',
            gateway: 'ola_money'
        },
        
        // Test Options
        'test_success': {
            name: 'Test Success',
            desc: 'Simulate a successful payment for testing purposes.',
            gateway: 'test'
        },
        'test_failed': {
            name: 'Test Failed',
            desc: 'Simulate a failed payment for testing purposes.',
            gateway: 'test'
        }
    };
    
    let selectedMethod = '';
    
    function selectPaymentMethod(method) {
        // Remove previous selection
        document.querySelectorAll('.payment-method-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        // Add selection to clicked card
        event.currentTarget.classList.add('selected');
        
        // Update hidden input
        document.getElementById('payment_method').value = method;
        selectedMethod = method;
        
        // Update gateway info
        updateGatewayInfo(method);
        
        // Enable payment button if terms are checked
        updatePaymentButton();
    }
    
    function updateGatewayInfo(method) {
        const gatewayInfo = document.getElementById('gatewayInfo');
        const methodName = document.getElementById('selectedMethodName');
        const methodDesc = document.getElementById('selectedMethodDesc');
        
        if (paymentMethods[method]) {
            methodName.textContent = paymentMethods[method].name;
            methodDesc.textContent = paymentMethods[method].desc;
            gatewayInfo.style.display = 'block';
        } else {
            gatewayInfo.style.display = 'none';
        }
    }
    
    function updatePaymentButton() {
        const paymentBtn = document.getElementById('paymentBtn');
        const termsChecked = document.getElementById('terms').checked;
        const privacyChecked = document.getElementById('privacy').checked;
        const methodSelected = selectedMethod !== '';
        
        if (termsChecked && privacyChecked && methodSelected) {
            paymentBtn.disabled = false;
            paymentBtn.classList.remove('btn-secondary');
            paymentBtn.classList.add('btn-primary');
        } else {
            paymentBtn.disabled = true;
            paymentBtn.classList.remove('btn-primary');
            paymentBtn.classList.add('btn-secondary');
        }
    }
    
    // Event listeners
    document.getElementById('terms').addEventListener('change', updatePaymentButton);
    document.getElementById('privacy').addEventListener('change', updatePaymentButton);
    
    // Form submission handling
    document.getElementById('paymentForm').addEventListener('submit', function(e) {
        if (!selectedMethod) {
            e.preventDefault();
            alert('Please select a payment method');
            return false;
        }
        
        // Show loading spinner
        const spinner = document.getElementById('paymentSpinner');
        const paymentBtn = document.getElementById('paymentBtn');
        
        spinner.classList.remove('d-none');
        paymentBtn.disabled = true;
        paymentBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing Payment...';
    });
    
    // Auto-select first payment method for demo
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-select test success for demo
        const testCard = document.querySelector('[onclick*="test_success"]');
        if (testCard) {
            testCard.click();
        }
    });
</script>

<?php include 'includes/footer.php'; ?>