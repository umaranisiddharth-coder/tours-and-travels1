<?php
require_once 'config.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: login.php");
    exit();
}

// Page configuration
$page_title = 'My Profile';
$page_description = 'Manage your SR Travels account settings and personal information';
$show_page_header = true;
$breadcrumbs = [
    ['title' => 'Home', 'url' => 'index.php', 'icon' => 'fas fa-home'],
    ['title' => 'Dashboard', 'url' => 'user-dashboard-enhanced.php', 'icon' => 'fas fa-tachometer-alt'],
    ['title' => 'My Profile', 'icon' => 'fas fa-user']
];

$error = '';
$success = '';

// Get user details
$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $user_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$user_result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($user_result);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        $full_name = sanitize_input($_POST['full_name']);
        $phone = sanitize_input($_POST['phone']);
        
        if (empty($full_name)) {
            $error = 'Full name is required.';
        } else {
            $update_query = "UPDATE users SET full_name = ?, phone = ? WHERE id = ?";
            $stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($stmt, "ssi", $full_name, $phone, $user_id);
            
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['full_name'] = $full_name;
                $success = 'Profile updated successfully!';
                // Refresh user data
                $user['full_name'] = $full_name;
                $user['phone'] = $phone;
            } else {
                $error = 'Error updating profile.';
            }
        }
    } elseif (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Enhanced validation
        if (empty($current_password)) {
            $error = 'Current password is required.';
        } elseif (empty($new_password)) {
            $error = 'New password is required.';
        } elseif ($new_password !== $confirm_password) {
            $error = 'New passwords do not match.';
        } elseif (strlen($new_password) < 8) {
            $error = 'New password must be at least 8 characters long.';
        } else {
            // Check password strength
            $password_errors = check_password_strength($new_password);
            if (!empty($password_errors)) {
                $error = implode('<br>', $password_errors);
            } else {
                // Verify current password
                if (password_verify($current_password, $user['password'])) {
                    // Hash new password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    
                    // Update password
                    $update_query = "UPDATE users SET password = ? WHERE id = ?";
                    $stmt = mysqli_prepare($conn, $update_query);
                    mysqli_stmt_bind_param($stmt, "si", $hashed_password, $user_id);
                    
                    if (mysqli_stmt_execute($stmt)) {
                        $success = 'Password changed successfully!';
                    } else {
                        $error = 'Error changing password.';
                    }
                } else {
                    $error = 'Current password is incorrect.';
                }
            }
        }
    }
}

// Custom CSS for profile page
$custom_css = "
    .profile-card {
        background: white;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        border: 1px solid rgba(211, 47, 47, 0.1);
        transition: all 0.3s ease;
    }
    
    .profile-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    }
    
    .profile-header {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        color: white;
        border-radius: 15px 15px 0 0;
        padding: 30px;
        text-align: center;
    }
    
    .profile-avatar {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.2);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        font-size: 3rem;
        border: 4px solid rgba(255, 255, 255, 0.3);
    }
    
    .profile-name {
        font-size: 1.5rem;
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .profile-email {
        opacity: 0.9;
        font-size: 1rem;
    }
    
    .nav-tabs .nav-link {
        border: none;
        color: #666;
        font-weight: 500;
        padding: 15px 25px;
        border-radius: 10px 10px 0 0;
        margin-right: 5px;
        transition: all 0.3s ease;
    }
    
    .nav-tabs .nav-link.active {
        background: #d32f2f;
        color: white;
    }
    
    .nav-tabs .nav-link:hover {
        background: rgba(211, 47, 47, 0.1);
        color: #d32f2f;
    }
    
    .tab-content {
        padding: 30px;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        font-weight: 500;
        color: #333;
        margin-bottom: 8px;
    }
    
    .form-control {
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        padding: 12px 15px;
        transition: all 0.3s ease;
    }
    
    .form-control:focus {
        border-color: #d32f2f;
        box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.1);
    }
    
    .btn-update {
        background: linear-gradient(135deg, #d32f2f, #b71c1c);
        border: none;
        border-radius: 10px;
        padding: 12px 30px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .btn-update:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(211, 47, 47, 0.3);
    }
    
    .password-strength {
        margin-top: 10px;
        font-size: 0.85rem;
    }
    
    .strength-bar {
        height: 6px;
        background: #e0e0e0;
        border-radius: 3px;
        margin-top: 5px;
        overflow: hidden;
    }
    
    .strength-fill {
        height: 100%;
        width: 0%;
        transition: all 0.3s ease;
        border-radius: 3px;
    }
    
    .password-rules {
        font-size: 0.8rem;
        color: #666;
        margin-top: 10px;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .password-rules ul {
        padding-left: 20px;
        margin-bottom: 0;
    }
    
    .password-rules li {
        margin-bottom: 5px;
        transition: color 0.3s ease;
    }
    
    .password-rules li.valid {
        color: #28a745;
    }
    
    .password-rules li.invalid {
        color: #dc3545;
    }
    
    .password-rules li.valid::before {
        content: '✓ ';
        font-weight: bold;
    }
    
    .password-rules li.invalid::before {
        content: '✗ ';
        font-weight: bold;
    }
    
    .input-group .btn {
        border: 2px solid #e0e0e0;
        border-left: none;
        background: #f8f9fa;
        color: #666;
    }
    
    .input-group .btn:hover {
        background: #e9ecef;
        color: #333;
    }
";

// Include header
include 'includes/header.php';
?>

<!-- Profile Content -->
<div class="content-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="profile-card" data-aos="fade-up">
                    <!-- Profile Header -->
                    <div class="profile-header">
                        <div class="profile-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="profile-name"><?php echo htmlspecialchars($user['full_name']); ?></div>
                        <div class="profile-email"><?php echo htmlspecialchars($user['email']); ?></div>
                        <div class="mt-3">
                            <span class="badge bg-light text-dark">
                                <i class="fas fa-calendar me-1"></i>
                                Member since <?php echo date('M Y', strtotime($user['created_at'] ?? 'now')); ?>
                            </span>
                        </div>
                    </div>
                    
                    <!-- Flash Messages -->
                    <?php if ($error): ?>
                        <div class="alert alert-danger mx-4 mt-4">
                            <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success mx-4 mt-4">
                            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Profile Tabs -->
                    <ul class="nav nav-tabs mt-4 mx-4" id="profileTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab">
                                <i class="fas fa-user me-2"></i>Profile Information
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="password-tab" data-bs-toggle="tab" data-bs-target="#password" type="button" role="tab">
                                <i class="fas fa-lock me-2"></i>Change Password
                            </button>
                        </li>
                    </ul>
                    
                    <div class="tab-content" id="profileTabsContent">
                        <!-- Profile Information Tab -->
                        <div class="tab-pane fade show active" id="profile" role="tabpanel">
                            <form method="POST" action="">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label" for="full_name">Full Name *</label>
                                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                                   value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label" for="username">Username</label>
                                            <input type="text" class="form-control" id="username" 
                                                   value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                                            <small class="text-muted">Username cannot be changed</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label" for="email">Email Address</label>
                                            <input type="email" class="form-control" id="email" 
                                                   value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                                            <small class="text-muted">Email cannot be changed</small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label" for="phone">Phone Number</label>
                                            <input type="tel" class="form-control" id="phone" name="phone" 
                                                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" 
                                                   placeholder="Enter 10-digit mobile number">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="text-end">
                                    <button type="submit" name="update_profile" class="btn btn-primary btn-update">
                                        <i class="fas fa-save me-2"></i>Update Profile
                                    </button>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Change Password Tab -->
                        <div class="tab-pane fade" id="password" role="tabpanel">
                            <form method="POST" action="" id="passwordForm">
                                <div class="form-group">
                                    <label class="form-label" for="current_password">Current Password *</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                                        <button type="button" class="btn toggle-password">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="new_password">New Password *</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                                        <button type="button" class="btn toggle-password">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <div class="password-strength">
                                        <div>Password strength: <span id="strength-value" style="font-weight: 600;">None</span></div>
                                        <div class="strength-bar">
                                            <div id="strength-fill" class="strength-fill"></div>
                                        </div>
                                    </div>
                                    <div class="password-rules">
                                        <strong>Password Requirements:</strong>
                                        <ul>
                                            <li id="rule-length" class="invalid">At least 8 characters</li>
                                            <li id="rule-uppercase" class="invalid">One uppercase letter</li>
                                            <li id="rule-lowercase" class="invalid">One lowercase letter</li>
                                            <li id="rule-number" class="invalid">One number</li>
                                            <li id="rule-special" class="invalid">One special character</li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="confirm_password">Confirm New Password *</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                        <button type="button" class="btn toggle-password">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <div id="password-match" class="form-text"></div>
                                </div>
                                
                                <div class="text-end">
                                    <button type="submit" name="change_password" class="btn btn-primary btn-update">
                                        <i class="fas fa-key me-2"></i>Change Password
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Password strength checker (same as reset-password.php)
    const passwordInput = document.getElementById('new_password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const strengthText = document.getElementById('strength-value');
    const strengthFill = document.getElementById('strength-fill');
    const passwordMatch = document.getElementById('password-match');
    
    // Password rules elements
    const ruleLength = document.getElementById('rule-length');
    const ruleUppercase = document.getElementById('rule-uppercase');
    const ruleLowercase = document.getElementById('rule-lowercase');
    const ruleNumber = document.getElementById('rule-number');
    const ruleSpecial = document.getElementById('rule-special');
    
    function checkPasswordStrength(password) {
        let strength = 0;
        
        // Check length
        if (password.length >= 8) {
            strength += 20;
            ruleLength.classList.remove('invalid');
            ruleLength.classList.add('valid');
        } else {
            ruleLength.classList.remove('valid');
            ruleLength.classList.add('invalid');
        }
        
        // Check uppercase
        if (/[A-Z]/.test(password)) {
            strength += 20;
            ruleUppercase.classList.remove('invalid');
            ruleUppercase.classList.add('valid');
        } else {
            ruleUppercase.classList.remove('valid');
            ruleUppercase.classList.add('invalid');
        }
        
        // Check lowercase
        if (/[a-z]/.test(password)) {
            strength += 20;
            ruleLowercase.classList.remove('invalid');
            ruleLowercase.classList.add('valid');
        } else {
            ruleLowercase.classList.remove('valid');
            ruleLowercase.classList.add('invalid');
        }
        
        // Check numbers
        if (/[0-9]/.test(password)) {
            strength += 20;
            ruleNumber.classList.remove('invalid');
            ruleNumber.classList.add('valid');
        } else {
            ruleNumber.classList.remove('valid');
            ruleNumber.classList.add('invalid');
        }
        
        // Check special characters
        if (/[^A-Za-z0-9]/.test(password)) {
            strength += 20;
            ruleSpecial.classList.remove('invalid');
            ruleSpecial.classList.add('valid');
        } else {
            ruleSpecial.classList.remove('valid');
            ruleSpecial.classList.add('invalid');
        }
        
        // Update strength bar
        strengthFill.style.width = strength + '%';
        
        // Update strength text and colors
        if (strength >= 80) {
            strengthText.textContent = 'Strong';
            strengthText.style.color = '#28a745';
            strengthFill.style.backgroundColor = '#28a745';
        } else if (strength >= 60) {
            strengthText.textContent = 'Good';
            strengthText.style.color = '#ffc107';
            strengthFill.style.backgroundColor = '#ffc107';
        } else if (strength >= 40) {
            strengthText.textContent = 'Fair';
            strengthText.style.color = '#fd7e14';
            strengthFill.style.backgroundColor = '#fd7e14';
        } else if (strength > 0) {
            strengthText.textContent = 'Weak';
            strengthText.style.color = '#dc3545';
            strengthFill.style.backgroundColor = '#dc3545';
        } else {
            strengthText.textContent = 'None';
            strengthText.style.color = '#6c757d';
            strengthFill.style.backgroundColor = '#6c757d';
        }
    }
    
    function checkPasswordMatch() {
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        
        if (confirmPassword === '') {
            passwordMatch.textContent = '';
            passwordMatch.style.color = '';
        } else if (password === confirmPassword) {
            passwordMatch.innerHTML = '<i class="fas fa-check-circle me-1"></i>Passwords match';
            passwordMatch.style.color = '#28a745';
        } else {
            passwordMatch.innerHTML = '<i class="fas fa-times-circle me-1"></i>Passwords do not match';
            passwordMatch.style.color = '#dc3545';
        }
    }
    
    // Event listeners
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            checkPasswordMatch();
        });
    }
    
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', checkPasswordMatch);
    }
    
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // Form validation
    const passwordForm = document.getElementById('passwordForm');
    if (passwordForm) {
        passwordForm.addEventListener('submit', function(e) {
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return;
            }
            
            // Check if password meets all requirements
            const validRules = document.querySelectorAll('.password-rules li.valid');
            if (validRules.length < 5) {
                e.preventDefault();
                alert('Please ensure your password meets all requirements.');
                return;
            }
        });
    }
</script>

<?php include 'includes/footer.php'; ?>>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - SR Travels</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="index.php">SR<span class="text-warning">TRAVELS</span></a>
            <div class="d-flex align-items-center">
                <span class="me-3">Welcome, <?php echo $_SESSION['full_name']; ?></span>
                <a href="user.php" class="btn btn-outline-primary btn-sm">Dashboard</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title mb-4">Change Password</h3>
                        
                        <?php if($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                <div class="form-text">Minimum 6 characters</div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="confirm_password" class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Change Password</button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-3">
                            <a href="user.php" class="text-decoration-none">
                                <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>